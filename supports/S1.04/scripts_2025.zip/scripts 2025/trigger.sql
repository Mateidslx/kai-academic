-------------------------------------------------------------------
-- TRIGGERS : DATE >= TODAY (TRUNC)
-------------------------------------------------------------------

-- 1) SAISON : dateDebSai >= today
CREATE OR REPLACE TRIGGER trg_saison_date_today
BEFORE INSERT OR UPDATE OF dateDebSai ON SAISON
FOR EACH ROW
BEGIN
  IF TRUNC(:NEW.dateDebSai) < TRUNC(SYSDATE) THEN
    RAISE_APPLICATION_ERROR(
      -20001,
      'SAISON.dateDebSai must be >= today.'
    );
  END IF;
END;
/
-------------------------------------------------------------------

-- 2) RESERVATION : dateRes >= today
CREATE OR REPLACE TRIGGER trg_reservation_date_today
BEFORE INSERT OR UPDATE OF dateRes ON RESERVATION
FOR EACH ROW
BEGIN
  IF TRUNC(:NEW.dateRes) < TRUNC(SYSDATE) THEN
    RAISE_APPLICATION_ERROR(
      -20002,
      'RESERVATION.dateRes must be >= today.'
    );
  END IF;
END;
/
-------------------------------------------------------------------

-- 3) LOUER : dateDebLoc >= today
CREATE OR REPLACE TRIGGER trg_louer_date_today
BEFORE INSERT OR UPDATE OF dateDebLoc ON LOUER
FOR EACH ROW
BEGIN
  IF TRUNC(:NEW.dateDebLoc) < TRUNC(SYSDATE) THEN
    RAISE_APPLICATION_ERROR(
      -20003,
      'LOUER.dateDebLoc must be >= today.'
    );
  END IF;
END;
/
-------------------------------------------------------------------

-- 4) PAIEMENT : datePaiement >= today
CREATE OR REPLACE TRIGGER trg_paiement_date_today
BEFORE INSERT OR UPDATE OF datePaiement ON PAIEMENT
FOR EACH ROW
BEGIN
  IF TRUNC(:NEW.datePaiement) < TRUNC(SYSDATE) THEN
    RAISE_APPLICATION_ERROR(
      -20004,
      'PAIEMENT.datePaiement must be >= today.'
    );
  END IF;
END;
/
-------------------------------------------------------------------
