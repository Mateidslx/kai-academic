BEGIN
    -- Supprimer toutes les tables du projet ONGI ETORRI
    FOR c IN (
        SELECT table_name
        FROM user_tables
        WHERE table_name IN (
            'EPI',
            'REGION',
            'COMMUNE',
            'HEBERGEMENT',
            'CHAMBRE',
            'SAISON',
            'CLIENT',
            'SEJOUR',
            'RESERVATION',
            'PAIEMENT',
            'MODEREGLEMENT',
            'PERIODE',
            'THEMATIQUE',
            'LOUER',
            'CLASSER',
            'PLANIFIER'
        )
    ) LOOP
        EXECUTE IMMEDIATE ('DROP TABLE "' || c.table_name || '" CASCADE CONSTRAINTS');
    END LOOP;

    -- Supprimer toutes les sequences éventuellement créées
    FOR s IN (SELECT sequence_name FROM user_sequences) LOOP
        EXECUTE IMMEDIATE ('DROP SEQUENCE ' || s.sequence_name);
    END LOOP;
END;
/
