-------------------------------------------------------------------
-- 1. ENTITES SIMPLES
-------------------------------------------------------------------

CREATE TABLE EPI (
    code            NUMBER(2)       CONSTRAINT pk_epi PRIMARY KEY,
    description     VARCHAR2(30)   NOT NULL
);

CREATE TABLE REGION (
    code            NUMBER(2)       CONSTRAINT pk_region PRIMARY KEY,
    libelle         VARCHAR2(15)    NOT NULL
); 

CREATE TABLE COMMUNE (
    code            NUMBER(2)       CONSTRAINT pk_commune PRIMARY KEY,
    libelle         VARCHAR2(25)    NOT NULL, 
    codeRegion      NUMBER(2)       NOT NULL, 
    CONSTRAINT fk_commune_region
        FOREIGN KEY (codeRegion) REFERENCES REGION(code)
); 

CREATE TABLE SAISON (
    code            VARCHAR2(2)     NOT NULL,
    dateDebSai      DATE            NOT NULL,
    dateFinSai      DATE            NOT NULL,
    libelle         VARCHAR2(15)    NOT NULL,
    coefficient     NUMBER(4,2)     NOT NULL,
    CONSTRAINT pk_saison
        PRIMARY KEY (code, dateDebSai, dateFinSai),
    CONSTRAINT ck_saison_semaines_samedi
        CHECK (
            dateFinSai = dateDebSai + 7
            AND TO_CHAR(dateDebSai, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') = 'SAT'
            AND TO_CHAR(dateFinSai, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') = 'SAT'
        )
);

CREATE TABLE MODEREGLEMENT (
    code            NUMBER(4)    CONSTRAINT pk_moderegl PRIMARY KEY,
    libelle         VARCHAR2(20)    NOT NULL
);


CREATE TABLE PERIODE (
    code            VARCHAR2(7)       CONSTRAINT pk_periode PRIMARY KEY,
    libelle         VARCHAR2(20)    NOT NULL
);

CREATE TABLE THEMATIQUE (
    code            NUMBER(4)       CONSTRAINT pk_thematique PRIMARY KEY,
    libelle         VARCHAR2(20)    NOT NULL
);


-------------------------------------------------------------------
-- 2. HEBERGEMENT & CHAMBRE
-------------------------------------------------------------------

CREATE TABLE HEBERGEMENT (
    code                VARCHAR2(3)       CONSTRAINT pk_hebergement PRIMARY KEY,
    nomProp             VARCHAR2(20)    NOT NULL,
    telFixe             VARCHAR2(10),
    telMob              VARCHAR2(10)    NOT NULL,
    URL                 VARCHAR2(30),
    email               VARCHAR2(30)   NOT NULL,
    capacite            NUMBER(2)      NOT NULL,
    tarifBaseChambre    NUMBER(8,2)     NOT NULL,
    tarifBaseLitSup     NUMBER(8,2)     NOT NULL,
    codeEpi             NUMBER(2)       NOT NULL,
    codeCommune         NUMBER(2)       NOT NULL,
    CONSTRAINT fk_heberg_epi
        FOREIGN KEY (codeEpi) REFERENCES EPI(code),
    CONSTRAINT fk_heberg_commune
        FOREIGN KEY (codeCommune) REFERENCES COMMUNE(code)
);

CREATE TABLE CHAMBRE (
    code            NUMBER(4)       CONSTRAINT pk_chambre PRIMARY KEY,
    type            VARCHAR2(15)    NOT NULL,
    codeHeberg      VARCHAR2(3)       NOT NULL,
    CONSTRAINT fk_chambre_heberg
        FOREIGN KEY (codeHeberg) REFERENCES HEBERGEMENT(code)
);


-------------------------------------------------------------------
-- 3. CLIENT
-------------------------------------------------------------------

CREATE TABLE CLIENT (
    code            NUMBER(6)       CONSTRAINT pk_client PRIMARY KEY,
    nom             VARCHAR2(20)    NOT NULL,
    prenom          VARCHAR2(15)    NOT NULL,
    adresse         VARCHAR2(90),
    codePost        VARCHAR2(5),
    ville           VARCHAR2(15),
    telFixe         VARCHAR2(10),
    telMob          VARCHAR2(10)    NOT NULL,
    email           VARCHAR2(30)   NOT NULL
);


-------------------------------------------------------------------
-- 4. SEJOUR
-------------------------------------------------------------------

CREATE TABLE SEJOUR (
    code            VARCHAR2(8)       CONSTRAINT pk_sejour PRIMARY KEY,
    type            VARCHAR2(10)    DEFAULT 'Theme' NOT NULL,
    intitule        VARCHAR2(20)   NOT NULL,
    lieu            VARCHAR2(20)    NOT NULL,
    dateArrivee     DATE            NOT NULL,
    heureArrivee    VARCHAR2(5)     NOT NULL,
    dateDepart      DATE            NOT NULL,
    heureDepart     VARCHAR2(5)     NOT NULL,
    nomContact      VARCHAR2(15)    NOT NULL,
    telContact      VARCHAR2(10)    NOT NULL,
    emailContact    VARCHAR2(30)   NOT NULL,
    tarifHS         NUMBER(8,2)     NOT NULL,
    tarifS          NUMBER(8,2)     NOT NULL,
    CONSTRAINT chk_sejour
        CHECK (type IN ('Theme', 'Liberte')
        AND dateDepart>=dateArrivee)
);


-------------------------------------------------------------------
-- 5. RESERVATION & PAIEMENT
-------------------------------------------------------------------

CREATE TABLE RESERVATION (
    numero          NUMBER(8)       CONSTRAINT pk_reservation PRIMARY KEY,
    dateRes         DATE            NOT NULL,
    nbrePers        NUMBER(4)       NOT NULL,
    codeClient      NUMBER(6)       NOT NULL,
    codeSejour      VARCHAR2(8),
    CONSTRAINT fk_res_client
        FOREIGN KEY (codeClient) REFERENCES CLIENT(code),
    CONSTRAINT fk_res_sejour
        FOREIGN KEY (codeSejour) REFERENCES SEJOUR(code)
);

CREATE TABLE PAIEMENT (
    code            NUMBER(8)       CONSTRAINT pk_paiement PRIMARY KEY,
    datePaiement    DATE            NOT NULL,
    montant         NUMBER(10,2)    NOT NULL,
    type            VARCHAR2(20)    NOT NULL,
    codeRes         NUMBER(8)       NOT NULL,
    codeModeReg     NUMBER(4)       NOT NULL,
    CONSTRAINT fk_paie_reservation
        FOREIGN KEY (codeRes) REFERENCES RESERVATION(numero),
    CONSTRAINT fk_paie_modereg
        FOREIGN KEY (codeModeReg) REFERENCES MODEREGLEMENT(code)
);


-------------------------------------------------------------------
-- 6. TABLES DES ASSOCIATIONS
-------------------------------------------------------------------

-- 1. LOUER

CREATE TABLE LOUER (
    numRes          NUMBER(8)       NOT NULL,
    codeChambre     NUMBER(4)       NOT NULL,
    codeSaison      VARCHAR2(2)     NOT NULL,
    dateDebSai      DATE            NOT NULL,
    dateFinSai      DATE            NOT NULL,
    dateDebLoc      DATE            NOT NULL,
    dateFinLoc      DATE            NOT NULL,
    litsSupp        NUMBER(2)       DEFAULT 0 NOT NULL,
    CONSTRAINT pk_louer
        PRIMARY KEY (numRes, codeChambre, codeSaison, dateDebSai, dateFinSai),
    CONSTRAINT fk_louer_reservation
        FOREIGN KEY (numRes) REFERENCES RESERVATION(numero),
    CONSTRAINT fk_louer_chambre
        FOREIGN KEY (codeChambre) REFERENCES CHAMBRE(code),
    CONSTRAINT fk_louer_saison
        FOREIGN KEY (codeSaison, dateDebSai, dateFinSai)
        REFERENCES SAISON(code, dateDebSai, dateFinSai),
    CONSTRAINT ck_louer_litssupp
        CHECK (litsSupp >= 0 AND litsSupp <= 3)
);


-- 2. CLASSER

CREATE TABLE CLASSER (
    codeSejour      VARCHAR2(8)       NOT NULL,
    codeThematique  NUMBER(4)       NOT NULL,
    CONSTRAINT pk_classer
        PRIMARY KEY (codeSejour, codeThematique),
    CONSTRAINT fk_classer_sejour
        FOREIGN KEY (codeSejour) REFERENCES SEJOUR(code),
    CONSTRAINT fk_classer_thematique
        FOREIGN KEY (codeThematique) REFERENCES THEMATIQUE(code)
);


-- 3. PLANIFIER

CREATE TABLE PLANIFIER (
    codePeriode         VARCHAR2(7)       NOT NULL,
    codeSejour          VARCHAR2(8)       NOT NULL,
    libelleProgramme    VARCHAR2(40)   NOT NULL,
    CONSTRAINT pk_planifier
        PRIMARY KEY (codePeriode, codeSejour),
    CONSTRAINT fk_planifier_periode
        FOREIGN KEY (codePeriode) REFERENCES PERIODE(code),
    CONSTRAINT fk_planifier_sejour
        FOREIGN KEY (codeSejour) REFERENCES SEJOUR(code)
);
