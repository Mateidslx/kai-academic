/*
 Programme : testTrisTableauxEntiers
 But :  Tester les sous-programmes de la bibliothèque triTableauxEntiers
 Date de dernière modification : 16/11/2025
 Auteur : Pantxika Dagorret
 Référence : R1.01-partie2 - feuille de TD n°1
*/

#include <iostream>
using namespace std;

/*---------------------------------------------------------------*/
/*  Déclarations des éléments et sous-programmes communs aux tests
  ---------------------------------------------------------------*/
const unsigned int TAILLE = 10; // taille des tableaux du module

void afficher(int tab[], unsigned int lgTab);
/* But : affiche à l'écran le contenu du carré tableau de lgTab entiers */

/*---------------------------------------------------------*/
/*  Déclarations des sous-programmes servant à faire les tests
  ---------------------------------------------------------*/
void testTriBulle_entiers();
// test du sous-programme triBulle() du module

void testTriParInsertion_entiers();
// test du sous-programme triParInsertion() du module

void testTriParSelectionDePlace_entiers();
// test du sous-programme triParSelectionDePlace() du module

/*-------------------------*/
/* MAIN
---------------------------*/
int main()
{
    /* TODO:
                    appel à décommenter selon l'avancement de votre codage */

    cout << "Programme testant des tris de tableaux d'entiers " << endl << endl ; 
    // testTriBulle_entiers();
    // testTriParInsertion_entiers();
    // testTriParSelectionDePlace_entiers();
    return 0;
}

/*  ---------------------------------------------------*/
/* Corps des sous-programmes servant à faire les tests
 -----------------------------------------------------*/

void testTriBulle_entiers()
{
	/* Stratégie : les tableaux à tester sont dans des éléments différents.
                   Il faudra donc dupliquer le code pour reproduire le test de chaque tableau --> mauvaise pratique.
                   Voir la stratégie des autres sous-programmes de test.
    */
	
    const unsigned int TAILLE = 10;
	
    int tableau1[TAILLE] = { 7, -6, 8, 10, 2, -3, 6, 9, 0, 2 }; // non trié au hasard
    int tableau2[TAILLE] = { -6, -3, 0, 2, 2, 6, 7, 8, 9, 10 }; // déjà trié croissant
    int tableau3[TAILLE] = { 10, 9, 8, 7, 6, 2, 1, 0, -3, -6 }; // trié à l'envers, sans doublons (= décroissant)
    int tableau4[TAILLE] = { 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 }; // constant

    cout << " ------------------   TRI BULLE croissant - tableau d'ENTIERS --------------" << endl
         << endl;

    // ---------tableau 1
    // afficher tableau avant le tri
    cout << "Avant tri BULLE croissant, tableau = ";
    afficher(tableau1, TAILLE);

    // tableau, TAILLE >> triBulle >> tableau
    //  triBulle(tableau1, TAILLE) ;                      //TODO: à décommenter

    // afficher tableau après le tri
    cout << "Apres tri BULLE croissant, tableau = ";
    afficher(tableau1, TAILLE);
    cout << endl;
}

void testTriParInsertion_entiers()
{
    /* Stratégie : les 4 tableaux sont rangés dans un tableau.
                   Le dernier appel teste le comportement du tri d'un tableau de taille nulle 
				   */

    const unsigned int TAILLE = 10;
    const unsigned NB_TABLEAUX = 4;

    cout << " ------------------   TRI PAR INSERTION croissant - tableau d'ENTIERS --------------" << endl
         << endl;
    int tableauxEntiers[NB_TABLEAUX][TAILLE] = {
        { 7, -6, 8, 10, 2, -3, 6, 9, 0, 2 }, // non trié au hasard
        { -6, -3, 0, 2, 2, 6, 7, 8, 9, 10 }, // déjà trié croissant
        { 10, 9, 8, 7, 6, 2, 1, 0, -3, -6 }, // trié à l'envers, sans doublons (= décroissant)
        { 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 } // constant
    };

    string messageAvantTri = "Avant tri PAR INSERTION croissant, tableau ";
    string messageApresTri = "Apres tri PAR INSERTION croissant, tableau ";

    for (unsigned int i = 0; i < NB_TABLEAUX; i++)
    {
        cout << messageAvantTri << i + 1 << " = ";
        afficher(tableauxEntiers[i], TAILLE);
        // triParInsertion(tableauxEntiers[i], TAILLE);    // TODO: à décommenter
        cout << messageApresTri << i + 1 << " = ";
        afficher(tableauxEntiers[i], TAILLE);
        cout << endl;
    }

    // tester le tri d'un tableau de taille nulle
    cout << messageAvantTri << 5 << " = ";
    afficher(tableauxEntiers[0], 0);
    // triParInsertion(tableauxEntiers[0], 0);            // TODO: à décommenter
    cout << messageApresTri << 5 << " = ";
    afficher(tableauxEntiers[0], 0);

    cout << endl;
}

void testTriParSelectionDePlace_entiers()
{
    /* Stratégie : les 4 tableaux sont rangés dans un tableau.
                   Le dernier appel teste le comportement du tri d'un tableau de taille nulle 
				   */

    const unsigned int TAILLE = 10;
    const unsigned NB_TABLEAUX = 4;

    cout << " ------------------   TRI PAR SELECTION DE PLACE croissant - tableau d'ENTIERS --------------" << endl
         << endl;
    int tableauxEntiers[NB_TABLEAUX][TAILLE] = {
        { 7, -6, 8, 10, 2, -3, 6, 9, 0, 2 }, // non trié au hasard
        { -6, -3, 0, 2, 2, 6, 7, 8, 9, 10 }, // déjà trié croissant
        { 10, 9, 8, 7, 6, 2, 1, 0, -3, -6 }, // trié à l'envers, sans doublons (= décroissant)
        { 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 } // constant
    };

    string messageAvantTri = "Avant tri PAR SELECTION DE PLACE croissant, tableau ";
    string messageApresTri = "Apres tri PAR SELECTION DE PLACE croissant, tableau ";

    for (unsigned int i = 0; i < NB_TABLEAUX; i++)
    {
        cout << messageAvantTri << i + 1 << " = ";
        afficher(tableauxEntiers[i], TAILLE);
        // triParSelectionDePlace(tableauxEntiers[i], TAILLE);            // TODO: à décommenter
        cout << messageApresTri << i + 1 << " = ";
        afficher(tableauxEntiers[i], TAILLE);
        cout << endl;
    }
    // tester le tri d'un tableau de taille nulle
    cout << messageAvantTri << 5 << " = ";
    afficher(tableauxEntiers[0], 0);
    // triParSelectionDePlace(tableauxEntiers[0], 0);            // TODO: à décommenter
    cout << messageApresTri << 5 << " = ";
    afficher(tableauxEntiers[0], 0);

    cout << endl;
}

/*=========================================================================================
  PRIMITIVES d'ENTREE / SORTIE
  =========================================================================================*/
void afficher(int tab[], unsigned int lgTab)
{
    if (lgTab > 0)
    {
        cout << "{";
        for (unsigned short int i = 0; i < lgTab - 1; i++)
        {
            cout << tab[i] << ", ";
        };
        cout << tab[lgTab - 1] << "} " << endl;
    }
    else
    {
        cout << "tableau vide " << endl;
    }
}