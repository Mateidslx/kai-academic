/**
 * Fichier : main.cpp
 * But : Programme de prise en main de la notion de module
 *       v0 : le programme complet (sous-programme et main) implanté dans 1 seul fichier
 * Auteur : Pantxika Dagorret
 * date : 16-11-2025
 * Référence : feuille de TD n°1, exercice 1
 */


void sp1(); // But : affiche le message : sous-programme 1
void sp2(); // But : affiche le message : sous-programme 2

int main (void)
{
    std::cout << "debut de main() " << std::endl;
    sp1();
    sp2();
    std::cout << "fin de main() " << std::endl;
    return 0;
}

void sp1()
{
    std::cout << "sous-programme 1" << std::endl;
}

void sp2()
{
    std::cout << "sous-programme 2" << std::endl;
}