/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 1 / 2 / 3 (à adapter selon l'affectation Elearn)
 * Numéro de l'exercice : 2 (Ceinture Jaune)
 * But de l'exercice : 
 * Modèle(s) d'algorithme(s) choisi(s) : 
 * Brève justification du ou des modèles choisis : 
 * Remarques éventuelles : 
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES

    // VARIABLES

    // TRAITEMENTS

    return 0;
}
