/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèle 1)
 * Numéro de l'exercice : 1 (Ceinture Blanche)
 * But de l'exercice : Saisir deux entiers, les trier par ordre croissant par échange et les afficher.
 * Modèle(s) d'algorithme(s) choisi(s) : L'échange de deux valeurs
 * Brève justification du ou des modèles choisis : La permutation sans perte d'information de deux variables nécessite une troisième variable temporaire (copieVal1).
 * Remarques éventuelles : Conforme aux conventions de nommage camelCase et typage strict R1.01/S1.01.
 */
#include <iostream>
using namespace std;

int main()
{
    //VARIABLES
    int val1;      // Première valeur entière saisie par l'utilisateur
    int val2;      // Seconde valeur entière saisie par l'utilisateur
    int copieVal1; // Variable temporaire permettant l'échange de val1 et val2

    // TRAITEMENTS
    // Saisir les deux valeurs entières
    cout << "Entrez la premiere valeur entiere : ";
    cin >> val1;
    cout << "Entrez la seconde valeur entiere : ";
    cin >> val2;

    // Ordonner val1 et val2 par ordre croissant si nécessaire (Modèle : Échange de 2 valeurs)
    if (val1 > val2)
    {
        copieVal1 = val1;
        val1 = val2;
        val2 = copieVal1;
    }

    // Afficher les valeurs ordonnées
    cout << "Valeurs par ordre croissant : " << val1 << " <= " << val2 << endl;

    return 0;
}
