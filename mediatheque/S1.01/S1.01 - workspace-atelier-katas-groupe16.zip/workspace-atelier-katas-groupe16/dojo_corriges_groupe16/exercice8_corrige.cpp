/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèle 5 adapté - TD7 Ex. 8)
 * Numéro de l'exercice : 8 (Ceinture Marron)
 * But de l'exercice : Déterminer si une chaîne de caractères est un palindrome sans parcourir inutilement toute la chaîne en cas d'échec.
 * Modèle(s) d'algorithme(s) choisi(s) : La recherche de première occurrence
 * Brève justification du ou des modèles choisis : On recherche la première occurrence d'une différence entre mot[posGauche] et son symétrique mot[posDroite]. Dès qu'une différence est trouvée, on arrête immédiatement la boucle.
 * Remarques éventuelles : Seuil de validation Ceinture Marron en défense collective >= 16,01 / 20.
 */
#include <iostream>
#include <string>
using namespace std;

int main()
{
    // VARIABLES
    string mot;                  // Mot en minuscules à analyser
    unsigned int nbCaracteres;   // Nombre total de caractères du mot
    unsigned int posGauche;      // Indice courant partant du début du mot
    unsigned int posDroite;      // Indice symétrique partant de la fin du mot
    bool differenceTrouvee;      // Indique si deux lettres symétriques différentes ont été détectées

    // TRAITEMENTS
    // Initialiser le mot à tester
    mot = "kayak";
    nbCaracteres = static_cast<unsigned int>(mot.size());

    // Initialiser la recherche de première discordance
    differenceTrouvee = false;
    posGauche = 0;

    // Parcourir tant qu'aucune différence n'est trouvée et que la moitié n'est pas dépassée
    while ((!differenceTrouvee) && (posGauche < (nbCaracteres / 2)))
    {
        posDroite = nbCaracteres - 1 - posGauche;
        if (mot[posGauche] != mot[posDroite])
        {
            differenceTrouvee = true;
        }
        else
        {
            posGauche = posGauche + 1;
        }
    }

    // Conclure sur la nature palindromique du mot
    if (!differenceTrouvee)
    {
        cout << "Le mot '" << mot << "' EST un palindrome." << endl;
    }
    else
    {
        cout << "Le mot '" << mot << "' N'EST PAS un palindrome (difference en position "
             << posGauche << ")." << endl;
    }

    return 0;
}
