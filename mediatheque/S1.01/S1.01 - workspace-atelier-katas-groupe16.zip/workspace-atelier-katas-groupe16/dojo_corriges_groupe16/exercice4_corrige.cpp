/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèle 4 - TD7 Ex. 2 & 3)
 * Numéro de l'exercice : 4 (Ceinture Orange)
 * But de l'exercice : Compter et incrémenter de 1 toutes les valeurs strictement négatives d'un tableau d'entiers.
 * Modèle(s) d'algorithme(s) choisi(s) : Le parcours complet avec traitement conditionné
 * Brève justification du ou des modèles choisis : Il faut examiner l'intégralité du tableau mais n'appliquer le comptage et l'incrémentation que lorsque la case courante est strictement négative.
 * Remarques éventuelles : Combine les exercices 2 et 3 du TD7 R1.01 de M. Etcheverry.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int NB_RELEVES = 12; // Nombre de relevés thermiques dans le tableau

    // VARIABLES
    short int temperatures[NB_RELEVES] = {4, -3, 0, -1, 7, -5, 12, 8, -2, 3, 0, -4}; // Relevés de températures en °C
    unsigned short int nbNegatives; // Compteur de températures strictement négatives avant correction
    unsigned short int i;           // Indice de parcours du tableau temperatures

    // TRAITEMENTS
    // Parcourir le tableau pour compter et incrémenter les valeurs négatives
    nbNegatives = 0;
    for (i = 0; i <= NB_RELEVES - 1; i++)
    {
        if (temperatures[i] < 0)
        {
            nbNegatives = nbNegatives + 1;
            temperatures[i] = temperatures[i] + 1;
        }
    }

    // Afficher le bilan du traitement
    cout << "Nombre de valeurs strictement negatives detectees : " << nbNegatives << endl;

    return 0;
}
