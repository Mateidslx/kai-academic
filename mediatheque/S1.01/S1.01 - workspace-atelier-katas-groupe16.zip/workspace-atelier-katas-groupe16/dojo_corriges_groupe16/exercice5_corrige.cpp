/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèles 2 + 4 - TD7/TP7 Ex. 5)
 * Numéro de l'exercice : 5 (Ceinture Orange-Verte)
 * But de l'exercice : Saisir un numéro de groupe de TP valide et compter combien d'étudiants de la promotion y sont inscrits.
 * Modèle(s) d'algorithme(s) choisi(s) : La saisie-vérification d'une valeur + Le parcours complet avec traitement conditionné
 * Brève justification du ou des modèles choisis : Saisie-vérification pour contrôler le numéro de TP saisi, puis parcours complet conditionné du tableau d'enregistrements Etudiant pour incrémenter l'effectif lorsque promo[i].tp vaut le groupe recherché.
 * Remarques éventuelles : Utilise le jeu de données officiel promo[EFFECTIF_PROMO] du TP7 R1.01.
 */
#include <iostream>
#include <string>
using namespace std;

// Définition du type Etudiant
struct Etudiant
{
    string nom;             // Nom de l'étudiant
    string prenom;          // Prénom de l'étudiant
    unsigned short int td;  // Numéro de groupe de TD de l'étudiant
    unsigned short int tp;  // Numéro de groupe de TP de l'étudiant
};

int main()
{
    // CONSTANTES
    const unsigned int EFFECTIF_PROMO = 15;     // Nombre d'étudiants enregistrés dans la promotion
    const unsigned short int NUM_TP_MIN = 1;    // Numéro minimal de groupe de TP
    const unsigned short int NUM_TP_MAX = 4;    // Numéro maximal de groupe de TP

    // VARIABLES
    Etudiant promo[EFFECTIF_PROMO] = {
        {"Attan", "Charles", 1, 1},
        {"Terrieur", "Alain", 1, 2},
        {"Touille", "Sacha", 1, 1},
        {"Ompagne", "Jacques", 2, 3},
        {"Cue", "Eva", 1, 2},
        {"Bonneau", "Jean", 1, 1},
        {"Zion", "Eva", 2, 3},
        {"Dy", "Sam", 2, 4},
        {"Xelaire", "Jacques", 2, 3},
        {"Ple", "Sam", 2, 4},
        {"Inter", "Roger", 2, 4},
        {"Masse", "Laly", 5, 1},
        {"Dy", "Alain", 5, 1},
        {"Bole", "Maguy", 5, 1},
        {"Serien", "Jean", 2, 3}
    }; // Tableau contenant les étudiants de la promotion
    short int numTpRecherche;        // Numéro du groupe de TP à analyser saisi au clavier
    unsigned int effectifGroupeTp;   // Compteur d'étudiants inscrits dans le groupe numTpRecherche
    unsigned int i;                  // Indice de parcours du tableau promo

    // TRAITEMENTS
    // 1. Saisir-vérifier le numéro du groupe de TP à analyser (Modèle : Saisie-vérification)
    for ( ; ; )
    {
        cout << "Entrez le numero du groupe de TP a analyser (" << NUM_TP_MIN << " a " << NUM_TP_MAX << ") : ";
        cin >> numTpRecherche;

        if ((numTpRecherche >= NUM_TP_MIN) && (numTpRecherche <= NUM_TP_MAX))
        {
            break;
        }
        cout << "Valeur incorrecte. Veuillez saisir un numero entre " << NUM_TP_MIN << " et " << NUM_TP_MAX << "." << endl;
    }

    // 2. Compter les étudiants appartenant au groupe numTpRecherche (Modèle : Parcours complet conditionné)
    effectifGroupeTp = 0;
    for (i = 0; i <= EFFECTIF_PROMO - 1; i++)
    {
        if (promo[i].tp == static_cast<unsigned short int>(numTpRecherche))
        {
            effectifGroupeTp = effectifGroupeTp + 1;
        }
    }

    // 3. Afficher le résultat
    cout << "Effectif du groupe TP" << numTpRecherche << " : " << effectifGroupeTp << " etudiant(s)." << endl;

    return 0;
}
