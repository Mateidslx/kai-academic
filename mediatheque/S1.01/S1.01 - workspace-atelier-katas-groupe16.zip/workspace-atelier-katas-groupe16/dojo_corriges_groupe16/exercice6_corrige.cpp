/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèle 5 - Cours 07 & TD7 Ex. 7a)
 * Numéro de l'exercice : 6 (Ceinture Verte)
 * But de l'exercice : Afficher la position de la première voyelle d'une chaîne de caractères.
 * Modèle(s) d'algorithme(s) choisi(s) : La recherche de première occurrence
 * Brève justification du ou des modèles choisis : Le parcours doit s'arrêter immédiatement dès que la première voyelle est localisée ou lorsque la fin de la chaîne est atteinte.
 * Remarques éventuelles : Conforme au diaporama 07-modeles-algos-basiques (slides 25 à 38) de M. Etcheverry.
 */
#include <iostream>
#include <string>
using namespace std;

int main()
{
    // VARIABLES
    string mot;              // Chaîne de caractères dans laquelle on recherche une voyelle
    unsigned int posCourante; // Position courante d'inspection dans la chaîne mot
    unsigned int nbCaracteres; // Longueur totale de la chaîne mot
    bool trouve;             // Indique si une première voyelle a été trouvée
    char carCourant;         // Caractère courant inspecté à la position posCourante

    // TRAITEMENTS
    // Initialiser la chaîne à analyser
    mot = "algorithmique";
    nbCaracteres = static_cast<unsigned int>(mot.size());

    // Initialiser la recherche sur le premier caractère (Modèle : Recherche de 1re occurrence)
    trouve = false;
    posCourante = 0;

    // Effectuer la recherche tant qu'on n'a pas trouvé et qu'il reste des caractères
    while ((!trouve) && (posCourante < nbCaracteres))
    {
        carCourant = mot[posCourante];
        if ((carCourant == 'a') || (carCourant == 'e') || (carCourant == 'i') ||
            (carCourant == 'o') || (carCourant == 'u') || (carCourant == 'y'))
        {
            trouve = true;
        }
        else
        {
            posCourante = posCourante + 1;
        }
    }

    // Déterminer et afficher le résultat de la recherche
    if (trouve)
    {
        cout << "Premiere voyelle '" << mot[posCourante]
             << "' trouvee a la position (indice) : " << posCourante << endl;
    }
    else
    {
        cout << "Aucune voyelle n'est presente dans le mot : " << mot << endl;
    }

    return 0;
}
