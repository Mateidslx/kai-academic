/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèles 3 adapté + 1 - TD7 Ex. 6)
 * Numéro de l'exercice : 7 (Ceinture Bleue)
 * But de l'exercice : Inverser sur place les valeurs entières d'un tableau puis afficher le résultat.
 * Modèle(s) d'algorithme(s) choisi(s) : Le parcours complet avec traitement systématique (adapté sur demi-tableau) + L'échange de deux valeurs
 * Brève justification du ou des modèles choisis : Chaque élément de la première moitié du tableau (0 à NB_CASES/2 - 1) est systématiquement échangé avec son élément symétrique (NB_CASES - 1 - i) grâce au modèle d'échange de deux valeurs.
 * Remarques éventuelles : Seuil de validation Ceinture Bleue en défense collective >= 15,01 / 20.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int NB_CASES = 7; // Nombre d'éléments du tableau à inverser

    // VARIABLES
    int valeurs[NB_CASES] = {10, 20, 30, 40, 50, 60, 70}; // Tableau d'entiers à inverser sur place
    int copieValeur;             // Variable temporaire pour l'échange de deux cases symétriques
    unsigned short int i;        // Indice de parcours du tableau
    unsigned short int indSym;   // Indice de la case symétrique par rapport au milieu du tableau

    // TRAITEMENTS
    // 1. Parcourir la première moitié du tableau et échanger les cases symétriques
    for (i = 0; i <= (NB_CASES / 2) - 1; i++)
    {
        indSym = NB_CASES - 1 - i;

        // Modèle : Échange de deux valeurs entre valeurs[i] et valeurs[indSym]
        copieValeur = valeurs[i];
        valeurs[i] = valeurs[indSym];
        valeurs[indSym] = copieValeur;
    }

    // 2. Afficher le tableau inversé (Modèle : Parcours complet avec traitement systématique)
    cout << "Tableau inverse : ";
    for (i = 0; i <= NB_CASES - 1; i++)
    {
        cout << valeurs[i] << " ";
    }
    cout << endl;

    return 0;
}
