/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèles combinés - Référence code-explorer/etudiant001.cpp)
 * Numéro de l'exercice : 9 (Ceinture Noire)
 * But de l'exercice : Partitionner sur place un tableau d'entiers en plaçant les nombres pairs en tête et les nombres impairs en fin de tableau.
 * Modèle(s) d'algorithme(s) choisi(s) : Le parcours complet avec traitement conditionné (adapté à deux indices convergents) + L'échange de deux valeurs
 * Brève justification du ou des modèles choisis : Tous les éléments doivent être examinés jusqu'au croisement des indices indPair et indImpair ; si tab[indPair] est impair, on applique le modèle d'échange de deux valeurs avec tab[indImpair] et on recule indImpair.
 * Remarques éventuelles : Seuil de validation Ceinture Noire en défense collective >= 18,01 / 20 ! Code corrigé sans les défauts de nommage/typage de etudiant001.cpp.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int NB_CASES = 10; // Nombre d'éléments du tableau à partitionner

    // VARIABLES
    int tabValeurs[NB_CASES] = {15, 12, 8, 9, 4, 17, 5, 13, 11, 14}; // Tableau d'entiers à trier (pairs à gauche, impairs à droite)
    unsigned short int indPair;   // Indice courant de progression des valeurs paires (depuis le début)
    unsigned short int indImpair; // Indice courant de placement des valeurs impaires (depuis la fin)
    int copieValeur;              // Variable temporaire permettant l'échange de deux cases
    unsigned short int i;         // Indice d'affichage final du tableau

    // TRAITEMENTS
    // 1. Initialiser les deux indices aux extrémités du tableau
    indPair = 0;
    indImpair = NB_CASES - 1;

    // 2. Partitionner le tableau tant que les deux indices ne se sont pas rejoints
    while (indPair < indImpair)
    {
        if ((tabValeurs[indPair] % 2) == 0)
        {
            // La valeur est déjà paire : on avance la frontière gauche
            indPair = indPair + 1;
        }
        else
        {
            // La valeur est impaire : on l'échange avec tabValeurs[indImpair] (Modèle : Échange de 2 valeurs)
            copieValeur = tabValeurs[indPair];
            tabValeurs[indPair] = tabValeurs[indImpair];
            tabValeurs[indImpair] = copieValeur;

            // On recule la frontière droite des nombres impairs
            indImpair = indImpair - 1;
        }
    }

    // 3. Afficher le tableau partitionné (Modèle : Parcours complet systématique)
    cout << "Tableau partitionne (Pairs puis Impairs) : ";
    for (i = 0; i <= NB_CASES - 1; i++)
    {
        cout << tabValeurs[i] << " ";
    }
    cout << endl;

    return 0;
}
