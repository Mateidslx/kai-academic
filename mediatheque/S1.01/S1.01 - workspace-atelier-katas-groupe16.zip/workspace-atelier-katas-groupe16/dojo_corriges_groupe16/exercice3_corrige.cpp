/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèle 3 - Référence mainProf.cpp)
 * Numéro de l'exercice : 3 (Ceinture Jaune-Orange)
 * But de l'exercice : Calculer et afficher la moyenne des valeurs stockées dans un tableau de notes.
 * Modèle(s) d'algorithme(s) choisi(s) : Le parcours complet avec traitement systématique
 * Brève justification du ou des modèles choisis : Chaque note du tableau doit être additionnée systématiquement dans le cumul avant de diviser par l'effectif total.
 * Remarques éventuelles : Basé sur l'exemple de référence mainProf.cpp de M. Patrick Etcheverry.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int NB_NOTES = 10; // Nombre total de notes dans le tableau

    // VARIABLES
    float notesControle1[NB_NOTES] = {15.0, 12.5, 8.0, 9.0, 4.0, 17.0, 5.5, 13.0, 11.0, 14.0}; // Notes obtenues au 1er contrôle
    float cumulNotes;   // Cumul de toutes les notes du tableau notesControle1
    float moyenneNotes; // Moyenne arithmétique des notes du contrôle
    unsigned short int i; // Indice de parcours du tableau notesControle1

    // TRAITEMENTS
    // Calculer le cumul de toutes les notes du tableau (Modèle : Parcours complet systématique)
    cumulNotes = 0.0;
    for (i = 0; i <= NB_NOTES - 1; i++)
    {
        cumulNotes = cumulNotes + notesControle1[i];
    }

    // Calculer et afficher la moyenne des notes
    moyenneNotes = cumulNotes / NB_NOTES;
    cout << "Moyenne du controle : " << moyenneNotes << " / 20" << endl;

    return 0;
}
