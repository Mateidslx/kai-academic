/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata d'entraînement (Modèle 2)
 * Numéro de l'exercice : 2 (Ceinture Jaune)
 * But de l'exercice : Saisir et vérifier un numéro de groupe de TP compris entre 1 et 5 inclus.
 * Modèle(s) d'algorithme(s) choisi(s) : La saisie-vérification d'une valeur
 * Brève justification du ou des modèles choisis : Nombre de répétitions inconnu a priori avec message d'erreur avant rebouclage : structure Répéter...Jusqu'à avec sortie conditionnelle (for(;;) + break).
 * Remarques éventuelles : Utilisation de constantes nommées (zéro nombre magique).
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int NUM_TP_MIN = 1; // Numéro minimal de groupe de TP autorisé
    const unsigned short int NUM_TP_MAX = 5; // Numéro maximal de groupe de TP autorisé

    // VARIABLES
    short int numGroupeTp; // Numéro de groupe de TP saisi au clavier

    // TRAITEMENTS
    // Saisir-vérifier le numéro de groupe de TP dans [NUM_TP_MIN ; NUM_TP_MAX]
    for ( ; ; )
    {
        cout << "Entrez un numero de groupe de TP (" << NUM_TP_MIN << " a " << NUM_TP_MAX << ") : ";
        cin >> numGroupeTp;

        if ((numGroupeTp >= NUM_TP_MIN) && (numGroupeTp <= NUM_TP_MAX))
        {
            break;
        }

        cout << "Erreur : le numero de TP doit etre compris entre "
             << NUM_TP_MIN << " et " << NUM_TP_MAX << ". Recommencez." << endl;
    }

    // Afficher la valeur validée
    cout << "Groupe de TP valide retenu : TP" << numGroupeTp << endl;

    return 0;
}
