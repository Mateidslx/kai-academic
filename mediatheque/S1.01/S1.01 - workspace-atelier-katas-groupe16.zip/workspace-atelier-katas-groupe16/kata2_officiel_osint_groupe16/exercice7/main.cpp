/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 7 (Ceinture Bleue)
 * But de l'exercice : Saisir une valeur et afficher l'indice de sa dernière occurrence dans un tableau d'entiers.
 * Modèle(s) d'algorithme(s) choisi(s) : La recherche de première occurrence (en partant de la fin)
 * Brève justification du ou des modèles choisis : En démarrant la recherche par la dernière case (TAILLE_TAB - 1) et en reculant vers 0, on s'arrête dès que la cible est trouvée.
 * Remarques éventuelles : posCourante est typé en short int (signé) pour que la condition posCourante >= 0 s'arrête proprement à -1 lorsque la valeur est absente (évite le piège du wrap-around unsigned !).
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int TAILLE_TAB = 6; // Nombre d'éléments du tableau

    // VARIABLES
    int tabEntiers[TAILLE_TAB] = {20, 15, 10, 0, 15, 5}; // Tableau d'entiers dans lequel effectuer la recherche
    int valRecherchee;      // Valeur recherchée saisie par l'utilisateur
    short int posCourante;  // Indice courant partant de la fin (signé pour tester posCourante >= 0)
    bool trouve;            // Indique si valRecherchee a été localisée

    // TRAITEMENTS
    // 1. Saisir la valeur recherchée >> valRecherchee
    cout << "Quelle valeur recherchez-vous ? ";
    cin >> valRecherchee;

    // 2. Initialiser la recherche sur la dernière case du tableau >> trouve, posCourante
    trouve = false;
    posCourante = static_cast<short int>(TAILLE_TAB) - 1;

    // 3. tabEntiers, valRecherchee >> Rechercher la 1re occurrence en partant de la fin >> trouve, posCourante
    while ((!trouve) && (posCourante >= 0))
    {
        if (tabEntiers[posCourante] == valRecherchee)
        {
            trouve = true;
        }
        else
        {
            posCourante = posCourante - 1;
        }
    }

    // 4. trouve, posCourante >> Afficher le résultat >> (écran)
    if (trouve)
    {
        cout << "Derniere occurrence de " << valRecherchee << " trouvee a l'indice : " << posCourante << endl;
    }
    else
    {
        cout << "La valeur " << valRecherchee << " n'est pas dans le tableau." << endl;
    }

    return 0;
}
