/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 5 (Ceinture Orange-Verte)
 * But de l'exercice : Rechercher et remplacer un caractère uniquement dans les 9 premiers caractères d'une phrase.
 * Modèle(s) d'algorithme(s) choisi(s) : Le parcours complet avec traitement conditionné
 * Brève justification du ou des modèles choisis : Plusieurs occurrences pouvant exister parmi les 9 premiers caractères, on parcourt toutes les positions de 0 à LIMITE - 1 en remplaçant conditionnellement les caractères égaux à charAModifier.
 * Remarques éventuelles : Un booléen remplacementEffectue permet de distinguer l'affichage final.
 */
#include <iostream>
#include <string>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int LIMITE = 9; // Nombre de premiers caractères de la phrase à inspecter

    // VARIABLES
    string phrase = "Trop de boucles, tue la boucle"; // Phrase soumise au remplacement partiel
    char charAModifier;         // Caractère recherché à remplacer
    char charRemplacant;        // Nouveau caractère de remplacement
    bool remplacementEffectue;  // Indique si au moins une occurrence a été trouvée et remplacée
    unsigned short int i;       // Indice de parcours des LIMITE premiers caractères

    // TRAITEMENTS
    // 1. Saisir le caractère à modifier et le caractère de remplacement >> charAModifier, charRemplacant
    cout << "Saisissez le caractere a modifier : ";
    cin >> charAModifier;
    cout << "Saisissez le caractere de remplacement : ";
    cin >> charRemplacant;

    // 2. phrase, LIMITE, charAModifier, charRemplacant >> Remplacer dans les 9 premiers caractères >> phrase, remplacementEffectue
    remplacementEffectue = false;
    for (i = 0; i <= LIMITE - 1; i++)
    {
        if (phrase[i] == charAModifier)
        {
            phrase[i] = charRemplacant;
            remplacementEffectue = true;
        }
    }

    // 3. remplacementEffectue, phrase >> Afficher le résultat >> (écran)
    if (remplacementEffectue)
    {
        cout << "Phrase modifiee : " << phrase << endl;
    }
    else
    {
        cout << "Aucune occurrence trouvee dans les " << LIMITE << " premiers caracteres." << endl;
    }

    return 0;
}
