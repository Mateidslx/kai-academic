/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 4 (Ceinture Orange)
 * But de l'exercice : Afficher uniquement les valeurs strictement positives d'un tableau d'entiers.
 * Modèle(s) d'algorithme(s) choisi(s) : Le parcours complet avec traitement conditionné
 * Brève justification du ou des modèles choisis : Toutes les cases du tableau doivent être examinées de 0 à TAILLE_TAB - 1, mais seules celles vérifiant tabEntiers[i] > 0 sont affichées.
 * Remarques éventuelles : Typage précis unsigned short int pour la taille et l'indice de parcours croissant.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int TAILLE_TAB = 6; // Nombre de cases du tableau d'entiers

    // VARIABLES
    int tabEntiers[TAILLE_TAB] = {12, -5, 0, 15, -3, 20}; // Tableau d'entiers contenant des valeurs positives, nulles et négatives
    unsigned short int i; // Indice de parcours du tableau tabEntiers

    // TRAITEMENTS
    // tabEntiers, TAILLE_TAB >> Afficher uniquement les valeurs strictement positives >> (écran)
    for (i = 0; i <= TAILLE_TAB - 1; i++)
    {
        if (tabEntiers[i] > 0)
        {
            cout << tabEntiers[i] << endl;
        }
    }

    return 0;
}
