/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 8 (Ceinture Marron)
 * But de l'exercice : Vérifier et afficher si toutes les valeurs d'un tableau sont de signe opposé à la valeur précédente.
 * Modèle(s) d'algorithme(s) choisi(s) : La recherche de première occurrence
 * Brève justification du ou des modèles choisis : On recherche la première occurrence d'une anomalie (deux cases consécutives tabEntiers[posCourante] et tabEntiers[posCourante - 1] ayant le même signe) à partir de l'indice 1.
 * Remarques éventuelles : Deux nombres sont de signes strictement opposés si et seulement si leur produit est strictement négatif (< 0).
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int TAILLE_TAB = 6; // Nombre d'éléments du tableau à vérifier

    // VARIABLES
    int tabEntiers[TAILLE_TAB] = {1, -1, 1, -1, 1, -1}; // Tableau d'entiers dont on vérifie l'alternance de signe
    unsigned short int posCourante; // Indice courant d'inspection (démarre à 1 pour comparer avec posCourante - 1)
    bool anomalieTrouvee;           // Indique si deux valeurs consécutives de même signe ont été détectées

    // TRAITEMENTS
    // 1. Initialiser la recherche d'anomalie au deuxième élément (indice 1) >> anomalieTrouvee, posCourante
    anomalieTrouvee = false;
    posCourante = 1;

    // 2. tabEntiers, TAILLE_TAB >> Rechercher la 1re paire consécutive de même signe >> anomalieTrouvee, posCourante
    while ((!anomalieTrouvee) && (posCourante < TAILLE_TAB))
    {
        if ((tabEntiers[posCourante] * tabEntiers[posCourante - 1]) >= 0)
        {
            anomalieTrouvee = true;
        }
        else
        {
            posCourante = posCourante + 1;
        }
    }

    // 3. anomalieTrouvee, posCourante >> Afficher la conclusion >> (écran)
    if (!anomalieTrouvee)
    {
        cout << "Toutes les valeurs sont bien de signe oppose a la valeur precedente." << endl;
    }
    else
    {
        cout << "Condition non respectee a l'indice " << posCourante
             << " (valeurs consecutives : " << tabEntiers[posCourante - 1]
             << " et " << tabEntiers[posCourante] << ")." << endl;
    }

    return 0;
}
