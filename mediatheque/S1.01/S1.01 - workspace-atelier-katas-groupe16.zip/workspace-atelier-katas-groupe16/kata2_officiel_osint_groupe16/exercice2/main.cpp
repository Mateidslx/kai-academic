/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 2 (Ceinture Jaune)
 * But de l'exercice : Saisir deux indices valides et échanger les deux caractères correspondants dans la phrase "le compilateur est ta boussole".
 * Modèle(s) d'algorithme(s) choisi(s) : La saisie-vérification d'une valeur, L'échange de deux valeurs
 * Brève justification du ou des modèles choisis : La saisie-vérification garantit que ind1 et ind2 sont des indices valides de la chaîne, puis le modèle d'échange de deux valeurs permute phrase[ind1] et phrase[ind2] via une variable temporaire copieCaractere.
 * Remarques éventuelles : Indices non signés bornés par IND_MAX.
 */
#include <iostream>
#include <string>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int IND_MAX = 29; // Indice maximal valide dans la chaîne (longueur 30 : indices 0 à 29)

    // VARIABLES
    string phrase = "le compilateur est ta boussole"; // Phrase initiale à modifier
    unsigned short int ind1; // Premier indice de caractère saisi par l'utilisateur
    unsigned short int ind2; // Second indice de caractère saisi par l'utilisateur
    char copieCaractere;     // Variable temporaire pour l'échange de phrase[ind1] et phrase[ind2]

    // TRAITEMENTS
    // 1. Saisir et vérifier les deux indices ind1 et ind2 >> ind1, ind2
    for ( ; ; )
    {
        cout << "Saisissez le premier indice (entre 0 et " << IND_MAX << ") : ";
        cin >> ind1;
        cout << "Saisissez le second indice (entre 0 et " << IND_MAX << ") : ";
        cin >> ind2;

        if ((ind1 <= IND_MAX) && (ind2 <= IND_MAX))
        {
            break;
        }

        cout << "Valeur incorrecte, veuillez saisir deux indices inferieurs ou egaux a " << IND_MAX << "." << endl;
    }

    // 2. phrase, ind1, ind2 >> Échanger les caractères en ind1 et ind2 >> phrase
    copieCaractere = phrase[ind1];
    phrase[ind1] = phrase[ind2];
    phrase[ind2] = copieCaractere;

    // 3. phrase >> Afficher la phrase modifiée >> (écran)
    cout << "Nouvelle chaine : " << phrase << endl;

    return 0;
}
