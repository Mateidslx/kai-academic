/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 6 (Ceinture Verte)
 * But de l'exercice : Déterminer et afficher si le tableau contient au moins une fois la valeur 20.
 * Modèle(s) d'algorithme(s) choisi(s) : La recherche de première occurrence
 * Brève justification du ou des modèles choisis : Il suffit de trouver une seule occurrence de la valeur 20 pour conclure positivement et arrêter immédiatement le parcours.
 * Remarques éventuelles : Structure conforme au diaporama 07-modeles-algos-basiques de M. Etcheverry.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int TAILLE_TAB = 7; // Nombre d'éléments du tableau
    const int VAL_RECHERCHEE = 20;           // Valeur entière recherchée dans le tableau

    // VARIABLES
    int tabEntiers[TAILLE_TAB] = {20, 21, 22, 23, 24, 25, 26}; // Tableau d'entiers inspecté
    unsigned short int posCourante; // Indice courant d'inspection dans tabEntiers
    bool trouve;                    // Indique si VAL_RECHERCHEE a été trouvée

    // TRAITEMENTS
    // 1. Initialiser la recherche au premier élément >> trouve, posCourante
    trouve = false;
    posCourante = 0;

    // 2. tabEntiers, TAILLE_TAB, VAL_RECHERCHEE >> Rechercher la 1re occurrence >> trouve, posCourante
    while ((!trouve) && (posCourante < TAILLE_TAB))
    {
        if (tabEntiers[posCourante] == VAL_RECHERCHEE)
        {
            trouve = true;
        }
        else
        {
            posCourante = posCourante + 1;
        }
    }

    // 3. trouve, posCourante >> Afficher le résultat de la recherche >> (écran)
    if (trouve)
    {
        cout << "Le tableau contient la valeur " << VAL_RECHERCHEE
             << " (premiere occurrence a l'indice " << posCourante << ")." << endl;
    }
    else
    {
        cout << "Le tableau ne contient pas la valeur " << VAL_RECHERCHEE << "." << endl;
    }

    return 0;
}
