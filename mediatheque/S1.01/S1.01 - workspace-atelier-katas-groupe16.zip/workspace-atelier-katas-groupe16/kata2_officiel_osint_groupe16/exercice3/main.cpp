/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 3 (Ceinture Jaune-Orange)
 * But de l'exercice : Afficher un tableau de 6 entiers en commençant par la fin.
 * Modèle(s) d'algorithme(s) choisi(s) : Le parcours complet avec traitement systématique
 * Brève justification du ou des modèles choisis : Chaque case du tableau doit être affichée systématiquement en parcourant les indices de TAILLE_TAB - 1 jusqu'à 0 inclus.
 * Remarques éventuelles : L'indice i est typé en short int (signé) car la condition d'arrêt i >= 0 décrémente i jusqu'à -1 en fin de boucle.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int TAILLE_TAB = 6; // Nombre d'éléments du tableau d'entiers

    // VARIABLES
    int tabEntiers[TAILLE_TAB] = {5, 10, 15, 20, 25, 30}; // Tableau d'entiers à afficher à l'envers
    short int i; // Indice de parcours décroissant du tableau (signé pour permettre le test i >= 0)

    // TRAITEMENTS
    // tabEntiers, TAILLE_TAB >> Afficher chaque case de la dernière à la première >> (écran)
    for (i = static_cast<short int>(TAILLE_TAB) - 1; i >= 0; i--)
    {
        cout << tabEntiers[i] << endl;
    }

    return 0;
}
