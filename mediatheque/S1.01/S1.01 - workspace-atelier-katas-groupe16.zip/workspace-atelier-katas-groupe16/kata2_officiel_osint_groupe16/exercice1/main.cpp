/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 1 (Ceinture Blanche)
 * But de l'exercice : Saisir et vérifier une température en degrés Celsius comprise entre -30 et 50.
 * Modèle(s) d'algorithme(s) choisi(s) : La saisie-vérification d'une valeur
 * Brève justification du ou des modèles choisis : Il faut répéter la saisie tant que la température n'est pas comprise dans l'intervalle [-30 ; 50] en affichant un message d'erreur en cas de valeur hors bornes.
 * Remarques éventuelles : Conforme à l'arbre méthodologique R1.01 (for(;;) + break) et sans nombre magique.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const short int TEMP_MIN = -30; // Température minimale autorisée en degrés Celsius
    const short int TEMP_MAX = 50;  // Température maximale autorisée en degrés Celsius

    // VARIABLES
    short int temperature; // Température en degrés Celsius saisie par l'utilisateur

    // TRAITEMENTS
    // Saisir et vérifier la température dans [TEMP_MIN ; TEMP_MAX] >> temperature
    for ( ; ; )
    {
        cout << "Saisissez une temperature entre " << TEMP_MIN << " et " << TEMP_MAX << " : ";
        cin >> temperature;

        if ((temperature >= TEMP_MIN) && (temperature <= TEMP_MAX))
        {
            break;
        }

        cout << "Valeur incorrecte, veuillez saisir une temperature entre "
             << TEMP_MIN << " et " << TEMP_MAX << "." << endl;
    }

    // temperature >> Afficher la température validée >> (écran)
    cout << "Temperature valide : " << temperature << " °C" << endl;

    return 0;
}
