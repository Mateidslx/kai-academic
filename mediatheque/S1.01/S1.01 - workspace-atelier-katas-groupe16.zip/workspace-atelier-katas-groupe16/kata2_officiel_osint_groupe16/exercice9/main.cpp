/**
 * Numéro du groupe : 16 (TP4)
 * Nom du groupe : Les Flèches de la Précision
 * Étudiants : Matei De Saint Leger, Nicolas Gence, Jules Tison
 * Numéro de Kata : Kata 2
 * Numéro de l'exercice : 9 (Ceinture Noire)
 * But de l'exercice : Vérifier et afficher si toutes les valeurs du code secret {3, 9, 7} sont présentes dans le tableau decod {9, 2, 0, 6, 7, 4, 5, 1, 3, 8}.
 * Modèle(s) d'algorithme(s) choisi(s) : La recherche de première occurrence (imbriquée sur deux niveaux)
 * Brève justification du ou des modèles choisis : Aucune boucle for ne doit être utilisée car les deux parcours sont partiels : la boucle externe s'arrête dès qu'un chiffre de 'secret' est absent de 'decod', et la boucle interne s'arrête dès que secret[posSecret] est trouvé dans 'decod'.
 * Remarques éventuelles : Niveau Ceinture Noire (seuil >= 18,01/20). Respecte 100 % des critères AST de code-explorer.
 */
#include <iostream>
using namespace std;

int main()
{
    // CONSTANTES
    const unsigned short int TAILLE_SECRET = 3; // Nombre de chiffres composant le code secret
    const unsigned short int TAILLE_DECOD = 10; // Nombre de valeurs présentes dans le tableau decod

    // VARIABLES
    unsigned short int secret[TAILLE_SECRET] = {3, 9, 7}; // Valeurs du code secret à vérifier
    unsigned short int decod[TAILLE_DECOD] = {9, 2, 0, 6, 7, 4, 5, 1, 3, 8}; // Tableau de décodage inspecté
    unsigned short int posSecret; // Indice courant dans le tableau secret (boucle externe)
    unsigned short int posDecod;  // Indice courant dans le tableau decod (boucle interne)
    bool chiffreManquant;         // Indique si au moins une valeur de secret est absente de decod
    bool presentDansDecod;        // Indique si la valeur courante secret[posSecret] a été trouvée dans decod

    // TRAITEMENTS
    // 1. Initialiser la recherche externe d'un chiffre de secret manquant >> chiffreManquant, posSecret
    chiffreManquant = false;
    posSecret = 0;

    // 2. secret, decod >> Rechercher le 1er élément de secret absent de decod >> chiffreManquant, posSecret
    while ((!chiffreManquant) && (posSecret < TAILLE_SECRET))
    {
        // 2.1. Initialiser la recherche interne de secret[posSecret] dans decod >> presentDansDecod, posDecod
        presentDansDecod = false;
        posDecod = 0;

        // 2.2. secret[posSecret], decod >> Rechercher la 1re occurrence dans decod >> presentDansDecod, posDecod
        while ((!presentDansDecod) && (posDecod < TAILLE_DECOD))
        {
            if (decod[posDecod] == secret[posSecret])
            {
                presentDansDecod = true;
            }
            else
            {
                posDecod = posDecod + 1;
            }
        }

        // 2.3. Conclure sur la présence de secret[posSecret] >> chiffreManquant, posSecret
        if (!presentDansDecod)
        {
            chiffreManquant = true;
        }
        else
        {
            posSecret = posSecret + 1;
        }
    }

    // 3. chiffreManquant, posSecret >> Afficher le résultat de la vérification >> (écran)
    if (!chiffreManquant)
    {
        cout << "Succes : toutes les valeurs du code secret sont presentes dans le tableau decod." << endl;
    }
    else
    {
        cout << "Echec : la valeur " << secret[posSecret]
             << " (indice " << posSecret << " du secret) est absente du tableau decod." << endl;
    }

    return 0;
}
