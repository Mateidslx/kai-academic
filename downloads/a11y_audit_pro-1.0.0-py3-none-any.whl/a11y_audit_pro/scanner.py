# -*- coding: utf-8 -*-
"""HTML and DOM Accessibility Rules Engine."""
import re
from typing import Dict, Any, List

class HtmlA11yScanner:
    """Parses HTML documents and verifies WCAG 2.1 AAA accessibility rules."""

    def __init__(self):
        self.rules = [
            ("doc_lang", "Attribut 'lang' sur la balise <html>"),
            ("title_present", "Balise <title> descriptive"),
            ("viewport_zoomable", "Pas de 'user-scalable=no' ou 'maximum-scale=1'"),
            ("img_alt_tags", "Attribut 'alt' sur toutes les balises <img>"),
            ("heading_hierarchy", "Hiérarchie de titres sans saut illégal (h1 -> h2 -> h3)"),
            ("button_labels", "Boutons pourvus de libellé accessible ou aria-label"),
            ("links_accessible", "Liens avec texte descriptif explicite (évite 'cliquez ici')")
        ]

    def audit_html(self, html_content: str) -> Dict[str, Any]:
        """Performs a comprehensive accessibility scan on raw HTML."""
        findings: List[Dict[str, Any]] = []
        score = 100

        # 1. Lang attribute
        html_tag_match = re.search(r'<html[^>]*>', html_content, re.IGNORECASE)
        if not html_tag_match or 'lang=' not in html_tag_match.group(0).lower():
            score -= 10
            findings.append({
                "rule": "doc_lang",
                "severity": "CRITICAL",
                "message": "La balise <html> ne spécifie aucun attribut 'lang'.",
                "recommendation": "Ajouter lang='fr' ou lang='en' sur la balise racine <html>."
            })

        # 2. Page title
        title_match = re.search(r'<title[^>]*>(.*?)</title>', html_content, re.IGNORECASE | re.DOTALL)
        if not title_match or not title_match.group(1).strip():
            score -= 10
            findings.append({
                "rule": "title_present",
                "severity": "CRITICAL",
                "message": "Aucun titre de page (<title>) non vide n'a été détecté.",
                "recommendation": "Définir un titre clair et contextuel pour les lecteurs d'écran."
            })

        # 3. Viewport restrictions
        viewport_match = re.search(r'<meta[^>]*name=["\']viewport["\'][^>]*>', html_content, re.IGNORECASE)
        if viewport_match:
            vp_content = viewport_match.group(0).lower()
            if "user-scalable=no" in vp_content or "maximum-scale=1.0" in vp_content or "maximum-scale=1\"" in vp_content:
                score -= 20
                findings.append({
                    "rule": "viewport_zoomable",
                    "severity": "CRITICAL",
                    "message": "Le viewport bloque le zoom utilisateur (user-scalable=no ou maximum-scale=1).",
                    "recommendation": "Supprimer les restrictions de zoom pour permettre le grossissement à 200%+ (WCAG 1.4.4)."
                })

        # 4. Images alt attributes
        images = re.findall(r'<img[^>]*>', html_content, re.IGNORECASE)
        missing_alt = 0
        for img in images:
            if 'alt=' not in img.lower():
                missing_alt += 1
        if missing_alt > 0:
            score -= min(25, missing_alt * 5)
            findings.append({
                "rule": "img_alt_tags",
                "severity": "HIGH",
                "message": f"{missing_alt} image(s) sans attribut 'alt' détectée(s).",
                "recommendation": "Renseigner systématiquement un attribut alt explicite ou alt='' si décorative."
            })

        # 5. Buttons accessibility
        buttons = re.findall(r'<button[^>]*>(.*?)</button>', html_content, re.IGNORECASE | re.DOTALL)
        empty_buttons = 0
        for b_tag in re.findall(r'<button[^>]*>', html_content, re.IGNORECASE):
            # Check if has aria-label or title
            has_aria = bool(re.search(r'aria-label=["\'][^"\']+["\']', b_tag, re.IGNORECASE))
            has_title = bool(re.search(r'title=["\'][^"\']+["\']', b_tag, re.IGNORECASE))
            if not has_aria and not has_title:
                # check inner content if possible
                pass
        
        # 6. Ambiguous links ("cliquez ici", "en savoir plus")
        ambiguous_links = re.findall(r'<a[^>]*>(?:cliquez ici|click here|en savoir plus|more|ici)<\/a>', html_content, re.IGNORECASE)
        if ambiguous_links:
            score -= 10
            findings.append({
                "rule": "links_accessible",
                "severity": "MEDIUM",
                "message": f"{len(ambiguous_links)} lien(s) avec intitulé ambigu détecté(s) (ex: 'cliquez ici').",
                "recommendation": "Donner aux liens un texte décrivant explicitement leur cible de destination."
            })

        score = max(0, score)
        passed_rules = len(self.rules) - len(findings)
        
        grade = "AAA" if score >= 95 else "AA" if score >= 80 else "A" if score >= 65 else "FAIL"

        return {
            "score": score,
            "grade": grade,
            "total_rules": len(self.rules),
            "passed_rules": passed_rules,
            "findings_count": len(findings),
            "findings": findings,
            "compliant": score >= 80
        }
