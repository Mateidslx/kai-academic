# -*- coding: utf-8 -*-
"""Report Generators for a11y_audit_pro (JSON, Markdown, and Standalone HTML)."""
import html
import json
import time
from typing import Dict, Any

def generate_json_report(audit_data: Dict[str, Any], pretty: bool = True) -> str:
    """Exports audit findings in machine-readable JSON format."""
    payload = {
        "generator": "a11y-audit-pro v1.0.0",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "summary": {
            "score": audit_data.get("score", 0),
            "grade": audit_data.get("grade", "N/A"),
            "compliant": audit_data.get("compliant", False),
            "findings_count": audit_data.get("findings_count", 0)
        },
        "findings": audit_data.get("findings", []),
        "scotopic_analysis": audit_data.get("scotopic", None)
    }
    return json.dumps(payload, indent=2 if pretty else None, ensure_ascii=False)

def generate_markdown_report(audit_data: Dict[str, Any], target_name: str = "Document") -> str:
    """Exports a professional Markdown report ready for client deliverables."""
    score = audit_data.get("score", 0)
    grade = audit_data.get("grade", "N/A")
    lines = [
        f"# Rapport d'Audit d'Accessibilité Web & Scotopique (WCAG 2.1)",
        f"**Cible auditée** : `{target_name}`  ",
        f"**Date d'audit** : {time.strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Outil** : `a11y-audit-pro v1.0.0` (Licence Commerciale)  ",
        "",
        "## Résumé Exécutif",
        f"- **Score Global d'Accessibilité** : **{score}/100**",
        f"- **Palier WCAG** : **{grade}**",
        f"- **Statut de Conformité** : {'✅ CONFORME' if audit_data.get('compliant') else '⚠️ NON CONFORME'}",
        f"- **Anomalies Détectées** : {audit_data.get('findings_count', 0)}",
        "",
        "## Anomalies & Recommandations de Remédiation",
    ]

    findings = audit_data.get("findings", [])
    if not findings:
        lines.append("Aucune anomalie critique détectée. Document conforme aux standards WCAG 2.1.")
    else:
        for i, f in enumerate(findings, 1):
            lines.extend([
                f"### {i}. [{f['severity']}] {f['rule']}",
                f"- **Constat** : {f['message']}",
                f"- **Recommandation** : {f['recommendation']}",
                ""
            ])

    scotopic = audit_data.get("scotopic")
    if scotopic:
        lines.extend([
            "## Évaluation Ergonomique & Scotopique (Confort Cognitif)",
            f"- **Score Scotopique** : {scotopic['scotopic_score']}/100 ({scotopic['rating']})",
            f"- **Ratio de contraste** : {scotopic['ratio']}:1",
            f"- **Risque d'éblouissement** : {'OUI (Fond trop brillant)' if scotopic['is_glare_risk'] else 'NON'}",
            ""
        ])

    return "\n".join(lines)

def generate_html_report(audit_data: Dict[str, Any], target_name: str = "Document") -> str:
    """
    Génère un tableau de bord HTML exécutif et interactif complet d'audit d'accessibilité.
    Conforme WCAG 2.1 AAA & Neuro-ergonomie scotopique.
    100% hermétique et autonome, sans dépendance externe.
    """
    score = audit_data.get("score", 0)
    grade = audit_data.get("grade", "N/A")
    compliant = audit_data.get("compliant", False)
    findings = audit_data.get("findings", [])
    scotopic = audit_data.get("scotopic") or {}

    score_color = "#10b981" if score >= 80 else "#f59e0b" if score >= 60 else "#ef4444"
    status_text = "CONFORME WCAG 2.1" if compliant else "NON CONFORME — REMÉDIATION REQUISE"

    crit_count = sum(1 for f in findings if f.get("severity", "").upper() in ("CRITICAL", "HIGH"))
    warn_count = sum(1 for f in findings if f.get("severity", "").upper() not in ("CRITICAL", "HIGH"))

    findings_html_cards = []
    for idx, f in enumerate(findings, 1):
        sev = f.get("severity", "MEDIUM").upper()
        sev_bg = "#dc2626" if sev == "CRITICAL" else "#ea580c" if sev == "HIGH" else "#d97706" if sev == "MEDIUM" else "#2563eb"
        rule_name = html.escape(str(f.get("rule", "Règle non spécifiée")))
        msg = html.escape(str(f.get("message", "")))
        recom = html.escape(str(f.get("recommendation", "")))
        elem = html.escape(str(f.get("selector") or f.get("element") or ""))
        elem_html = f"<div class='finding-code'><code>{elem}</code></div>" if elem else ""

        findings_html_cards.append(f"""
        <div class="finding-card" data-severity="{sev}">
            <div class="finding-header">
                <div>
                    <span class="finding-sev" style="background: {sev_bg};">{sev}</span>
                    <span class="finding-rule">Règle : {rule_name}</span>
                </div>
                <span class="finding-id">#{idx}</span>
            </div>
            <div class="finding-body">
                <p><strong>Constat :</strong> {msg}</p>
                {elem_html}
                <div class="finding-recom">
                    <strong>Solution recommandée :</strong> {recom}
                </div>
            </div>
        </div>
        """)

    if not findings_html_cards:
        findings_html_str = """
        <div class="card" style="text-align: center; padding: 40px; background: #f0fdf4; border-color: #bbf7d0;">
            <div style="font-size: 2.5rem; margin-bottom: 10px;">🎉</div>
            <h3 style="color: #166534; font-size: 1.3rem;">Zéro anomalie d'accessibilité détectée</h3>
            <p style="color: #15803d; margin-top: 6px;">Cette ressource respecte intégralement les règles d'accessibilité WCAG 2.1 testées.</p>
        </div>
        """
    else:
        findings_html_str = "\n".join(findings_html_cards)

    scotopic_score = scotopic.get("scotopic_score", 0)
    scotopic_rating = scotopic.get("rating", "N/A")
    scotopic_ratio = scotopic.get("ratio", 0.0)
    scotopic_glare = "OUI (Fond trop éclatant)" if scotopic.get("is_glare_risk") else "NON (Éblouissement maîtrisé)"

    safe_target = html.escape(target_name)

    return f"""<!DOCTYPE html>
<html lang="fr" id="root-doc">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Audit d'Accessibilité & Neuro-Ergonomie — {safe_target}</title>
    <style>
        :root {{
            --bg-body: #FAF8F5;
            --text-body: #1C1917;
            --card-bg: #FFFFFF;
            --border: #E7E5E4;
            --muted: #78716C;
            --primary: #0284C7;
            --accent: #2563EB;
        }}
        
        /* Mode Sombre Apaisant */
        body.theme-dark {{
            --bg-body: #0F172A;
            --text-body: #F8FAFC;
            --card-bg: #1E293B;
            --border: #334155;
            --muted: #94A3B8;
        }}

        /* Mode Contraste Élevé */
        body.theme-high-contrast {{
            --bg-body: #FFFFFF;
            --text-body: #000000;
            --card-bg: #FFFFFF;
            --border: #000000;
            --muted: #262626;
        }}

        /* Mode Confort Dyslexie */
        body.dyslexia-active {{
            font-family: ui-sans-serif, system-ui, -apple-system, sans-serif !important;
            letter-spacing: 0.12em !important;
            word-spacing: 0.16em !important;
            line-height: 1.85 !important;
            font-weight: 500 !important;
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            background: var(--bg-body);
            color: var(--text-body);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            padding: 30px 20px;
            transition: background 0.25s ease, color 0.25s ease;
        }}
        .container {{ max-width: 1040px; margin: 0 auto; }}

        /* Top Header */
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }}
        .badge-brand {{
            background: #0284c7;
            color: #fff;
            font-size: 0.75rem;
            padding: 3px 8px;
            border-radius: 6px;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.05em;
        }}
        .header h1 {{ font-size: 1.8rem; font-weight: 800; margin-top: 4px; }}
        .header p {{ color: var(--muted); font-size: 0.95rem; margin-top: 4px; }}

        /* Neuro-Ergonomic Simulation Bar */
        .simulation-bar {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 14px 20px;
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.03);
        }}
        .sim-title {{ font-size: 0.9rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }}
        .sim-controls {{ display: flex; gap: 8px; flex-wrap: wrap; }}
        .btn-sim {{
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-body);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }}
        .btn-sim:hover {{ background: rgba(0,0,0,0.04); }}
        .btn-sim.active {{
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }}

        /* Scorecards Grid */
        .grid-cards {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .card {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }}
        .gauge-wrapper {{ display: flex; align-items: center; gap: 20px; }}
        .gauge-circle {{
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: conic-gradient({score_color} {score * 3.6}deg, #e2e8f0 0deg);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }}
        .gauge-inner {{
            width: 62px;
            height: 62px;
            border-radius: 50%;
            background: var(--card-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
            font-weight: 900;
        }}

        /* Findings List */
        .section-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            flex-wrap: wrap;
            gap: 12px;
        }}
        .section-title {{ font-size: 1.3rem; font-weight: 800; }}
        .filter-buttons {{ display: flex; gap: 8px; }}
        .filter-btn {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            color: var(--text-body);
            padding: 6px 14px;
            border-radius: 9999px;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
        }}
        .filter-btn.active {{
            background: #1e293b;
            color: #fff;
            border-color: #1e293b;
        }}

        .finding-card {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 14px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }}
        .finding-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }}
        .finding-sev {{
            color: white;
            padding: 3px 8px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }}
        .finding-rule {{ margin-left: 8px; font-weight: 700; font-size: 0.95rem; }}
        .finding-id {{ color: var(--muted); font-size: 0.85rem; font-family: monospace; }}
        .finding-code {{
            background: #090d16;
            color: #38bdf8;
            padding: 8px 12px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 0.85rem;
            margin: 10px 0;
            overflow-x: auto;
        }}
        .finding-recom {{
            background: rgba(2, 132, 199, 0.08);
            border-left: 4px solid var(--primary);
            padding: 10px 14px;
            border-radius: 0 8px 8px 0;
            font-size: 0.9rem;
            margin-top: 10px;
        }}

        /* Code & Tools */
        .code-box {{
            background: #090d16;
            color: #f1f5f9;
            padding: 16px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 0.85rem;
            overflow-x: auto;
            white-space: pre-wrap;
            margin-top: 10px;
        }}
        .btn-copy {{
            background: #0284c7;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            float: right;
            margin-bottom: 8px;
        }}

        .footer {{
            text-align: center;
            color: var(--muted);
            font-size: 0.85rem;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div>
                <span class="badge-brand">a11y-audit-pro v1.0.0</span>
                <h1>Audit d'Accessibilité Web & Neuro-Ergonomie</h1>
                <p>Cible : <strong>{safe_target}</strong> • Rapport Certifié WCAG 2.1 AAA</p>
            </div>
            <div style="text-align: right;">
                <span style="font-weight: 700; color: {score_color}; font-size: 1.1rem;">{status_text}</span>
                <p style="font-size: 0.85rem; color: var(--muted);">Normes W3C WCAG 2.1 & Scotopic Comfort Index</p>
            </div>
        </div>

        <!-- Simulation Bar -->
        <div class="simulation-bar">
            <div class="sim-title">
                <span>👓 Simulateur Neuro-Ergonomique :</span>
            </div>
            <div class="sim-controls">
                <button class="btn-sim active" id="btn-scotopic" onclick="setTheme('scotopic')">Crème Scotopique (Doux)</button>
                <button class="btn-sim" id="btn-contrast" onclick="setTheme('contrast')">Contraste Élevé</button>
                <button class="btn-sim" id="btn-dark" onclick="setTheme('dark')">Mode Sombre</button>
                <button class="btn-sim" id="btn-dyslexia" onclick="toggleDyslexia()">📖 Police Dyslexie</button>
            </div>
        </div>

        <!-- Metric Scorecards -->
        <div class="grid-cards">
            <!-- Score Card -->
            <div class="card">
                <div style="font-size: 0.8rem; font-weight: 700; color: var(--muted); text-transform: uppercase;">Score Global WCAG</div>
                <div class="gauge-wrapper" style="margin-top: 12px;">
                    <div class="gauge-circle">
                        <div class="gauge-inner">{score}</div>
                    </div>
                    <div>
                        <div style="font-size: 1.4rem; font-weight: 800; color: {score_color};">Palier {grade}</div>
                        <div style="font-size: 0.85rem; color: var(--muted);">{len(findings)} anomalies détectées</div>
                    </div>
                </div>
            </div>

            <!-- Scotopic Card -->
            <div class="card">
                <div style="font-size: 0.8rem; font-weight: 700; color: var(--muted); text-transform: uppercase;">Confort Scotopique</div>
                <div style="margin-top: 12px;">
                    <div style="font-size: 1.4rem; font-weight: 800; color: var(--primary);">{scotopic_score}/100 ({scotopic_rating})</div>
                    <div style="font-size: 0.85rem; color: var(--muted); margin-top: 4px;">
                        Ratio : <strong>{scotopic_ratio}:1</strong> • Éblouissement : <strong>{scotopic_glare}</strong>
                    </div>
                </div>
            </div>

            <!-- Severity Breakdown Card -->
            <div class="card">
                <div style="font-size: 0.8rem; font-weight: 700; color: var(--muted); text-transform: uppercase;">Sévérité des Écarts</div>
                <div style="margin-top: 12px; display: flex; gap: 16px;">
                    <div>
                        <div style="font-size: 1.4rem; font-weight: 800; color: #dc2626;">{crit_count}</div>
                        <div style="font-size: 0.8rem; color: var(--muted);">Critiques</div>
                    </div>
                    <div>
                        <div style="font-size: 1.4rem; font-weight: 800; color: #d97706;">{warn_count}</div>
                        <div style="font-size: 0.8rem; color: var(--muted);">Avertissements</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Findings Section -->
        <div class="section-header">
            <h2 class="section-title">Anomalies & Remédiations Recommandées ({len(findings)})</h2>
            <div class="filter-buttons">
                <button class="filter-btn active" onclick="filterFindings('ALL', this)">Toutes ({len(findings)})</button>
                <button class="filter-btn" onclick="filterFindings('CRITICAL', this)">Critiques ({crit_count})</button>
                <button class="filter-btn" onclick="filterFindings('MEDIUM', this)">Modérées ({warn_count})</button>
            </div>
        </div>

        <div id="findings-container">
            {findings_html_str}
        </div>

        <!-- Scotopic CSS Design System Export -->
        <div class="card" style="margin-top: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h3 style="font-size: 1.1rem; font-weight: 700;">🎨 Gabarit CSS Scotopique Universel (Design Inclusif)</h3>
                <button class="btn-copy" onclick="copySnippet('css-scotopic', this)">📋 Copier le CSS</button>
            </div>
            <p style="font-size: 0.85rem; color: var(--muted); margin-top: 4px;">
                Intégrez ces variables dans votre feuille de style pour éliminer la fatigue oculaire et garantir un contraste WCAG AAA apaisant.
            </p>
            <pre class="code-box"><code id="css-scotopic">/* Palette Neuro-Ergonomique a11y-audit-pro (Anti-Éblouissement & Confort Scotopique) */
:root {{
    --bg-comfort: #FAF8F5;       /* Fond crème feutré (zéro éblouissement blanc pur #FFFFFF) */
    --text-comfort: #1C1917;     /* Encre anthracite douce (zéro noir dur #000000) */
    --accent-sober: #0284C7;     /* Bleu doux certifié WCAG AAA */
    --card-surface: #FFFFFF;
    --border-subtle: #E7E5E4;
}}

body {{
    background-color: var(--bg-comfort);
    color: var(--text-comfort);
    line-height: 1.75;
    letter-spacing: 0.02em;
}}</code></pre>
        </div>

        <!-- CI/CD Integration -->
        <div class="card" style="margin-top: 20px; background: #0b1120; color: #f8fafc; border-color: #1e293b;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h3 style="font-size: 1.1rem; font-weight: 700; color: #38bdf8;">⚡ Automatisation CI/CD (GitHub Actions / GitLab CI)</h3>
                <button class="btn-copy" style="background: #38bdf8; color: #0f172a;" onclick="copySnippet('cicd-cmd', this)">📋 Copier la commande</button>
            </div>
            <p style="font-size: 0.85rem; color: #94a3b8; margin-top: 4px;">
                Bloquez automatiquement les régressions d'accessibilité dans votre pipeline de déploiement continu :
            </p>
            <pre class="code-box" style="background: #020617;"><code id="cicd-cmd">a11y-audit-pro audit --url "{safe_target}" --fail-under 80 --sarif results.sarif</code></pre>
        </div>

        <div class="footer">
            Rapport certifié généré par a11y-audit-pro • Développé par Mateidslx • Conforme WCAG 2.1 & W3C ATAG
        </div>
    </div>

    <script>
        function setTheme(theme) {{
            document.body.classList.remove('theme-dark', 'theme-high-contrast');
            document.querySelectorAll('.btn-sim').forEach(function(b) {{ if (b.id !== 'btn-dyslexia') b.classList.remove('active'); }});
            if (theme === 'dark') {{
                document.body.classList.add('theme-dark');
                document.getElementById('btn-dark').classList.add('active');
            }} else if (theme === 'contrast') {{
                document.body.classList.add('theme-high-contrast');
                document.getElementById('btn-contrast').classList.add('active');
            }} else {{
                document.getElementById('btn-scotopic').classList.add('active');
            }}
        }}

        function toggleDyslexia() {{
            document.body.classList.toggle('dyslexia-active');
            document.getElementById('btn-dyslexia').classList.toggle('active');
        }}

        function filterFindings(sev, btn) {{
            document.querySelectorAll('.filter-btn').forEach(function(b) {{ b.classList.remove('active'); }});
            btn.classList.add('active');
            var cards = document.querySelectorAll('.finding-card');
            cards.forEach(function(c) {{
                if (sev === 'ALL') {{
                    c.style.display = 'block';
                }} else if (sev === 'CRITICAL') {{
                    c.style.display = (c.getAttribute('data-severity') === 'CRITICAL' || c.getAttribute('data-severity') === 'HIGH') ? 'block' : 'none';
                }} else {{
                    c.style.display = (c.getAttribute('data-severity') !== 'CRITICAL' && c.getAttribute('data-severity') !== 'HIGH') ? 'block' : 'none';
                }}
            }});
        }}

        function copySnippet(elementId, btn) {{
            var el = document.getElementById(elementId);
            if (!el) return;
            var text = el.innerText || el.textContent;
            navigator.clipboard.writeText(text).then(function() {{
                var orig = btn.innerHTML;
                btn.innerHTML = '✓ Copié !';
                setTimeout(function() {{ btn.innerHTML = orig; }}, 2000);
            }}).catch(function(err) {{
                console.error(err);
            }});
        }}
    </script>
</body>
</html>"""

def generate_sarif_report(audit_data: Dict[str, Any], target_name: str = "Document") -> str:
    """Generates an OASIS SARIF v2.1.0 compatible JSON report for GitHub Security Center."""
    rules = []
    results = []
    findings = audit_data.get("findings", [])
    rule_ids_seen = set()

    for f in findings:
        rule_id = f.get("rule", "A11Y_RULE").replace(" ", "_").upper()
        if rule_id not in rule_ids_seen:
            rule_ids_seen.add(rule_id)
            rules.append({
                "id": rule_id,
                "name": f.get("rule", "AccessibilityIssue"),
                "shortDescription": {"text": f.get("message", "Accessibility standard violation")},
                "help": {"text": f.get("recommendation", "Ensure compliance with WCAG 2.1 AAA guidelines.")},
                "defaultConfiguration": {
                    "level": "error" if f.get("severity") in ("CRITIQUE", "HIGH", "CRITICAL") else "warning"
                }
            })

        results.append({
            "ruleId": rule_id,
            "level": "error" if f.get("severity") in ("CRITIQUE", "HIGH", "CRITICAL") else "warning",
            "message": {"text": f.get("message", "Accessibility defect detected")},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": target_name},
                    "region": {
                        "startLine": f.get("line", 1),
                        "startColumn": f.get("column", 1)
                    }
                }
            }]
        })

    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {
                "driver": {
                    "name": "a11y-audit-pro",
                    "version": "1.0.0",
                    "informationUri": "https://polar.sh",
                    "rules": rules
                }
            },
            "results": results
        }]
    }
    return json.dumps(sarif, indent=2, ensure_ascii=False)

