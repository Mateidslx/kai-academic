# -*- coding: utf-8 -*-
"""A11y Audit Pro - Visual & Functional Accessibility Engine."""
from .contrast import calculate_contrast_ratio, is_wcag_compliant, hex_to_rgb
from .scotopic import ScotopicAnalyzer
from .scanner import HtmlA11yScanner
from .browser_auditor import VisualFunctionalA11yAuditor, A11yFinding, EphemeralServer

__version__ = "2.1.0"
__all__ = [
    "VisualFunctionalA11yAuditor",
    "A11yFinding",
    "EphemeralServer",
    "HtmlA11yScanner",
    "ScotopicAnalyzer",
    "calculate_contrast_ratio",
    "is_wcag_compliant",
    "hex_to_rgb"
]
