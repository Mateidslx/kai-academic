# -*- coding: utf-8 -*-
"""Color Contrast and Luminance Mathematics (WCAG 2.1 Formulae)."""
import re
from typing import Tuple, Dict

def hex_to_rgb(hex_str: str) -> Tuple[int, int, int]:
    """Converts a hex color string (#RGB or #RRGGBB) to (r, g, b)."""
    h = hex_str.strip().lstrip('#')
    if len(h) == 3:
        h = ''.join([c * 2 for c in h])
    if len(h) != 6:
        raise ValueError(f"Invalid hex color code: '{hex_str}'")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

def relative_luminance(rgb: Tuple[int, int, int]) -> float:
    """Calculates relative luminance according to WCAG 2.1 specifications."""
    def channel_luminance(val: int) -> float:
        s = val / 255.0
        return s / 12.92 if s <= 0.03928 else ((s + 0.055) / 1.055) ** 2.4

    r = channel_luminance(rgb[0])
    g = channel_luminance(rgb[1])
    b = channel_luminance(rgb[2])
    return 0.2126 * r + 0.7152 * g + 0.0722 * b

def calculate_contrast_ratio(color1: str, color2: str) -> float:
    """Returns the contrast ratio between two hex colors, formatted as a float >= 1.0."""
    rgb1 = hex_to_rgb(color1)
    rgb2 = hex_to_rgb(color2)
    l1 = relative_luminance(rgb1)
    l2 = relative_luminance(rgb2)
    lighter = max(l1, l2)
    darker = min(l1, l2)
    ratio = (lighter + 0.05) / (darker + 0.05)
    return round(ratio, 2)

def is_wcag_compliant(ratio: float, level: str = "AA", is_large_text: bool = False) -> Dict[str, bool]:
    """Checks whether the contrast ratio meets WCAG AA / AAA requirements."""
    level = level.upper()
    req_aa = 3.0 if is_large_text else 4.5
    req_aaa = 4.5 if is_large_text else 7.0
    return {
        "aa_compliant": ratio >= req_aa,
        "aaa_compliant": ratio >= req_aaa,
        "ratio": ratio,
        "required_aa": req_aa,
        "required_aaa": req_aaa
    }
