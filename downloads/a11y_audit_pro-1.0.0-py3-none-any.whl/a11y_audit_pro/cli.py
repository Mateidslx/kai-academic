# -*- coding: utf-8 -*-
"""Command-line interface for a11y-audit-pro."""
import argparse
import sys
import os
from pathlib import Path
from . import __version__
from .scanner import HtmlA11yScanner
from .contrast import calculate_contrast_ratio, is_wcag_compliant
from .scotopic import ScotopicAnalyzer
from .reporters import generate_json_report, generate_markdown_report, generate_html_report, generate_sarif_report

# Reconfigure stdout/stderr for Windows terminal emoji and UTF-8 safety
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def main():
    parser = argparse.ArgumentParser(
        prog="a11y-audit-pro",
        description="Inspecteur professionnel d'accessibilité numérique WCAG 2.1 AAA et confort scotopique"
    )
    parser.add_argument("--version", action="version", version=f"a11y-audit-pro {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)

    # Subcommand: scan
    scan_parser = subparsers.add_parser("scan", help="Scan an HTML file for accessibility compliance")
    scan_parser.add_argument("file", help="Path to local HTML file to audit")
    scan_parser.add_argument("--format", choices=["text", "json", "markdown", "html", "sarif"], default="text", help="Output format")
    scan_parser.add_argument("--output", help="Optional output file path")
    scan_parser.add_argument("--bg", default="#FAF8F5", help="Background color for scotopic contrast test (hex)")
    scan_parser.add_argument("--text-color", default="#1C1917", help="Text color for contrast test (hex)")

    # Subcommand: contrast
    contrast_parser = subparsers.add_parser("contrast", help="Evaluate contrast ratio between two hex colors")
    contrast_parser.add_argument("color1", help="First color (hex, e.g. #FFFFFF)")
    contrast_parser.add_argument("color2", help="Second color (hex, e.g. #000000)")
    contrast_parser.add_argument("--large-text", action="store_true", help="Evaluate for large text (>= 18pt or bold 14pt)")
    # Subcommand: audit (Visual and Functional Browser Audit)
    audit_parser = subparsers.add_parser("audit", help="Auditer visuellement et fonctionnellement une URL ou un répertoire en navigateur réel")
    audit_parser.add_argument("target", help="URL autorisée (http://...) ou chemin d'un répertoire projet local")
    audit_parser.add_argument("--page", default="/", help="Chemin de page relatif (par défaut '/')")
    audit_parser.add_argument("--output-dir", help="Répertoire de sortie pour les captures d'écran et rapports")
    audit_parser.add_argument("--format", choices=["text", "json", "markdown"], default="text", help="Format de sortie")

    args = parser.parse_args()

    if args.command == "contrast":
        try:
            ratio = calculate_contrast_ratio(args.color1, args.color2)
            comp = is_wcag_compliant(ratio, is_large_text=args.large_text)
            print(f"==================================================")
            print(f"  A11Y CONTRAST AUDIT : {args.color1} vs {args.color2}")
            print(f"==================================================")
            print(f"  Contraste mesuré : {ratio}:1")
            print(f"  Conforme WCAG AA : {'OUI' if comp['aa_compliant'] else 'NON'} (seuil requis: {comp['required_aa']}:1)")
            print(f"  Conforme WCAG AAA: {'OUI' if comp['aaa_compliant'] else 'NON'} (seuil requis: {comp['required_aaa']}:1)")
            sys.exit(0 if comp['aa_compliant'] else 1)
        except Exception as e:
            print(f"Erreur de calcul : {e}", file=sys.stderr)
            sys.exit(2)

    elif args.command == "scan":
        target_path = Path(args.file)
        if not target_path.exists():
            print(f"Fichier introuvable : {target_path}", file=sys.stderr)
            sys.exit(2)

        content = target_path.read_text(encoding="utf-8", errors="replace")
        scanner = HtmlA11yScanner()
        audit_data = scanner.audit_html(content)

        scotopic_analyzer = ScotopicAnalyzer()
        scotopic_res = scotopic_analyzer.evaluate_palette(args.bg, args.text_color)
        audit_data["scotopic"] = scotopic_res

        if args.format == "json":
            out_str = generate_json_report(audit_data)
        elif args.format == "markdown":
            out_str = generate_markdown_report(audit_data, target_name=target_path.name)
        elif args.format == "html":
            out_str = generate_html_report(audit_data, target_name=target_path.name)
        elif args.format == "sarif":
            out_str = generate_sarif_report(audit_data, target_name=target_path.name)
        else:
            # Text format
            print(f"==================================================")
            print(f"  A11Y AUDIT PRO : {target_path.name}")
            print(f"  Score Global  : {audit_data['score']}/100 ({audit_data['grade']})")
            print(f"  Conformité    : {'OUI' if audit_data['compliant'] else 'NON'}")
            print(f"  Anomalies     : {audit_data['findings_count']}")
            print(f"==================================================")
            for f in audit_data["findings"]:
                print(f"  [{f['severity']}] {f['rule']}: {f['message']}")
            print(f"  Score Scotopique: {scotopic_res['scotopic_score']}/100 ({scotopic_res['rating']})")
            out_str = None

        if out_str:
            if args.output:
                Path(args.output).write_text(out_str, encoding="utf-8")
                print(f"Rapport sauvegardé dans {args.output}")
            else:
                print(out_str)

        sys.exit(0 if audit_data['compliant'] else 1)

    elif args.command == "audit":
        from .browser_auditor import VisualFunctionalA11yAuditor
        import json
        out_path = Path(args.output_dir) if args.output_dir else None
        auditor = VisualFunctionalA11yAuditor(output_dir=out_path, headless=True)
        res = auditor.audit_target(args.target, page_path=args.page)

        if args.format == "json":
            print(json.dumps(res, indent=2, ensure_ascii=False))
        elif args.format == "markdown":
            print(f"# RAPPORT D'AUDIT VISUEL & FONCTIONNEL : {res['target_url']}\n")
            print(f"- **Note globale :** {res['score']}/100 ({res['grade']})")
            print(f"- **Durée d'audit :** {res['duration_seconds']}s")
            print(f"- **Anomalies trouvées :** {res['findings_count']}")
            print(f"- **Capture d'écran :** `{res['full_screenshot']}`\n")
            print("## Fiches d'Anomalies Détaillées")
            for f in res["findings"]:
                print(f"### [{f['finding_id']}] {f['rule']} ({f['severity']})")
                print(f"- **Élément :** `{f['element_selector']}`")
                print(f"- **Constaté :** {f['observed_behavior']}")
                print(f"- **Attendu :** {f['expected_behavior']}")
                print(f"- **Standard :** {f['standard']}")
                print(f"- **Correctif proposé :**\n```html\n{f['proposed_patch']}\n```\n")
        else:
            print(f"==================================================")
            print(f"  AUDIT VISUEL ET FONCTIONNEL : {res['target_url']}")
            print(f"  Score Global : {res['score']}/100 ({res['grade']})")
            print(f"  Anomalies    : {res['findings_count']}")
            print(f"  Screenshot   : {res['full_screenshot']}")
            print(f"==================================================")
            for f in res["findings"]:
                print(f"  [{f['severity']}] {f['finding_id']}: {f['rule']}")
                print(f"    Élément: {f['element_selector']}")
                print(f"    Constat: {f['observed_behavior']}")
                print(f"    Patch:   {f['proposed_patch']}")
        sys.exit(0 if res["score"] >= 80 else 1)


if __name__ == "__main__":
    main()
