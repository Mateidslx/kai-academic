# -*- coding: utf-8 -*-
"""Scotopic Sensitivity & Cognitive Fatigue Analyzer."""
from typing import Dict, Any, List
from .contrast import hex_to_rgb, calculate_contrast_ratio

class ScotopicAnalyzer:
    """Evaluates optical glare, dyslexia compliance and visual fatigue."""

    # Colors causing photopic stress / visual fatigue for neurodivergent & dyslexic users
    HIGH_GLARE_BACKGROUNDS = ["#FFFFFF", "#FFFF00", "#00FFFF"]

    # Recommended soothing tint palettes
    CALMING_TINTS = {
        "#FAF8F5": "Crème Doux (Warm Cream)",
        "#FAF6EE": "Sable Chaud (Warm Sand)",
        "#FFF7ED": "Pêche Feutré (Soft Peach)",
        "#F0FDF4": "Menthe Apaisante (Soft Mint)",
        "#F0F9FF": "Ciel Céladon (Soft Sky)"
    }

    def evaluate_palette(self, background_hex: str, text_hex: str) -> Dict[str, Any]:
        """Analyzes glare factor and scotopic comfort."""
        ratio = calculate_contrast_ratio(background_hex, text_hex)
        bg_upper = background_hex.strip().upper()
        
        is_glare_risk = bg_upper in [g.upper() for g in self.HIGH_GLARE_BACKGROUNDS] and ratio > 15.0
        is_calming_tint = bg_upper in [t.upper() for t in self.CALMING_TINTS.keys()]
        
        score = 100
        penalties = []
        recommendations = []

        if is_glare_risk:
            score -= 30
            penalties.append("Risque élevé d'éblouissement photopique (100% blanc pur sur texte noir profond)")
            recommendations.append("Adopter un fond feutré scotopique (#FAF8F5 ou #FAF6EE) pour réduire la fatigue oculaire.")

        if ratio < 4.5:
            score -= 40
            penalties.append(f"Contraste insuffisant pour lecture confortable ({ratio}:1 < 4.5:1)")
            recommendations.append("Augmenter le contraste textuel pour garantir le palier WCAG AA.")

        if is_calming_tint:
            recommendations.append(f"Excellente palette cognitive : {self.CALMING_TINTS.get(bg_upper, 'Teinte apaisante')}.")

        return {
            "scotopic_score": max(0, score),
            "ratio": ratio,
            "background": background_hex,
            "text": text_hex,
            "is_glare_risk": is_glare_risk,
            "is_calming_tint": is_calming_tint,
            "penalties": penalties,
            "recommendations": recommendations,
            "rating": "OPTIMAL" if score >= 85 else "ACCEPTABLE" if score >= 60 else "FATIGANT"
        }
