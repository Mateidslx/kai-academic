# -*- coding: utf-8 -*-
"""a11y_audit_pro/browser_auditor.py
Moteur d'audit visuel et fonctionnel d'accessibilité en navigateur réel (Playwright).
Prend en charge :
1. Deux modes d'entrée : URL distante autorisée ou répertoire projet local (avec serveur éphémère).
2. Inspection de l'arbre d'accessibilité (Accessibility Tree) et du DOM calculé.
3. Vérification du contraste WCAG 2.1 réel (styles calculés) et texte sur arrière-plan.
4. Navigation clavier et visibilité du focus (:focus-visible, contour actif).
5. Robustesse au zoom (200%+) et adaptabilité responsive (détection d'overflow horizontal).
6. Contrôle fonctionnel des interactions :
   - Contrôles inertes (boutons sans action ni gestionnaire)
   - Liens brisés ou destinations inattendues
   - Auto-liens accidentels vs navigation légitime
   - Doublons d'actions
   - Formulaires sans libellé accessible
7. Fiches d'anomalies structurées avec étapes de reproduction et captures d'écran.
8. Application et vérification de correctifs (patchs) dans un espace de travail isolé.
"""

import os
import sys
import time
import socket
import threading
import json
import urllib.parse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, asdict
from PIL import Image
from playwright.sync_api import sync_playwright, Page, BrowserContext

ROOT = Path(__file__).resolve().parent.parent
from .contrast import calculate_contrast_ratio, is_wcag_compliant, hex_to_rgb


class VisionAuditor:
    """Module d'audit visuel par intelligence artificielle multimodale (Gemini 3.8 Flash).
    Inspecte la capture photographique complète de la page web pour interpréter l'ergonomie visuelle,
    la disposition spatiale, le confort scotopique et discriminer contextuellement les éléments graphiques.
    """
    def __init__(self, model_name: str = "gemini-3.8-flash"):
        self.model_name = model_name
        self._client = None
        self._init_client()

    def _init_client(self):
        try:
            import dotenv
            dotenv.load_dotenv()
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
            if api_key:
                from google import genai
                self._client = genai.Client(api_key=api_key)
        except Exception:
            self._client = None

    def analyze_page_screenshot(self, screenshot_path: Path, dom_summary: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        start_time = time.time()
        if not screenshot_path.exists():
            return {
                "model_name": self.model_name,
                "status": "ERROR",
                "error": f"Capture introuvable : {screenshot_path}"
            }

        img = Image.open(screenshot_path)
        dimensions = f"{img.width}x{img.height}"

        if not self._client:
            latency = round((time.time() - start_time) * 1000, 2)
            return {
                "model_name": None,
                "status": "NOT_EVALUATED",
                "input_dimensions": dimensions,
                "latency_ms": latency,
                "billing_tier": "UNKNOWN",
                "token_usage": None,
                "offline_fallback": False,
                "error": "Client Gemini non configuré (GEMINI_API_KEY absente). Analyse visuelle IA non effectuée.",
                "visual_conclusions": None,
                "contextual_discrimination": None,
                "scotopic_comfort_rating": None,
                "issues_detected": None,
                "confidence": 0.0,
                "uncertainty": "Fournisseur d'IA visuelle indisponible : aucune analyse de l'image n'a été réalisée."
            }

        prompt = f"""Tu es un auditeur expert en accessibilité visuelle, neuro-ergonomie et design inclusif.
Examine cette capture d'écran de page web (dimensions {dimensions}).
Contexte DOM : {json.dumps(dom_summary or {}, ensure_ascii=False)}

Effectue les analyses suivantes :
1. Perception visuelle d'ensemble : lisibilité, encombrement visuel, hiérarchie visuelle, clarté des espacements.
2. Discrimination contextuelle stricte : distingue formellement les images décoratives, bannières, photographies et illustrations (qui NE sont PAS des défauts de contraste) de la lisibilité réelle du texte de premier plan. Ne pénalise pas les couleurs riches d'une illustration comme un défaut de contraste.
3. Confort scotopique et fatigue oculaire : évalue si les couleurs sont agressives (néons, contrastes crus aveuglants) ou douces/ergonomiques.
4. Lisibilité du texte sur fond : détecte les textes superposés illisibles ou le manque de contraste effectif perçu à l'œil humain.

Réponds UNIQUEMENT sous forme d'un objet JSON strict valide avec les clés suivantes :
{{
  "visual_conclusions": "synthèse concise de la perception visuelle",
  "contextual_discrimination": "distinction explicite entre graphismes décoratifs et texte",
  "scotopic_comfort_rating": "EXCELLENT" ou "ACCEPTABLE" ou "HARSH",
  "issues_detected": ["liste des anomalies visuelles réelles perçues, ou vide si aucune"],
  "confidence": 0.95,
  "uncertainty": "explication des limites de la perception visuelle"
}}
"""
        models_to_try = [self.model_name, "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"]
        parsed = None
        used_model = self.model_name
        last_resp = None
        last_err = None
        model_attempts = []

        for m_name in models_to_try:
            try:
                resp = self._client.models.generate_content(
                    model=m_name,
                    contents=[img, prompt]
                )
                raw_text = resp.text.strip()
                if raw_text.startswith("```json"):
                    raw_text = raw_text[7:]
                if raw_text.startswith("```"):
                    raw_text = raw_text[3:]
                if raw_text.endswith("```"):
                    raw_text = raw_text[:-3]
                raw_text = raw_text.strip()

                parsed = json.loads(raw_text)
                used_model = m_name
                last_resp = resp
                usage = getattr(resp, "usage_metadata", None)
                model_attempts.append({
                    "model": m_name,
                    "status": "SUCCESS",
                    "prompt_token_count": getattr(usage, "prompt_token_count", None),
                    "candidates_token_count": getattr(usage, "candidates_token_count", None),
                    "total_token_count": getattr(usage, "total_token_count", None)
                })
                break
            except Exception as e:
                last_err = e
                model_attempts.append({
                    "model": m_name,
                    "status": "ERROR",
                    "error": str(e)
                })
                continue

        if parsed:
            latency = round((time.time() - start_time) * 1000, 2)
            usage = getattr(last_resp, "usage_metadata", None)
            token_usage = {
                "prompt_token_count": getattr(usage, "prompt_token_count", None),
                "candidates_token_count": getattr(usage, "candidates_token_count", None),
                "total_token_count": getattr(usage, "total_token_count", None)
            } if usage else None
            return {
                "model_name": used_model,
                "status": "SUCCESS",
                "input_dimensions": dimensions,
                "latency_ms": latency,
                "billing_tier": "UNKNOWN (account configuration unverified)",
                "monetary_cost": "UNKNOWN (no verified billing account data)",
                "token_usage": token_usage,
                "model_attempts": model_attempts,
                "offline_fallback": False,
                "visual_conclusions": parsed.get("visual_conclusions", ""),
                "contextual_discrimination": parsed.get("contextual_discrimination", ""),
                "scotopic_comfort_rating": parsed.get("scotopic_comfort_rating", "ACCEPTABLE"),
                "issues_detected": parsed.get("issues_detected", []),
                "confidence": float(parsed.get("confidence", 0.95)),
                "uncertainty": parsed.get("uncertainty", "Perception basée sur le rendu statique sans interaction dynamique.")
            }
        else:
            latency = round((time.time() - start_time) * 1000, 2)
            return {
                "model_name": None,
                "status": "ERROR",
                "input_dimensions": dimensions,
                "latency_ms": latency,
                "billing_tier": "UNKNOWN (account configuration unverified)",
                "monetary_cost": "UNKNOWN",
                "token_usage": None,
                "model_attempts": model_attempts,
                "offline_fallback": False,
                "error": f"Échec de l'ensemble des modèles de la cascade de vision : {str(last_err)}",
                "visual_conclusions": None,
                "contextual_discrimination": None,
                "scotopic_comfort_rating": None,
                "issues_detected": None,
                "confidence": 0.0,
                "uncertainty": "Erreur d'inférence API : aucune analyse visuelle IA n'a pu aboutir."
            }




@dataclass
class A11yFinding:
    finding_id: str
    rule: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    confidence: str  # CONFIRMED, HYPOTHESIS, UNCERTAIN
    element_selector: str
    element_html: str
    page_url: str
    observed_behavior: str
    expected_behavior: str
    reproduction_steps: List[str]
    evidence_path: Optional[str]
    standard: str
    proposed_patch: str
    verification_status: str = "UNVERIFIED"  # UNVERIFIED, PATCH_OFFERED, VERIFIED_FIXED

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class EphemeralServer:
    """Serveur HTTP éphémère local pour l'audit d'un répertoire projet isolé."""
    def __init__(self, directory: Path):
        self.directory = directory.resolve()
        self.server = None
        self.thread = None
        self.port = self._find_free_port()
        self.url = f"http://127.0.0.1:{self.port}"

    def _find_free_port(self) -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('127.0.0.1', 0))
            return s.getsockname()[1]

    def start(self):
        handler = lambda *args, **kwargs: SimpleHTTPRequestHandler(*args, directory=str(self.directory), **kwargs)
        self.server = ThreadingHTTPServer(('127.0.0.1', self.port), handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        # Attendre que le port réponde
        for _ in range(50):
            try:
                with socket.create_connection(('127.0.0.1', self.port), timeout=0.1):
                    break
            except OSError:
                time.sleep(0.05)

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()


class VisualFunctionalA11yAuditor:
    """Auditeur visuel et fonctionnel d'accessibilité piloté par navigateur réel Playwright."""

    def __init__(self, output_dir: Optional[Path] = None, headless: bool = True, enable_vision: bool = True):
        self.output_dir = output_dir or (ROOT / "reports" / "a11y_runs")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.screenshots_dir = self.output_dir / "screenshots"
        self.screenshots_dir.mkdir(parents=True, exist_ok=True)
        self.headless = headless
        self.enable_vision = enable_vision
        self.vision_auditor = VisionAuditor(model_name="gemini-3.8-flash") if enable_vision else None
        self.findings: List[A11yFinding] = []
        self._finding_seq = 1

    def _next_id(self) -> str:
        fid = f"A11Y-{self._finding_seq:03d}"
        self._finding_seq += 1
        return fid

    def audit_target(self, target: str | Path, page_path: str = "/") -> Dict[str, Any]:
        """Audite une cible : soit une URL (str commençant par http), soit un répertoire projet (Path ou str)."""
        ephemeral = None
        target_url = ""

        if isinstance(target, str) and (target.startswith("http://") or target.startswith("https://")):
            target_url = target
        else:
            proj_dir = Path(target).resolve()
            if not proj_dir.is_dir():
                raise ValueError(f"Le chemin spécifié n'est pas un répertoire valide : {target}")
            ephemeral = EphemeralServer(proj_dir)
            ephemeral.start()
            target_url = urllib.parse.urljoin(ephemeral.url, page_path)

        try:
            return self._run_browser_audit(target_url)
        finally:
            if ephemeral:
                ephemeral.stop()

    def _run_browser_audit(self, url: str) -> Dict[str, Any]:
        self.findings = []
        start_time = time.time()

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=self.headless)
            context = browser.new_context(
                viewport={"width": 1280, "height": 800},
                ignore_https_errors=True
            )
            page = context.new_page()

            # 1. Navigation et capture de base
            page.goto(url, wait_until="networkidle", timeout=15000)
            full_screenshot_path = self.screenshots_dir / f"full_page_{int(time.time())}.png"
            page.screenshot(path=str(full_screenshot_path), full_page=True)

            # 2. Arbre d'accessibilité (Accessibility Tree snapshot)
            try:
                a11y_tree = page.accessibility.snapshot()
            except Exception:
                a11y_tree = {}

            # 3. Contrôle des métadonnées du document et de la langue
            self._check_document_metadata(page, url)

            # 4. Hiérarchie des titres (Headings)
            self._check_heading_hierarchy(page, url)

            # 5. Accessibilité des images (Décoratives vs informatives)
            self._check_images_accessibility(page, url)

            # 6. Formulaires et libellés accessibles
            self._check_form_labels(page, url)

            # 7. Visibilité du focus et navigation clavier
            self._check_keyboard_and_focus(page, url)

            # 8. Contrastes de couleurs réels (Computed styles)
            self._check_computed_color_contrasts(page, url)

            # 9. Zoom et adaptabilité responsive (200% zoom et mobile)
            self._check_zoom_and_responsive(page, url)

            # 10. Contrôles interactifs, liens brisés et boutons inertes (test dynamique au clic)
            self._check_functional_controls(page, url)

            # 11. Analyse visuelle par IA multimodale (VisionAuditor)
            vision_result = None
            if self.vision_auditor and full_screenshot_path.exists():
                dom_summary = {
                    "title": page.title(),
                    "a11y_role": a11y_tree.get("role") if a11y_tree else "root",
                    "findings_count": len(self.findings)
                }
                vision_result = self.vision_auditor.analyze_page_screenshot(full_screenshot_path, dom_summary)

            browser.close()

        duration = time.time() - start_time
        score = self._compute_accessibility_score()

        return {
            "target_url": url,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "duration_seconds": round(duration, 2),
            "score": score,
            "grade": "AAA" if score >= 95 else "AA" if score >= 80 else "A" if score >= 65 else "FAIL",
            "full_screenshot": str(full_screenshot_path),
            "findings_count": len(self.findings),
            "findings": [f.to_dict() for f in self.findings],
            "vision_analysis": vision_result,
            "tree_summary": {
                "role": a11y_tree.get("role") if a11y_tree else "root",
                "children_count": len(a11y_tree.get("children", [])) if a11y_tree else 0
            }
        }

    def _check_document_metadata(self, page: Page, url: str):
        # Attribut lang
        html_lang = page.evaluate("() => document.documentElement.getAttribute('lang') || ''").strip()
        if not html_lang:
            self.findings.append(A11yFinding(
                finding_id=self._next_id(),
                rule="WCAG_DOC_LANG_MISSING",
                severity="CRITICAL",
                confidence="CONFIRMED",
                element_selector="html",
                element_html="<html>",
                page_url=url,
                observed_behavior="La balise racine <html> ne définit aucun attribut lang.",
                expected_behavior="La balise <html> doit définir un attribut lang valide (ex: lang='fr' ou lang='en').",
                reproduction_steps=["Ouvrir l'inspecteur DOM", "Examiner la balise racine <html>", "Constater l'absence d'attribut lang."],
                evidence_path=None,
                standard="WCAG 2.1 SC 3.1.1 Langue de la page",
                proposed_patch="<html lang=\"fr\">"
            ))

        # Balise <title>
        title = page.title().strip()
        if not title:
            self.findings.append(A11yFinding(
                finding_id=self._next_id(),
                rule="WCAG_PAGE_TITLE_EMPTY",
                severity="CRITICAL",
                confidence="CONFIRMED",
                element_selector="head > title",
                element_html="<title></title>",
                page_url=url,
                observed_behavior="Le titre de la page (<title>) est vide ou absent.",
                expected_behavior="Chaque page doit comporter un titre descriptif pour les technologies d'assistance.",
                reproduction_steps=["Examiner la balise <head>", "Observer l'absence de texte dans <title>."],
                evidence_path=None,
                standard="WCAG 2.1 SC 2.4.2 Titre de page",
                proposed_patch="<title>Page d'accueil - Titre Descriptif</title>"
            ))

    def _check_heading_hierarchy(self, page: Page, url: str):
        headings = page.evaluate("""() => {
            const hs = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6'));
            return hs.map(h => ({
                level: parseInt(h.tagName.substring(1)),
                text: h.innerText.trim(),
                selector: h.tagName.toLowerCase() + (h.id ? '#' + h.id : '')
            }));
        }""")
        if not headings:
            self.findings.append(A11yFinding(
                finding_id=self._next_id(),
                rule="A11Y_HEADINGS_MISSING",
                severity="MEDIUM",
                confidence="CONFIRMED",
                element_selector="body",
                element_html="<body>",
                page_url=url,
                observed_behavior="Aucun titre (h1-h6) n'est présent dans le document.",
                expected_behavior="La page doit comporter une structure hiérarchique avec au moins un titre principal h1.",
                reproduction_steps=["Rechercher les balises h1..h6 dans la page."],
                evidence_path=None,
                standard="WCAG 2.1 SC 1.3.1 Information et relations",
                proposed_patch="<h1>Titre Principal du Document</h1>"
            ))
            return

        # Vérifier qu'il y a un h1
        has_h1 = any(h["level"] == 1 for h in headings)
        if not has_h1:
            self.findings.append(A11yFinding(
                finding_id=self._next_id(),
                rule="WCAG_HEADING_NO_H1",
                severity="HIGH",
                confidence="CONFIRMED",
                element_selector=headings[0]["selector"],
                element_html=f"<h{headings[0]['level']}>{headings[0]['text'][:30]}</h{headings[0]['level']}>",
                page_url=url,
                observed_behavior=f"La page commence par <h{headings[0]['level']}> sans balise <h1> principale.",
                expected_behavior="Une page web doit comporter un titre <h1> décrivant le sujet de la page.",
                reproduction_steps=["Inspecter les titres du document", "Constater l'absence de niveau 1."],
                evidence_path=None,
                standard="WCAG 2.1 SC 1.3.1 Information et relations",
                proposed_patch=f"<h1>{headings[0]['text']}</h1>"
            ))

        # Vérifier les sauts illégaux (ex: h1 suivi de h3 sans h2)
        for i in range(len(headings) - 1):
            curr = headings[i]["level"]
            nxt = headings[i+1]["level"]
            if nxt > curr + 1:
                self.findings.append(A11yFinding(
                    finding_id=self._next_id(),
                    rule="WCAG_HEADING_SKIPPED_LEVEL",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    element_selector=headings[i+1]["selector"],
                    element_html=f"<h{nxt}>{headings[i+1]['text'][:30]}</h{nxt}>",
                    page_url=url,
                    observed_behavior=f"Saut hiérarchique non conforme de <h{curr}> vers <h{nxt}>.",
                    expected_behavior="La hiérarchie des titres ne doit pas sauter de niveau (ex: h1 -> h2 -> h3).",
                    reproduction_steps=[f"Lire le titre h{curr}", f"Observer que le titre suivant est h{nxt}"],
                    evidence_path=None,
                    standard="WCAG 2.1 SC 1.3.1 Information et relations",
                    proposed_patch=f"<h{curr+1}>{headings[i+1]['text']}</h{curr+1}>"
                ))

    def _check_images_accessibility(self, page: Page, url: str):
        images_info = page.evaluate("""() => {
            return Array.from(document.querySelectorAll('img')).map((img, idx) => {
                const hasAlt = img.hasAttribute('alt');
                const alt = img.getAttribute('alt');
                const role = img.getAttribute('role');
                const ariaHidden = img.getAttribute('aria-hidden');
                const isDecorative = (alt === '') || role === 'presentation' || ariaHidden === 'true';
                return {
                    idx: idx,
                    src: img.getAttribute('src') || '',
                    hasAlt: hasAlt,
                    alt: alt,
                    isDecorative: isDecorative,
                    visible: img.offsetParent !== null
                };
            });
        }""")

        for img in images_info:
            if not img["visible"]:
                continue
            if not img["hasAlt"]:
                self.findings.append(A11yFinding(
                    finding_id=self._next_id(),
                    rule="WCAG_IMG_MISSING_ALT",
                    severity="HIGH",
                    confidence="CONFIRMED",
                    element_selector=f"img[src*='{img['src'][:20]}']" if img["src"] else "img",
                    element_html=f"<img src=\"{img['src']}\">",
                    page_url=url,
                    observed_behavior="L'élément <img> ne comporte aucun attribut 'alt'.",
                    expected_behavior="Renseigner un attribut alt descriptif, ou alt='' si l'image est purement décorative.",
                    reproduction_steps=["Examiner la balise <img>", "Vérifier la présence de l'attribut alt."],
                    evidence_path=None,
                    standard="WCAG 2.1 SC 1.1.1 Contenu non textuel",
                    proposed_patch=f"<img src=\"{img['src']}\" alt=\"Description de l'image\">"
                ))

    def _check_form_labels(self, page: Page, url: str):
        inputs = page.evaluate("""() => {
            const fields = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]), textarea, select'));
            return fields.map(f => {
                const id = f.id;
                let hasLabel = false;
                if (id) {
                    const l = document.querySelector(`label[for="${id}"]`);
                    if (l && l.innerText.trim()) hasLabel = true;
                }
                const parentLabel = f.closest('label');
                if (parentLabel && parentLabel.innerText.trim()) hasLabel = true;
                const ariaLabel = f.getAttribute('aria-label');
                const ariaLabelledby = f.getAttribute('aria-labelledby');
                if (ariaLabel || ariaLabelledby) hasLabel = true;
                return {
                    tag: f.tagName.toLowerCase(),
                    type: f.getAttribute('type') || 'text',
                    id: id || '',
                    name: f.getAttribute('name') || '',
                    hasLabel: hasLabel,
                    outerHTML: f.outerHTML.substring(0, 100)
                };
            });
        }""")

        for f in inputs:
            if not f["hasLabel"]:
                self.findings.append(A11yFinding(
                    finding_id=self._next_id(),
                    rule="WCAG_INPUT_MISSING_LABEL",
                    severity="CRITICAL",
                    confidence="CONFIRMED",
                    element_selector=f"#{f['id']}" if f["id"] else f"{f['tag']}[name='{f['name']}']",
                    element_html=f["outerHTML"],
                    page_url=url,
                    observed_behavior=f"Le champ de formulaire <{f['tag']}> n'a aucun libellé accessible (<label>, aria-label, aria-labelledby).",
                    expected_behavior="Chaque contrôle de formulaire doit être lié à un label accessible pour le lecteur d'écran.",
                    reproduction_steps=["Inspecter le champ dans le formulaire", "Vérifier la présence d'un <label for='...'>."],
                    evidence_path=None,
                    standard="WCAG 2.1 SC 3.3.2 Étiquettes ou instructions",
                    proposed_patch=f"<label for=\"{f['id'] or 'field_id'}\">Nom du champ</label>\n{f['outerHTML']}"
                ))

    def _check_keyboard_and_focus(self, page: Page, url: str):
        # Identifier les éléments interactifs
        interactive_count = page.evaluate("""() => {
            return document.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])').length;
        }""")
        if interactive_count == 0:
            return

        # Tester la touche Tab sur les 5 premiers éléments et vérifier si :focus-visible a un contour
        try:
            page.keyboard.press("Tab")
            active_info = page.evaluate("""() => {
                const el = document.activeElement;
                if (!el || el === document.body) return null;
                const style = window.getComputedStyle(el);
                return {
                    tag: el.tagName.toLowerCase(),
                    id: el.id,
                    className: el.className,
                    outlineWidth: style.outlineWidth,
                    outlineStyle: style.outlineStyle,
                    boxShadow: style.boxShadow
                };
            }""")
            if active_info:
                # Si outlineStyle est 'none' et aucun box-shadow n'est appliqué
                if (active_info.get("outlineStyle") == "none" or active_info.get("outlineWidth") == "0px") and (active_info.get("boxShadow") == "none" or not active_info.get("boxShadow")):
                    self.findings.append(A11yFinding(
                        finding_id=self._next_id(),
                        rule="WCAG_FOCUS_VISIBLE_ABSENT",
                        severity="HIGH",
                        confidence="CONFIRMED",
                        element_selector=f"{active_info['tag']}{'.' + active_info['className'].split()[0] if active_info['className'] else ''}",
                        element_html=f"<{active_info['tag']}>",
                        page_url=url,
                        observed_behavior="L'indicateur de focus clavier est supprimé (outline: none sans alternative de box-shadow visible).",
                        expected_behavior="Tout élément interactif recevant le focus doit afficher un contour visible (WCAG 2.4.7).",
                        reproduction_steps=["Appuyer sur Tab pour naviguer", "Observer l'élément actif", "Constater l'absence de halo ou contour de focus."],
                        evidence_path=None,
                        standard="WCAG 2.1 SC 2.4.7 Visibilité du focus",
                        proposed_patch=":focus-visible { outline: 2px solid #2563eb; outline-offset: 2px; }"
                    ))
        except Exception:
            pass

    def _check_computed_color_contrasts(self, page: Page, url: str):
        # Récupérer les styles calculés réels de quelques éléments de texte clés
        contrast_samples = page.evaluate("""() => {
            const samples = [];
            const textNodes = Array.from(document.querySelectorAll('p, a, button, h1, h2, h3, span')).slice(0, 30);
            function rgbToHex(rgbStr) {
                if (!rgbStr || rgbStr === 'transparent' || rgbStr.startsWith('rgba(0, 0, 0, 0)')) return null;
                const m = rgbStr.match(/\\d+/g);
                if (!m || m.length < 3) return null;
                const r = parseInt(m[0]).toString(16).padStart(2, '0');
                const g = parseInt(m[1]).toString(16).padStart(2, '0');
                const b = parseInt(m[2]).toString(16).padStart(2, '0');
                return '#' + r + g + b;
            }
            for (const el of textNodes) {
                if (el.innerText.trim().length === 0 || el.offsetParent === null) continue;
                const cs = window.getComputedStyle(el);
                const fg = rgbToHex(cs.color);
                let bg = rgbToHex(cs.backgroundColor);
                // Si le fond est transparent, remonter aux parents
                let parent = el.parentElement;
                while (!bg && parent && parent !== document.documentElement) {
                    const pcs = window.getComputedStyle(parent);
                    bg = rgbToHex(pcs.backgroundColor);
                    parent = parent.parentElement;
                }
                if (!bg) bg = '#ffffff'; // Défaut fond blanc
                if (fg && bg) {
                    samples.push({
                        tag: el.tagName.toLowerCase(),
                        text: el.innerText.trim().substring(0, 30),
                        fg: fg,
                        bg: bg,
                        fontSize: parseFloat(cs.fontSize)
                    });
                }
            }
            return samples;
        }""")

        for sample in contrast_samples:
            try:
                ratio = calculate_contrast_ratio(sample["fg"], sample["bg"])
                is_large = sample.get("fontSize", 16) >= 24 or (sample.get("fontSize", 16) >= 18.66)
                compliance = is_wcag_compliant(ratio, is_large_text=is_large)
                if not compliance["aa_compliant"]:
                    self.findings.append(A11yFinding(
                        finding_id=self._next_id(),
                        rule="WCAG_CONTRAST_INSUFFICIENT",
                        severity="HIGH",
                        confidence="CONFIRMED",
                        element_selector=f"{sample['tag']}:has-text('{sample['text'][:15]}')",
                        element_html=f"<{sample['tag']}>{sample['text']}</{sample['tag']}>",
                        page_url=url,
                        observed_behavior=f"Contraste de couleur insuffisant : ratio mesuré de {ratio}:1 (Texte: {sample['fg']}, Fond: {sample['bg']}).",
                        expected_behavior=f"Le ratio de contraste minimal requis est de {compliance['required_aa']}:1 pour le niveau AA.",
                        reproduction_steps=["Examiner la couleur de texte calculée", "Examiner la couleur d'arrière-plan", "Calculer le ratio de contraste."],
                        evidence_path=None,
                        standard="WCAG 2.1 SC 1.4.3 Contraste (minimum)",
                        proposed_patch=f"color: #111827; background-color: {sample['bg']}; /* Ratio >= 4.5:1 */"
                    ))
                    break  # Éviter de saturer de rapports pour un même jeu de couleurs
            except Exception:
                pass

    def _check_zoom_and_responsive(self, page: Page, url: str):
        # 1. Vérification restriction du viewport
        meta_vp = page.evaluate("() => document.querySelector('meta[name=\"viewport\"]')?.getAttribute('content') || ''").lower()
        if "user-scalable=no" in meta_vp or "maximum-scale=1.0" in meta_vp or "maximum-scale=1\"" in meta_vp:
            self.findings.append(A11yFinding(
                finding_id=self._next_id(),
                rule="WCAG_VIEWPORT_ZOOM_BLOCKED",
                severity="CRITICAL",
                confidence="CONFIRMED",
                element_selector="meta[name='viewport']",
                element_html=f"<meta name=\"viewport\" content=\"{meta_vp}\">",
                page_url=url,
                observed_behavior="La balise viewport interdit l'agrandissement utilisateur (user-scalable=no ou maximum-scale=1).",
                expected_behavior="L'utilisateur doit pouvoir zoomer le texte jusqu'à au moins 200% sans perte de contenu.",
                reproduction_steps=["Examiner la balise meta viewport", "Observer l'interdiction de zoom."],
                evidence_path=None,
                standard="WCAG 2.1 SC 1.4.4 Redimensionnement du texte",
                proposed_patch="<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
            ))

        # 2. Test Responsive en largeur étroite (375px mobile)
        page.set_viewport_size({"width": 375, "height": 667})
        page.wait_for_timeout(300)
        has_horizontal_overflow = page.evaluate("() => document.documentElement.scrollWidth > window.innerWidth")
        if has_horizontal_overflow:
            overflow_px = page.evaluate("() => document.documentElement.scrollWidth - window.innerWidth")
            self.findings.append(A11yFinding(
                finding_id=self._next_id(),
                rule="A11Y_MOBILE_HORIZONTAL_SCROLL",
                severity="MEDIUM",
                confidence="CONFIRMED",
                element_selector="body",
                element_html="<body>",
                page_url=url,
                observed_behavior=f"Débordement horizontal non responsive ({overflow_px}px) sur écran 375px imposant un défilement bi-directionnel.",
                expected_behavior="Le contenu doit s'adapter sur une seule colonne sans défilement horizontal.",
                reproduction_steps=["Régler la fenêtre sur 375x667px", "Constater l'apparition d'une barre de défilement horizontale."],
                evidence_path=None,
                standard="WCAG 2.1 SC 1.4.10 Redistribution (Reflow)",
                proposed_patch="max-width: 100%; overflow-x: hidden; box-sizing: border-box;"
            ))
        # Rétablir viewport
        page.set_viewport_size({"width": 1280, "height": 800})

    def _check_functional_controls(self, page: Page, url: str):
        # Initialiser l'espion de mutations DOM pour tester l'interactivité réelle
        page.evaluate("""() => {
            window.__domMutations = 0;
            if (!window.__a11yObserver) {
                window.__a11yObserver = new MutationObserver((mutations) => {
                    window.__domMutations += mutations.length;
                });
                window.__a11yObserver.observe(document.body, {
                    attributes: true,
                    childList: true,
                    subtree: true,
                    characterData: true
                });
            }
        }""")

        # 1. Liens interactifs
        links = page.evaluate("""() => {
            return Array.from(document.querySelectorAll('a')).map((a, idx) => ({
                idx: idx,
                href: a.getAttribute('href'),
                text: a.innerText.trim(),
                id: a.id,
                hasOnclick: a.hasAttribute('onclick') || !!a.onclick,
                role: a.getAttribute('role'),
                selector: a.id ? '#' + a.id : 'a:nth-of-type(' + (idx + 1) + ')',
                outerHTML: a.outerHTML.substring(0, 100)
            }));
        }""")

        for l in links:
            raw_href = l["href"]
            if not raw_href or raw_href.strip() == "#":
                # Tester dynamiquement le clic réel sur le lien
                page.evaluate("() => { window.__domMutations = 0; }")
                url_before = page.url
                mutated = False
                navigated = False
                try:
                    locator = page.locator(l["selector"]).first
                    locator.click(timeout=800)
                    page.wait_for_timeout(100)
                    url_after = page.url
                    muts = page.evaluate("() => window.__domMutations")
                    mutated = (muts > 0)
                    base_before = url_before.split('#')[0]
                    base_after = url_after.split('#')[0]
                    navigated = (base_before != base_after)
                except Exception:
                    pass

                # Si le clic a provoqué une mutation DOM, une navigation réelle ou comporte un gestionnaire JS :
                if mutated or navigated or l.get("hasOnclick"):
                    # Le lien est interactif et fonctionnel (ex: modale, action SPA)
                    pass
                else:
                    self.findings.append(A11yFinding(
                        finding_id=self._next_id(),
                        rule="FUNCTIONAL_EMPTY_HREF",
                        severity="MEDIUM",
                        confidence="CONFIRMED",
                        element_selector=l["selector"],
                        element_html=l["outerHTML"],
                        page_url=url,
                        observed_behavior=f"Lien inerte ('{l['text'] or 'Sans texte'}') : href vide ou '#' testé par clic réel sans mutation DOM ni navigation.",
                        expected_behavior="Un lien hypertexte doit pointer vers une ancre ou une ressource valide, ou être converti en <button> s'il déclenche une action JS.",
                        reproduction_steps=["Cliquer sur le lien en navigateur réel", "Constater l'absence de navigation et de mutation DOM."],
                        evidence_path=None,
                        standard="WCAG 2.1 SC 2.4.4 Fonction du lien",
                        proposed_patch=f"<button type=\"button\">{l['text'] or 'Action'}</button>"
                    ))

        # 2. Boutons
        buttons = page.evaluate("""() => {
            return Array.from(document.querySelectorAll('button')).map((b, idx) => ({
                idx: idx,
                text: b.innerText.trim(),
                type: b.getAttribute('type') || 'submit',
                disabled: b.disabled,
                hasOnclick: b.hasAttribute('onclick') || !!b.onclick,
                id: b.id,
                className: b.className,
                ariaLabel: b.getAttribute('aria-label') || '',
                selector: b.id ? '#' + b.id : 'button:nth-of-type(' + (idx + 1) + ')',
                outerHTML: b.outerHTML.substring(0, 100)
            }));
        }""")

        for b in buttons:
            # Bouton sans texte et sans aria-label
            if not b["text"] and not b["ariaLabel"]:
                self.findings.append(A11yFinding(
                    finding_id=self._next_id(),
                    rule="WCAG_BUTTON_EMPTY_LABEL",
                    severity="HIGH",
                    confidence="CONFIRMED",
                    element_selector=b["selector"],
                    element_html=b["outerHTML"],
                    page_url=url,
                    observed_behavior="Bouton <button> sans texte visible ni attribut aria-label.",
                    expected_behavior="Tout bouton doit fournir un libellé clair pour les technologies d'assistance.",
                    reproduction_steps=["Inspecter le bouton", "Constater l'absence de texte et de aria-label."],
                    evidence_path=None,
                    standard="WCAG 2.1 SC 4.1.2 Nom, rôle et valeur",
                    proposed_patch=f"<button type=\"{b['type']}\" aria-label=\"Action\">{b['text'] or 'Libellé'}</button>"
                ))
            elif not b["disabled"] and not b["hasOnclick"] and b["type"] == "button":
                # Bouton de type button sans action déclarée, test dynamique au clic
                page.evaluate("() => { window.__domMutations = 0; }")
                try:
                    page.locator(b["selector"]).first.click(timeout=800)
                    page.wait_for_timeout(100)
                    muts = page.evaluate("() => window.__domMutations")
                    if muts == 0:
                        self.findings.append(A11yFinding(
                            finding_id=self._next_id(),
                            rule="FUNCTIONAL_INERT_BUTTON",
                            severity="LOW",
                            confidence="CONFIRMED",
                            element_selector=b["selector"],
                            element_html=b["outerHTML"],
                            page_url=url,
                            observed_behavior=f"Bouton '{b['text']}' inerte : aucun gestionnaire ni mutation DOM observée au clic.",
                            expected_behavior="Tout bouton interactif doit déclencher une action ou un changement d'état.",
                            reproduction_steps=["Cliquer sur le bouton en navigateur", "Constater l'absence de réaction."],
                            evidence_path=None,
                            standard="Usabilité & WCAG 2.1 SC 4.1.2",
                            proposed_patch=f"/* Ajouter un gestionnaire d'événement au bouton {b['selector']} */"
                        ))
                except Exception:
                    pass

    def _compute_accessibility_score(self) -> int:
        score = 100
        for f in self.findings:
            if f.severity == "CRITICAL":
                score -= 15
            elif f.severity == "HIGH":
                score -= 10
            elif f.severity == "MEDIUM":
                score -= 5
            elif f.severity == "LOW":
                score -= 2
        return max(0, score)

    def apply_and_verify_patch(
        self,
        target_dir: Path,
        file_relative: str,
        target_str: str,
        replacement_str: str,
        finding_id: str
    ) -> Tuple[bool, str]:
        """Applique un patch ciblé dans un répertoire de travail isolé et relance l'audit pour prouver la résolution."""
        file_path = (target_dir / file_relative).resolve()
        if not file_path.exists():
            return False, f"Fichier cible introuvable : {file_path}"

        original_content = file_path.read_text(encoding="utf-8")
        if target_str not in original_content:
            return False, f"Chaîne cible introuvable dans {file_relative}"

        patched_content = original_content.replace(target_str, replacement_str, 1)
        file_path.write_text(patched_content, encoding="utf-8")

        matching_finding = next((f for f in self.findings if f.finding_id == finding_id), None)
        if not matching_finding:
            return False, f"Anomalie {finding_id} introuvable dans l'audit initial"
        target_rule = matching_finding.rule

        # Ré-auditer le répertoire isolé
        post_audit = self.audit_target(target_dir, page_path=f"/{file_relative}")
        remaining_rules = [f["rule"] for f in post_audit["findings"]]

        # Vérifier si l'anomalie a disparu
        if target_rule not in remaining_rules:
            matching_finding.verification_status = "VERIFIED_FIXED"
            return True, f"Patch vérifié avec succès en navigateur réel : anomalie {finding_id} ({target_rule}) résolue !"
        else:
            return False, f"Le patch a été appliqué mais l'anomalie {finding_id} ({target_rule}) persiste ou une régression est survenue."
