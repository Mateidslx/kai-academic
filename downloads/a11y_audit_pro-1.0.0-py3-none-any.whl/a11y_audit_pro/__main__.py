# -*- coding: utf-8 -*-
"""Entry point for python -m a11y_audit_pro."""
from .cli import main

if __name__ == "__main__":
    main()
