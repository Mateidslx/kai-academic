# -*- coding: utf-8 -*-
"""tests/test_architecture_assessor.py
Tests rigoureux pour le moteur d'évaluation de sécurité d'architecture,
le laboratoire synthétique jetable et le cadre d'autorisation fail-closed.
"""

import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
WORKSPACE_ROOT = Path(__file__).resolve().parents[4]
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))

import pytest
import time
from sec_headers_sentinel.authorized_scope import (
    AuthorizedScope,
    EmergencyStopConfig,
    create_synthetic_lab_scope
)
from sec_headers_sentinel.synthetic_lab import SyntheticSecurityLab
from sec_headers_sentinel.architecture_assessor import ArchitectureSecurityAssessor
from sec_headers_sentinel.compatibility_matrix import get_internal_compatibility_matrix
from sec_headers_sentinel.remediation_concept import get_remediation_service_specification


def test_authorized_scope_validation():
    scope = create_synthetic_lab_scope()
    
    # Action autorisée
    ok, msg = scope.validate_action("127.0.0.1:8000", "rbac_boundary_test")
    assert ok is True
    assert "autorisée" in msg
    
    # Cible hors périmètre (Fail-Closed)
    ok_ext, msg_ext = scope.validate_action("google.com:443", "rbac_boundary_test")
    assert ok_ext is False
    assert "hors du périmètre" in msg_ext
    
    # Action interdite (prohibited)
    ok_ddos, msg_ddos = scope.validate_action("127.0.0.1:8000", "ddos_volumetric_flood")
    assert ok_ddos is False
    assert "formellement interdite" in msg_ddos
    
    # Technique non permise
    ok_tech, msg_tech = scope.validate_action("127.0.0.1:8000", "arbitrary_zero_day_fuzzing")
    assert ok_tech is False
    assert "non couverte" in msg_tech


def test_synthetic_lab_lifecycle():
    lab = SyntheticSecurityLab()
    lab.start()
    try:
        assert lab.port > 0
        assert lab.url.startswith("http://127.0.0.1:")
        
        # Requête santé sur palier public
        import urllib.request
        with urllib.request.urlopen(f"{lab.url}/api/health", timeout=3) as resp:
            assert resp.status == 200
            import json
            data = json.loads(resp.read().decode("utf-8"))
            assert data["status"] == "OK"
            assert data["tier"] == "PUBLIC"
            
        # Vérification journalisation défensive
        assert len(lab.security_events) > 0
    finally:
        lab.stop()


def test_architecture_assessor_full_assessment():
    lab = SyntheticSecurityLab()
    lab.start()
    try:
        assessor = ArchitectureSecurityAssessor()
        report = assessor.run_assessment(lab)
        
        assert report["scenarios_evaluated"] == 5
        assert report["summary"]["properly_blocked"] == 5
        assert report["summary"]["defensive_visibility_rate"] == "100%"
        assert report["lab_alerts_captured"] >= 4
        
        scenarios = {s["scenario_id"]: s for s in report["scenarios"]}
        
        # Scénario 1 : Externe non-authentifié
        s1 = scenarios["SCENARIO-01"]
        assert s1["is_blocked"] is True
        assert s1["defensive_detected"] is True
        assert "401" in s1["blocked_at"]
        assert len(s1["untested_paths"]) > 0
        
        # Scénario 2 : Employé ordinaire
        s2 = scenarios["SCENARIO-02"]
        assert s2["is_blocked"] is True
        assert s2["defensive_detected"] is True
        assert "403" in s2["blocked_at"]
        assert any(a["alert_type"] == "PRIVILEGE_ESCALATION_ATTEMPT" for a in s2["detection_alerts"])
        
        # Scénario 3 : Compte compromis
        s3 = scenarios["SCENARIO-03"]
        assert s3["is_blocked"] is True
        assert s3["defensive_detected"] is True
        assert "403" in s3["blocked_at"]
        assert any(a["alert_type"] == "INTERNAL_SERVICE_PROBE" for a in s3["detection_alerts"])
        
        # Scénario 4 : Admin privilégié
        s4 = scenarios["SCENARIO-04"]
        assert s4["is_blocked"] is True
        assert s4["security_verdict"] == "SECURE_BOUNDARY"
        
        # Scénario 5 : Compte de service (latéral bloqué)
        s5 = scenarios["SCENARIO-05"]
        assert s5["is_blocked"] is True
        assert s5["defensive_detected"] is True
        assert any(a["alert_type"] == "LATERAL_MOVEMENT_PROBE" for a in s5["detection_alerts"])
        
    finally:
        lab.stop()


def test_architecture_assessor_fail_closed_out_of_scope():
    # Périmètre vide ou non-conforme
    empty_scope = AuthorizedScope(
        target_name="Cible isolée",
        target_environments=["none"],
        allowed_domains=["internal.vault.corp"],
        allowed_ip_ranges=[],
        permitted_techniques=["rbac_boundary_test"],
        prohibited_actions=[]
    )
    
    lab = SyntheticSecurityLab()
    lab.start()
    try:
        assessor = ArchitectureSecurityAssessor(scope=empty_scope)
        with pytest.raises(PermissionError, match="bloquée par le mandat"):
            assessor.run_assessment(lab)
    finally:
        lab.stop()


def test_compatibility_matrix_and_remediation_concept():
    matrix = get_internal_compatibility_matrix()
    assert "categories" in matrix
    assert "SERVEURS_WEB_ET_REVERSE_PROXIES" in matrix["categories"]
    assert "AUTHENTIFICATION_ET_CONTROLE_D_ACCES" in matrix["categories"]
    assert "ISOLATION_ET_RESEAU" in matrix["categories"]
    
    # Vérification présence des statuts stricts
    statuses = [item["status"] for cat in matrix["categories"].values() for item in cat]
    assert "OPERATIONAL" in statuses
    assert "PARTIALLY_VERIFIED" in statuses
    assert "PLANNED" in statuses
    assert "UNSUPPORTED" in statuses
    
    spec = get_remediation_service_specification()
    assert len(spec["prohibitions"]) >= 3
    assert len(spec["qualifying_findings_criteria"]) >= 4
    assert len(spec["explicit_exclusions"]) >= 4
    assert len(spec["remediation_approval_protocol"]) == 5


def test_custom_scope_enforcement_and_synthetic_labeling():
    from core.kai_tools.cloud_engineering_tools import tool_run_architecture_assessment

    # 1. Test du label synthétique et disclaimer
    res_lab = tool_run_architecture_assessment(use_synthetic_lab=True)
    assert res_lab["status"] == "SUCCESS"
    assert res_lab["assessment_context"] == "SYNTHETIC_LAB"
    assert "laboratoire synthétique contrôlé" in res_lab["disclaimer"]

    # 2. Rejet Fail-Closed d'une cible externe non autorisée dans custom_scope
    bad_scope = {
        "target_name": "External Production Company",
        "target_environments": ["production"],
        "allowed_domains": ["api.company.com"],
        "allowed_ip_ranges": [],
        "permitted_techniques": ["passive_header_inspection"],
        "prohibited_actions": []
    }
    res_bad = tool_run_architecture_assessment(use_synthetic_lab=True, custom_scope=bad_scope)
    assert res_bad["status"] == "ERROR"
    assert res_bad["error_type"] == "ScopeEnforcementError"
    assert "non autorisée" in res_bad["message"]

    # 3. Rejet Fail-Closed de use_synthetic_lab=False
    res_no_lab = tool_run_architecture_assessment(use_synthetic_lab=False)
    assert res_no_lab["status"] == "ERROR"
    assert res_no_lab["error_type"] == "ScopeEnforcementError"

