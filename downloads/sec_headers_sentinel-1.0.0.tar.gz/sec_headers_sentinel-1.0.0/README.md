# sec-headers-sentinel v1.0.0
> **Inspecteur d'en-têtes HTTP de sécurité, durcisseur serveur & banc d'essai d'architecture (OWASP Compliant)**

[![Build](https://img.shields.io/badge/Build-Passing-emerald.svg)]()
[![Standard](https://img.shields.io/badge/Standard-OWASP_Top_10-blue.svg)]()
[![Format](https://img.shields.io/badge/Templates-Nginx_|_Caddy_|_FastAPI-orange.svg)]()
[![Platform](https://img.shields.io/badge/Platform-Windows_|_Linux-slate.svg)]()

Développé par **Matéi de Saint Leger & KAI Product Studio**.

---

## 🎯 Présentation du Produit

`sec-headers-sentinel` est un utilitaire de sécurité défensive et DevSecOps conçu pour analyser, noter et durcir instantanément les serveurs web et API face aux attaques courantes (Clickjacking, MIME Sniffing, injections XSS, vol de sessions et fuites d'en-têtes techniques).

### Fonctionnalités Clés :
1. **Audit Live d'URLs Distantes** : Analyse en temps réel des en-têtes HTTP renvoyés par tout serveur HTTPS avec calcul d'un score de conformité défensif sur 100.
2. **Couverture Complète OWASP & Mozilla Observatory** :
   - Strict-Transport-Security (HSTS avec preloading et subdomains).
   - Content-Security-Policy (CSP stricte avec frame-ancestors).
   - X-Content-Type-Options: nosniff.
   - Referrer-Policy & Permissions-Policy.
   - Contrôle des cookies (`Secure`, `HttpOnly`, `SameSite`).
   - Détection de fuites de version serveur (`Server`, `X-Powered-By`).
3. **Générateur de Gabarits de Durcissement** : Production de snippets de configuration prêts à l'emploi pour Nginx, Caddy, Apache et middleware FastAPI.
4. **Dashboards Visuels Autonomes** : Génération de rapports HTML exécutifs avec jauge SVG de sécurité et explications concrètes des risques.
5. **Intégration CI/CD** : Codes de sortie normalisés (`0` = conforme, `1` = failles détectées) et export JSON pour pipelines automatisés.

---

## 📦 Installation

```bash
pip install .
```

---

## 🛠️ Guide d'Utilisation

### 1. Scanner une URL en direct
```bash
# Rapport synthétique en console
sec-headers-sentinel scan https://example.com

# Générer un rapport HTML visuel haute fidélité
sec-headers-sentinel scan https://example.com --html rapport_securite.html
```

### 2. Générer une configuration de durcissement serveur
```bash
# Gabarit de durcissement Nginx
sec-headers-sentinel generate --server nginx

# Gabarit de durcissement Caddy
sec-headers-sentinel generate --server caddy

# Middleware de sécurité FastAPI
sec-headers-sentinel generate --server fastapi
```

### 3. Auditer des en-têtes JSON
```bash
sec-headers-sentinel audit-json '{"Strict-Transport-Security": "max-age=31536000", "X-Content-Type-Options": "nosniff"}'
```

---

## 🛡️ Intégration CI/CD

```yaml
- name: Inspect HTTP Security Headers
  run: |
    python -m sec_headers_sentinel scan https://staging.example.com --min-score 85
```
