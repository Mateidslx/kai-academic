# -*- coding: utf-8 -*-
"""
===============================================================================
Module: generator.py
Package: sec_headers_sentinel
Purpose: Dynamic Hardened Configuration Generator (Nginx, Caddy, Apache, FastAPI, Cloudflare).
Features:
  - Generates tailored blocks only for missing headers
  - Full OWASP hardened configurations
===============================================================================
"""

from typing import Dict, List, Optional, Any


class SnippetGenerator:
    """Generates hardened HTTP security header config blocks."""

    DIRECTIVES = {
        "strict-transport-security": {
            "nginx": 'add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;',
            "caddy": 'Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"',
            "apache": 'Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"',
            "fastapi": 'response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"',
        },
        "content-security-policy": {
            "nginx": 'add_header Content-Security-Policy "default-src \'self\'; script-src \'self\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data:; object-src \'none\'; frame-ancestors \'none\';" always;',
            "caddy": 'Content-Security-Policy "default-src \'self\'; script-src \'self\'; object-src \'none\'; frame-ancestors \'none\';"',
            "apache": 'Header always set Content-Security-Policy "default-src \'self\'; script-src \'self\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data:; object-src \'none\'; frame-ancestors \'none\';"',
            "fastapi": 'response.headers["Content-Security-Policy"] = "default-src \'self\'; object-src \'none\'; frame-ancestors \'none\';"',
        },
        "x-frame-options": {
            "nginx": 'add_header X-Frame-Options "DENY" always;',
            "caddy": 'X-Frame-Options "DENY"',
            "apache": 'Header always set X-Frame-Options "DENY"',
            "fastapi": 'response.headers["X-Frame-Options"] = "DENY"',
        },
        "x-content-type-options": {
            "nginx": 'add_header X-Content-Type-Options "nosniff" always;',
            "caddy": 'X-Content-Type-Options "nosniff"',
            "apache": 'Header always set X-Content-Type-Options "nosniff"',
            "fastapi": 'response.headers["X-Content-Type-Options"] = "nosniff"',
        },
        "referrer-policy": {
            "nginx": 'add_header Referrer-Policy "strict-origin-when-cross-origin" always;',
            "caddy": 'Referrer-Policy "strict-origin-when-cross-origin"',
            "apache": 'Header always set Referrer-Policy "strict-origin-when-cross-origin"',
            "fastapi": 'response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"',
        },
        "permissions-policy": {
            "nginx": 'add_header Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=()" always;',
            "caddy": 'Permissions-Policy "camera=(), microphone=(), geolocation=()"',
            "apache": 'Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"',
            "fastapi": 'response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"',
        },
    }

    @classmethod
    def generate_tailored(cls, missing_headers: List[str], server: str = "nginx") -> str:
        """Génère un bloc de configuration contenant UNIQUEMENT les en-têtes manquants identifiés."""
        server = server.lower().strip()
        lines = []

        if server == "nginx":
            lines.append("# --- Bloc d'En-têtes de Sécurité Recommandé (Nginx) ---")
            lines.append("# À insérer dans votre bloc server { ... } ou location / { ... }")
            for h in missing_headers:
                hk = h.lower().strip()
                if hk in cls.DIRECTIVES and "nginx" in cls.DIRECTIVES[hk]:
                    lines.append(cls.DIRECTIVES[hk]["nginx"])
            # Masquage de la bannière serveur
            lines.append("server_tokens off;")

        elif server == "caddy":
            lines.append("# --- Directive d'En-têtes de Sécurité Recommandée (Caddy) ---")
            lines.append("header {")
            for h in missing_headers:
                hk = h.lower().strip()
                if hk in cls.DIRECTIVES and "caddy" in cls.DIRECTIVES[hk]:
                    lines.append(f"    {cls.DIRECTIVES[hk]['caddy']}")
            lines.append("    -Server")
            lines.append("}")

        elif server == "apache":
            lines.append("# --- Configuration d'En-têtes Sécurisés (Apache / .htaccess) ---")
            lines.append("<IfModule mod_headers.c>")
            for h in missing_headers:
                hk = h.lower().strip()
                if hk in cls.DIRECTIVES and "apache" in cls.DIRECTIVES[hk]:
                    lines.append(f"    {cls.DIRECTIVES[hk]['apache']}")
            lines.append("    Header always unset X-Powered-By")
            lines.append("</IfModule>")

        elif server == "fastapi":
            lines.append("# --- Middleware FastAPI / Starlette ---")
            lines.append("from starlette.middleware.base import BaseHTTPMiddleware\n")
            lines.append("class SecurityHeadersMiddleware(BaseHTTPMiddleware):")
            lines.append("    async def dispatch(self, request, call_next):")
            lines.append("        response = await call_next(request)")
            for h in missing_headers:
                hk = h.lower().strip()
                if hk in cls.DIRECTIVES and "fastapi" in cls.DIRECTIVES[hk]:
                    lines.append(f"        {cls.DIRECTIVES[hk]['fastapi']}")
            lines.append("        return response")

        elif server == "cloudflare":
            lines.append("# --- Configuration Cloudflare Pages / Workers (_headers) ---")
            lines.append("/*")
            for h in missing_headers:
                hk = h.lower().strip()
                if hk in cls.DIRECTIVES and "caddy" in cls.DIRECTIVES[hk]:
                    val = cls.DIRECTIVES[hk]["caddy"]
                    parts = val.split(" ", 1)
                    if len(parts) == 2:
                        clean_val = parts[1].strip('"')
                        lines.append(f"  {parts[0]}: {clean_val}")

        elif server == "vercel":
            import json
            headers_list = []
            for h in missing_headers:
                hk = h.lower().strip()
                if hk in cls.DIRECTIVES and "caddy" in cls.DIRECTIVES[hk]:
                    val = cls.DIRECTIVES[hk]["caddy"]
                    parts = val.split(" ", 1)
                    if len(parts) == 2:
                        clean_val = parts[1].strip('"')
                        headers_list.append({"key": parts[0], "value": clean_val})
            vercel_cfg = {"headers": [{"source": "/(.*)", "headers": headers_list}]}
            lines.append("// --- Configuration Vercel (vercel.json) ---")
            lines.append(json.dumps(vercel_cfg, indent=2))

        return "\n".join(lines) + "\n"

    @classmethod
    def generate_nginx(cls) -> str:
        return cls.generate_tailored(list(cls.DIRECTIVES.keys()), server="nginx")

    @classmethod
    def generate_caddy(cls) -> str:
        return cls.generate_tailored(list(cls.DIRECTIVES.keys()), server="caddy")

    @classmethod
    def generate_apache(cls) -> str:
        return cls.generate_tailored(list(cls.DIRECTIVES.keys()), server="apache")

    @classmethod
    def generate_fastapi_middleware(cls) -> str:
        return cls.generate_tailored(list(cls.DIRECTIVES.keys()), server="fastapi")
