# -*- coding: utf-8 -*-
"""sec_headers_sentinel/synthetic_lab.py
Laboratoire synthétique jetable et multi-paliers pour l'évaluation de sécurité d'architecture.
Fournit un serveur HTTP multi-rôles avec journalisation défensive intégrée (Security Event Monitoring).
"""

from __future__ import annotations
import json
import time
import socket
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, Any, List, Optional, Tuple


class SyntheticLabHandler(SimpleHTTPRequestHandler):
    # Base de données d'utilisateurs et de rôles synthétiques
    ACCOUNTS = {
        ("emp_alice", "EmpPass123!"): {"role": "EMPLOYEE", "name": "Alice Dupont"},
        ("emp_bob", "CompromisedPass456!"): {"role": "EMPLOYEE", "name": "Bob Martin (Compromised)"},
        ("sec_admin", "AdminStrongPass789#"): {"role": "ADMIN", "name": "Security Administrator"}
    }
    SERVICE_TOKENS = {
        "svc_backup_token_xyz": {"role": "SERVICE_BACKUP", "allowed_endpoints": ["/internal/backup_status"]},
        "svc_vault_token_master": {"role": "SERVICE_VAULT", "allowed_endpoints": ["/internal/secrets/vault"]}
    }

    def log_message(self, format: str, *args):
        # Enregistrement dans les journaux de sécurité du laboratoire
        msg = format % args
        if hasattr(self.server, "security_events"):
            self.server.security_events.append({
                "timestamp": time.time(),
                "client": self.client_address[0],
                "message": msg
            })

    def _get_identity(self) -> Tuple_Identity:
        auth_header = self.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:].strip()
            svc = self.SERVICE_TOKENS.get(token)
            if svc:
                return svc["role"], svc
            return "UNAUTHENTICATED", None

        cookie_header = self.headers.get("Cookie", "")
        # Analyse cookie simulé session_role=...
        if "role=ADMIN" in cookie_header:
            return "ADMIN", {"name": "Admin via Session"}
        elif "role=EMPLOYEE" in cookie_header:
            return "EMPLOYEE", {"name": "Employee via Session"}

        return "UNAUTHENTICATED", None

    def _record_alert(self, alert_type: str, details: str):
        if hasattr(self.server, "alerts"):
            self.server.alerts.append({
                "timestamp": time.time(),
                "alert_type": alert_type,
                "client_ip": self.client_address[0],
                "endpoint": self.path,
                "details": details
            })

    def do_GET(self):
        role, ident = self._get_identity()
        clean_path = self.path.split("?")[0].lower()

        # 1. Palier Public
        if clean_path in ("/", "/index.html", "/robots.txt", "/api/health"):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "OK", "tier": "PUBLIC", "path": clean_path}).encode("utf-8"))
            return

        # 2. Palier Employé
        if clean_path.startswith("/employee/"):
            if role in ("EMPLOYEE", "ADMIN"):
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "status": "OK",
                    "tier": "EMPLOYEE",
                    "user": ident.get("name") if ident else role,
                    "documents": ["Rapport_Interne_Q3.pdf", "Guide_Securite.docx"]
                }).encode("utf-8"))
            else:
                self._record_alert("UNAUTHORIZED_ACCESS_ATTEMPT", f"Accès non authentifié tenté sur {clean_path}")
                self.send_response(401)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error": "Unauthorized", "message": "Connexion requise."}')
            return

        # 3. Palier Administration Restreinte
        if clean_path.startswith("/admin/"):
            if role == "ADMIN":
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "status": "OK",
                    "tier": "ADMIN",
                    "config": {"debug_mode": False, "auth_provider": "local_hmac"}
                }).encode("utf-8"))
            elif role == "EMPLOYEE":
                # Alerte de sécurité critique : escalade de privilèges tentée par un employé
                self._record_alert("PRIVILEGE_ESCALATION_ATTEMPT", f"L'employé a tenté d'accéder à l'interface admin : {clean_path}")
                self.send_response(403)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": "Forbidden", "message": "Privilèges administrateur requis."}).encode("utf-8"))
            else:
                self._record_alert("ANONYMOUS_ADMIN_PROBE", f"Probe externe non authentifié sur {clean_path}")
                self.send_response(401)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error": "Unauthorized"}')
            return

        # 4. Palier Interne & Comptes de Service
        if clean_path.startswith("/internal/"):
            if role == "SERVICE_BACKUP":
                if clean_path == "/internal/backup_status":
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"status": "BACKUP_HEALTHY", "last_run": "2026-10-10"}')
                else:
                    # Déplacement latéral bloqué !
                    self._record_alert("LATERAL_MOVEMENT_PROBE", f"Le compte de sauvegarde a tenté d'accéder à {clean_path}")
                    self.send_response(403)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": "Forbidden", "message": "Hors périmètre du compte de service."}).encode("utf-8"))
            elif role == "SERVICE_VAULT":
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"status": "VAULT_ACTIVE", "secrets_count": 42}')
            else:
                self._record_alert("INTERNAL_SERVICE_PROBE", f"Accès non autorisé au réseau interne sur {clean_path}")
                self.send_response(403)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": "Forbidden", "message": "Service réseau interne isolé."}).encode("utf-8"))
            return

        self.send_error(404, "Endpoint non trouvé")

    def do_POST(self):
        clean_path = self.path.split("?")[0].lower()
        if clean_path == "/api/login":
            content_len = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_len).decode("utf-8", errors="ignore")
            try:
                data = json.loads(body)
                u = data.get("username", "")
                p = data.get("password", "")
                user_info = self.ACCOUNTS.get((u, p))
                if user_info:
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    # Set cookie role
                    self.send_header("Set-Cookie", f"role={user_info['role']}; Path=/; HttpOnly; SameSite=Lax")
                    self.end_headers()
                    self.wfile.write(json.dumps({"ok": True, "role": user_info["role"], "name": user_info["name"]}).encode("utf-8"))
                else:
                    self._record_alert("FAILED_LOGIN_ATTEMPT", f"Échec de connexion pour l'utilisateur '{u}'")
                    self.send_response(401)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"ok": False, "error": "Identifiants invalides"}')
            except Exception:
                self.send_error(400, "Bad Request JSON")
            return

        self.send_error(404)


Tuple_Identity = tuple[str, Optional[Dict[str, Any]]]


class SyntheticSecurityLab:
    """Gestionnaire de cycle de vie du laboratoire de sécurité synthétique."""
    def __init__(self, port: Optional[int] = None):
        self.port = port or self._find_free_port()
        self.server = None
        self.thread = None
        self.url = f"http://127.0.0.1:{self.port}"
        self.security_events: List[Dict[str, Any]] = []
        self.alerts: List[Dict[str, Any]] = []

    def _find_free_port(self) -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('127.0.0.1', 0))
            return s.getsockname()[1]

    def start(self):
        self.server = ThreadingHTTPServer(('127.0.0.1', self.port), SyntheticLabHandler)
        self.server.security_events = self.security_events
        self.server.alerts = self.alerts
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        for _ in range(50):
            try:
                with socket.create_connection(('127.0.0.1', self.port), timeout=0.1):
                    break
            except OSError:
                time.sleep(0.05)

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
