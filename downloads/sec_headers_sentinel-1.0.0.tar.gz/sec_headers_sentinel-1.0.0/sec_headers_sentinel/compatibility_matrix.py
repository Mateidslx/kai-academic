# -*- coding: utf-8 -*-
"""sec_headers_sentinel/compatibility_matrix.py
Matrice de compatibilité interne d'évaluation de sécurité d'architecture.
Distingue formellement les environnements et technologies testés de la couverture planifiée.
"""

from typing import Dict, List, Any


def get_internal_compatibility_matrix() -> Dict[str, Any]:
    return {
        "title": "Matrice Interne de Compatibilité d'Architecture de Sécurité",
        "version": "1.0.0",
        "categories": {
            "SERVEURS_WEB_ET_REVERSE_PROXIES": [
                {"technology": "Python HTTP Base Server (Local loopback)", "status": "OPERATIONAL", "tested": True, "notes": "Testé en continu sous bancs d'essai Playwright et pytest."},
                {"technology": "Nginx TLS (Linux / ARM64 Ubuntu 22.04)", "status": "OPERATIONAL", "tested": True, "notes": "Testé sur VPS Oracle avec configuration reverse-proxy 443 -> 8765."},
                {"technology": "Apache HTTP Server (mod_headers, mod_auth)", "status": "PARTIALLY_VERIFIED", "tested": False, "notes": "Générateur de syntaxe validé, environnement de test actif planifié."},
                {"technology": "Caddy 2 Server", "status": "PARTIALLY_VERIFIED", "tested": False, "notes": "Générateur Caddyfile validé, lab d'exécution planifié."}
            ],
            "AUTHENTIFICATION_ET_CONTROLE_D_ACCES": [
                {"technology": "Session Cookie HttpOnly + SameSite=Lax", "status": "OPERATIONAL", "tested": True, "notes": "Validé avec révocation serveur et anti-rejeu de jetons."},
                {"technology": "Bearer Token Authorization (Service Accounts)", "status": "OPERATIONAL", "tested": True, "notes": "Validé sous lab synthétique multi-rôles."},
                {"technology": "HTTP Basic Auth (RFC 7617)", "status": "OPERATIONAL", "tested": True, "notes": "Validé avec rejet strict sur HTTP public non chiffré."},
                {"technology": "OAuth2 / OpenID Connect (OIDC)", "status": "PLANNED", "tested": False, "notes": "Intégration d'un mock Identity Provider (Keycloak) planifiée."},
                {"technology": "SAML 2.0 / Active Directory Kerberos", "status": "UNSUPPORTED", "tested": False, "notes": "Hors périmètre actuel des prototypes légers."}
            ],
            "ISOLATION_ET_RESEAU": [
                {"technology": "Contrôle RBAC applicatif", "status": "OPERATIONAL", "tested": True, "notes": "Évaluation prouvée sur 5 scénarios d'accès."},
                {"technology": "Encapsulation Tunnel SSH (ChaCha20 / AES)", "status": "OPERATIONAL", "tested": True, "notes": "Vérifié en conditions réelles avec le VPS Oracle."},
                {"technology": "Kubernetes NetworkPolicies / Cilium eBPF", "status": "PLANNED", "tested": False, "notes": "Nécessite un cluster de test dédié."},
                {"technology": "Cloudflare WAF / AWS Shield Advanced", "status": "UNSUPPORTED", "tested": False, "notes": "Aucune revendication de contournement de WAF externe."}
            ]
        }
    }
