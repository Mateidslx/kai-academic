# -*- coding: utf-8 -*-
"""sec_headers_sentinel/remediation_concept.py
Spécification conceptuelle interne du modèle de service "Évaluation d'Architecture puis Remédiation Séparée".
Document purement méthodologique interne (zéro prospection commerciale, zéro contact prospect, zéro allégation de vente).
"""

from typing import Dict, List, Any


def get_remediation_service_specification() -> Dict[str, Any]:
    return {
        "service_name": "Évaluation d'Architecture et Remédiation Séparée (Concept Interne)",
        "status": "INTERNAL_DESIGN_ONLY",
        "prohibitions": [
            "Interdiction absolue de contacter des prospects ou entreprises sans mandat préalable.",
            "Interdiction de promettre de trouver des vulnérabilités ou de traiter les failles comme des revenus acquis.",
            "Interdiction d'appliquer un correctif sur un environnement de production sans bon pour accord séparé."
        ],
        "qualifying_findings_criteria": [
            "Vulnérabilité d'architecture objective, documentée et reproductible de manière non destructive.",
            "Score de sévérité minimal CVSS v3.1 >= 4.0 (Medium / High / Critical).",
            "Chemin d'exploitation concret prouvé dans le cadre du mandat d'autorisation (absence de simple spéculation théorique).",
            "Défaut de configuration directe (ex: secret exposé, isolation latérale défaillante, RBAC contourné)."
        ],
        "explicit_exclusions": [
            "Attaques par déni de service (DDoS / épuisement de mémoire).",
            "Ingénierie sociale, phishing, collecte d'identifiants utilisateurs réels.",
            "Vulnérabilités amont dans des bibliothèques tierces sans correctif disponible (upstream 0-days).",
            "Problèmes purement cosmétiques ou divergences stylistiques sans impact sur la sécurité."
        ],
        "evidence_delivery_protocol": [
            "Livraison d'un dossier technique chiffré comprenant les étapes de reproduction exactes (PoC non destructif).",
            "Traces de journalisation défensive pour permettre à l'équipe cliente de vérifier la visibilité de ses sondes de sécurité (SIEM/IDS).",
            "Évaluation de l'impact métier et scénarios d'accès associés (employé, compromis, externe)."
        ],
        "remediation_approval_protocol": [
            "Phase 1 : Restitution du rapport d'évaluation d'architecture sans modification du système audité.",
            "Phase 2 : Émission d'une proposition de remédiation technique indépendante (devis et périmètre dédié).",
            "Phase 3 : Signature formelle du bon pour accord de remédiation par le responsable d'infrastructure.",
            "Phase 4 : Application du correctif dans une branche ou environnement de pré-production isolé.",
            "Phase 5 : Re-test contradictoire automatisé avant déploiement en production."
        ]
    }
