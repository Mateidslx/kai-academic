# -*- coding: utf-8 -*-
"""sec_headers_sentinel - HTTP Security Headers Auditor & CSP Policy Generator."""

__version__ = "1.0.0"
__author__ = "Matei de Saint Leger & KAI Product Studio"

from .scanner import HeaderSecurityScanner
from .generator import SnippetGenerator
from .reporter import generate_security_report

__all__ = [
    "HeaderSecurityScanner",
    "SnippetGenerator",
    "generate_security_report",
]
