# -*- coding: utf-8 -*-
"""
===============================================================================
Module: cli.py
Package: sec_headers_sentinel
Purpose: Command-Line Interface for SecHeaders Sentinel (v2.0).
Features:
  - Live URL scan with score, grade, cookie inspection, and server banner check
  - Automatic tailored server configuration generator (Nginx, Caddy, Apache, FastAPI)
  - Standalone executive HTML report export (--html)
===============================================================================
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .scanner import HeaderSecurityScanner
from .generator import SnippetGenerator
from .reporter import generate_security_report, generate_html_dashboard

# Ensure Windows terminal doesn't crash on emojis/accents
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="sec-headers-sentinel",
        description="Inspecteur professionnel d'en-têtes HTTP de sécurité et durcisseur serveur (OWASP Compliant)",
    )
    parser.add_argument("--version", action="version", version=f"sec-headers-sentinel {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)

    # Subcommand: scan (Live URL scan)
    scan_parser = subparsers.add_parser("scan", aliases=["audit"], help="Scanner une URL en direct et auditer sa conformité OWASP")
    scan_parser.add_argument("url", help="URL cible à inspecter (ex: https://monsite.fr)")
    scan_parser.add_argument("--server", choices=["nginx", "caddy", "apache", "fastapi", "cloudflare", "vercel"], default=None, help="Générer automatiquement le bloc de configuration adapté")
    scan_parser.add_argument("--html", help="Exporter un rapport exécutif HTML autonome vers ce chemin")
    scan_parser.add_argument("--json", action="store_true", help="Afficher les résultats au format JSON brut")

    # Subcommand: generate (Templates)
    gen_parser = subparsers.add_parser("generate", help="Générer un gabarit complet de durcissement serveur")
    gen_parser.add_argument("--server", choices=["nginx", "caddy", "apache", "fastapi", "cloudflare", "vercel"], default="nginx", help="Type de serveur web")

    # Subcommand: audit-json (Offline JSON audit)
    audit_parser = subparsers.add_parser("audit-json", help="Auditer un dictionnaire d'en-têtes HTTP JSON ou un fichier")
    audit_parser.add_argument("json_string", help="Chaîne JSON ou chemin de fichier JSON contenant les en-têtes")
    audit_parser.add_argument("--html", help="Exporter un rapport exécutif HTML autonome vers ce chemin")

    args = parser.parse_args()

    scanner = HeaderSecurityScanner()

    if args.command in ("scan", "audit"):
        res = scanner.scan_url(args.url)
        if "error" in res:
            if args.json:
                print(json.dumps(res, indent=2, ensure_ascii=False))
            else:
                print(f"❌ Erreur lors de l'inspection de {args.url} : {res['error']}", file=sys.stderr)
            sys.exit(2)

        if args.json:
            print(json.dumps(res, indent=2, ensure_ascii=False))
        else:
            # Affichage console professionnel
            score = res["score"]
            grade = res["grade"]
            status_icon = "🛡️ CONFORME" if res["is_secure"] else "⚠️ VULNÉRABLE"

            print("=" * 65)
            print(f"  SECHEADERS SENTINEL — RAPPORT D'AUDIT OWASP")
            print(f"  Cible : {res.get('effective_url', args.url)}")
            print("=" * 65)
            print(f"  Score Global     : {score}/100")
            print(f"  Note de Sécurité : {grade} ({status_icon})")
            print(f"  En-têtes validés : {res['headers_passed']}/{res['headers_checked']}")
            print("-" * 65)
            print(f"  {'EN-TÊTE':<30} | {'STATUT':<10} | {'POINTS'}")
            print("-" * 65)

            missing_headers = []
            for d in res["details"]:
                st = "PASS" if d["status"] == "PASS" else "MISSING"
                if d["status"] != "PASS":
                    missing_headers.append(d["header"])
                print(f"  {d['header']:<30} | {st:<10} | {d['points']}/25")

            print("=" * 65)

            if res.get("leak_audit"):
                print("\n⚠️  Divulgation d'informations serveur détectée :")
                for l in res["leak_audit"]:
                    print(f"   - {l['header']}: {l['value']}")

            if args.server:
                print(f"\n🔧 Correctif sur mesure pour {args.server.upper()} :\n")
                snippet = SnippetGenerator.generate_tailored(missing_headers, server=args.server)
                print(snippet)

        if args.html:
            html_content = generate_html_dashboard(res, domain=args.url)
            out_p = Path(args.html)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            out_p.write_text(html_content, encoding="utf-8")
            print(f"\n📊 Rapport HTML exécutif exporté avec succès : {out_p.resolve()}")

        sys.exit(0 if res["is_secure"] else 1)

    elif args.command == "generate":
        gen = SnippetGenerator()
        if args.server == "nginx":
            print(gen.generate_nginx())
        elif args.server == "caddy":
            print(gen.generate_caddy())
        elif args.server == "apache":
            print(gen.generate_apache())
        elif args.server == "fastapi":
            print(gen.generate_fastapi_middleware())
        elif args.server == "cloudflare":
            print(gen.generate_tailored(list(gen.DIRECTIVES.keys()), server="cloudflare"))
        elif args.server == "vercel":
            print(gen.generate_tailored(list(gen.DIRECTIVES.keys()), server="vercel"))

    elif args.command == "audit-json":
        try:
            p = Path(args.json_string)
            raw = p.read_text(encoding="utf-8") if p.exists() else args.json_string
            headers = json.loads(raw)
            res = scanner.audit_headers(headers)
            print(generate_security_report(res))

            if args.html:
                html_content = generate_html_dashboard(res, domain="Audit-JSON")
                Path(args.html).write_text(html_content, encoding="utf-8")
                print(f"\n📊 Rapport HTML exporté : {args.html}")

            sys.exit(0 if res["is_secure"] else 1)
        except Exception as e:
            print(f"Erreur d'analyse : {e}", file=sys.stderr)
            sys.exit(2)


if __name__ == "__main__":
    main()
