# -*- coding: utf-8 -*-
"""Entry point for python -m sec_headers_sentinel."""
from .cli import main

if __name__ == "__main__":
    main()
