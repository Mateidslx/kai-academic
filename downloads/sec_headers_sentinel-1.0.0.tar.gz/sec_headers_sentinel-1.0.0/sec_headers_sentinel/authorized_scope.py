# -*- coding: utf-8 -*-
"""sec_headers_sentinel/authorized_scope.py
Cadrage d'autorisation explicite et validation des règles d'engagement de sécurité.
Enforce le principe de moindre privilège et le blocage Fail-Closed de tout test hors périmètre.
"""

from __future__ import annotations
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
import ipaddress


@dataclass
class EmergencyStopConfig:
    emergency_stop_file: str = "EMERGENCY_STOP"
    max_requests_per_second: int = 20
    max_total_requests: int = 500


@dataclass
class AuthorizedScope:
    target_name: str
    target_environments: List[str]
    allowed_domains: List[str]
    allowed_ip_ranges: List[str]
    permitted_techniques: List[str]
    prohibited_actions: List[str]
    test_accounts: Dict[str, Dict[str, str]] = field(default_factory=dict)
    emergency_stop: EmergencyStopConfig = field(default_factory=EmergencyStopConfig)

    def validate_action(self, domain_or_ip: str, technique: str) -> Tuple_Validation:
        """Valide rigoureusement si une cible et une technique sont dans le périmètre autorisé."""
        # 1. Vérification des actions proscrites
        for prohibited in self.prohibited_actions:
            if prohibited.lower() in technique.lower():
                return False, f"Action formellement interdite par le mandat : {prohibited}"

        # 2. Vérification des techniques autorisées
        technique_allowed = any(t.lower() in technique.lower() for t in self.permitted_techniques)
        if not technique_allowed:
            return False, f"Technique non couverte par le périmètre autorisé : {technique}"

        # 3. Vérification du domaine / IP
        host_clean = domain_or_ip.split(":")[0].lower()
        if host_clean in [d.lower() for d in self.allowed_domains]:
            return True, "Cible et technique autorisées dans le périmètre."

        # Vérification plage IP
        try:
            ip_obj = ipaddress.ip_address(host_clean)
            for cidr in self.allowed_ip_ranges:
                if ip_obj in ipaddress.ip_network(cidr):
                    return True, "Adresse IP autorisée dans la plage couverte."
        except ValueError:
            pass

        return False, f"Cible '{domain_or_ip}' hors du périmètre autorisé ({self.allowed_domains})"


Tuple_Validation = tuple[bool, str]


class ScopeEnforcementError(PermissionError):
    """Exception formelle levée lors d'une tentative d'accès hors périmètre autorisé ou cible non couverte."""
    pass


def create_synthetic_lab_scope() -> AuthorizedScope:
    """Génère le mandat d'autorisation strict pour le laboratoire synthétique jetable."""
    return AuthorizedScope(
        target_name="Synthetic Disposable Security Lab",
        target_environments=["local_synthetic_sandbox", "cloud_disposable_lab"],
        allowed_domains=["127.0.0.1", "localhost"],
        allowed_ip_ranges=["127.0.0.1/32", "::1/128"],
        permitted_techniques=[
            "passive_header_inspection",
            "unauthenticated_traversal_test",
            "rbac_boundary_test",
            "credentialed_role_comparison",
            "lateral_movement_boundary_probe",
            "defensive_visibility_check"
        ],
        prohibited_actions=[
            "ddos",
            "denial_of_service",
            "destructive_write",
            "credential_stuffing",
            "phishing",
            "production_data_exfiltration",
            "brute_force_password_spray"
        ],
        test_accounts={
            "employee": {"username": "emp_alice", "role": "STANDARD_EMPLOYEE"},
            "compromised_employee": {"username": "emp_bob", "role": "COMPROMISED_EMPLOYEE_SIM"},
            "admin": {"username": "sec_admin", "role": "PRIVILEGED_ADMIN"},
            "service_account": {"token_id": "svc_backup_agent", "role": "BACKUP_SERVICE"}
        }
    )
