# -*- coding: utf-8 -*-
"""
===============================================================================
Module: scanner.py
Package: sec_headers_sentinel
Purpose: Production-grade HTTP Security Headers & Cookie Scanner (OWASP Compliant).
Features:
  - Live URL inspection (HTTPS, HTTP redirects, SSL/TLS boundary)
  - OWASP & Mozilla Web Security Guidelines scoring
  - Cookie security flag auditing (Secure, HttpOnly, SameSite)
  - Information disclosure detection (Server banner, X-Powered-By, etc.)
===============================================================================
"""

from __future__ import annotations

import re
import urllib.request
import urllib.error
import ssl
from typing import Dict, Any, List, Optional
from urllib.parse import urlparse


class HeaderSecurityScanner:
    """Audits HTTP response headers against OWASP and Mozilla Web Security Guidelines."""

    HEADER_SPECS = {
        "strict-transport-security": {
            "name": "HTTP Strict Transport Security (HSTS)",
            "weight": 25,
            "min_max_age": 31536000,
            "recommendation": "max-age=31536000; includeSubDomains; preload",
            "description": "Protège contre le déclassement SSL et l'interception de trafic (MITM).",
        },
        "content-security-policy": {
            "name": "Content Security Policy (CSP)",
            "weight": 30,
            "required_directives": ["default-src", "script-src"],
            "recommendation": "default-src 'self'; script-src 'self'; object-src 'none';",
            "description": "Bloque l'exécution de scripts non autorisés et les attaques XSS.",
        },
        "x-frame-options": {
            "name": "X-Frame-Options (Clickjacking Protection)",
            "weight": 15,
            "valid_values": ["DENY", "SAMEORIGIN"],
            "recommendation": "DENY",
            "description": "Empêche l'inclusion du site dans des iframes malveillantes (Clickjacking).",
        },
        "x-content-type-options": {
            "name": "X-Content-Type-Options (MIME Sniffing)",
            "weight": 10,
            "valid_values": ["nosniff"],
            "recommendation": "nosniff",
            "description": "Force le navigateur à respecter le type MIME déclaré (bloque les faux fichiers).",
        },
        "referrer-policy": {
            "name": "Referrer-Policy (Privacy)",
            "weight": 10,
            "valid_values": ["strict-origin-when-cross-origin", "no-referrer", "same-origin"],
            "recommendation": "strict-origin-when-cross-origin",
            "description": "Limite la fuite d'URLs et de données sensibles lors de clics externes.",
        },
        "permissions-policy": {
            "name": "Permissions-Policy (Feature Control)",
            "weight": 10,
            "recommendation": "camera=(), microphone=(), geolocation=()",
            "description": "Désactive les fonctionnalités matérielles invasives (caméra, micro, géolocalisation).",
        },
    }

    LEAK_HEADERS = [
        "server",
        "x-powered-by",
        "x-aspnet-version",
        "x-aspnetmvc-version",
        "x-generator",
        "x-runtime",
    ]

    def scan_url(self, target_url: str, timeout: int = 10) -> Dict[str, Any]:
        """Scanne une URL réelle en direct via HTTP/HTTPS avec gestion des redirections."""
        parsed = urlparse(target_url)
        if not parsed.scheme:
            target_url = "https://" + target_url
            parsed = urlparse(target_url)

        ctx = ssl.create_default_context()
        req = urllib.request.Request(
            target_url,
            headers={
                "User-Agent": "SecHeadersSentinel/2.0 (OWASP Auditor; +https://polar.sh/Mateidslx)",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
        )

        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                headers_dict: Dict[str, str] = {}
                cookies_list: List[str] = []
                for k, v in resp.headers.items():
                    if k.lower() == "set-cookie":
                        cookies_list.append(v)
                    else:
                        headers_dict[k] = v

                effective_url = resp.geturl()
                is_https = effective_url.startswith("https://")
                audit = self.audit_headers(headers_dict)
                audit["target_url"] = target_url
                audit["effective_url"] = effective_url
                audit["is_https"] = is_https
                audit["cookies_audit"] = self._audit_cookies(cookies_list)
                audit["leak_audit"] = self._audit_leak_headers(headers_dict)
                return audit
        except urllib.error.HTTPError as e:
            # Même en cas d'erreur HTTP 403 / 401, on peut analyser les en-têtes retournés
            headers_dict = dict(e.headers.items())
            audit = self.audit_headers(headers_dict)
            audit["target_url"] = target_url
            audit["effective_url"] = target_url
            audit["is_https"] = target_url.startswith("https://")
            audit["http_status"] = e.code
            audit["cookies_audit"] = self._audit_cookies([])
            audit["leak_audit"] = self._audit_leak_headers(headers_dict)
            return audit
        except Exception as exc:
            return {
                "target_url": target_url,
                "error": str(exc),
                "score": 0,
                "grade": "F",
                "is_secure": False,
                "details": [],
            }

    def _audit_cookies(self, cookies: List[str]) -> List[Dict[str, Any]]:
        """Vérifie la présence des drapeaux critiques Secure, HttpOnly et SameSite sur les cookies."""
        results = []
        for cookie_str in cookies:
            parts = [p.strip() for p in cookie_str.split(";")]
            name = parts[0].split("=")[0] if parts else "unknown"
            lower_parts = [p.lower() for p in parts]

            has_secure = "secure" in lower_parts
            has_httponly = "httponly" in lower_parts
            samesite_val = None
            for p in lower_parts:
                if p.startswith("samesite="):
                    samesite_val = p.split("=")[1]

            results.append({
                "cookie_name": name,
                "has_secure": has_secure,
                "has_httponly": has_httponly,
                "samesite": samesite_val,
                "is_secure": has_secure and has_httponly and (samesite_val in ("lax", "strict")),
            })
        return results

    def _audit_leak_headers(self, headers: Dict[str, str]) -> List[Dict[str, str]]:
        """Identifie les en-têtes de divulgation d'informations techniques (bannières de serveur)."""
        leaks = []
        lower_headers = {k.lower(): v for k, v in headers.items()}
        for leak in self.LEAK_HEADERS:
            if leak in lower_headers:
                leaks.append({
                    "header": leak,
                    "value": lower_headers[leak],
                    "recommendation": f"Supprimer ou masquer l'en-tête '{leak}' pour éviter la reconnaissance d'empreinte d'OS/serveur.",
                })
        return leaks

    def audit_headers(self, headers: Dict[str, str]) -> Dict[str, Any]:
        """Évalue un dictionnaire d'en-têtes HTTP selon les directives OWASP."""
        norm = {k.lower().strip(): v.strip() for k, v in headers.items()}
        score = 0
        details: List[Dict[str, Any]] = []

        for header_key, spec in self.HEADER_SPECS.items():
            val = norm.get(header_key)
            weight = spec["weight"]

            if not val:
                # Check if CSP frame-ancestors replaces x-frame-options
                if header_key == "x-frame-options" and "frame-ancestors" in norm.get("content-security-policy", ""):
                    score += weight
                    details.append({
                        "header": header_key,
                        "name": spec["name"],
                        "present": True,
                        "status": "PASS",
                        "value": "Couvert via CSP frame-ancestors",
                        "points": weight,
                        "description": spec["description"],
                    })
                    continue

                details.append({
                    "header": header_key,
                    "name": spec["name"],
                    "present": False,
                    "status": "MISSING",
                    "value": None,
                    "points": 0,
                    "recommendation": spec["recommendation"],
                    "description": spec["description"],
                })
            else:
                score += weight
                details.append({
                    "header": header_key,
                    "name": spec["name"],
                    "present": True,
                    "status": "PASS",
                    "value": val,
                    "points": weight,
                    "description": spec["description"],
                })

        grade = "A+" if score >= 95 else "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 50 else "F"

        return {
            "score": score,
            "max_score": 100,
            "grade": grade,
            "is_secure": score >= 75,
            "headers_checked": len(self.HEADER_SPECS),
            "headers_passed": sum(1 for d in details if d["status"] == "PASS"),
            "details": details,
        }
