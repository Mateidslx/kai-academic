# -*- coding: utf-8 -*-
"""
===============================================================================
Module: reporter.py
Package: sec_headers_sentinel
Purpose: Professional Report Generators (Markdown, Terminal, and Standalone Executive HTML Dashboard).
Features:
  - Clean Markdown reports for developer wikis / GitHub issues
  - Rich HTML executive dashboard with score gauge, dark mode, and remediation blocks
  - Tailored for both technical CTOs and non-technical clients/agencies
===============================================================================
"""

from __future__ import annotations

import html
import json
import time
from typing import Dict, Any, List

try:
    from .generator import SnippetGenerator
except ImportError:
    from sec_headers_sentinel.generator import SnippetGenerator


def generate_security_report(audit: Dict[str, Any], domain: str = "example.com") -> str:
    """Génère un rapport Markdown clair pour développeurs et tickets de remédiation."""
    target = audit.get("target_url", domain)
    lines = [
        f"# Rapport d'Audit de Sécurité des En-têtes HTTP (OWASP)",
        f"**Cible analysée** : `{target}`  ",
        f"**Date** : {time.strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Moteur** : `SecHeadersSentinel v2.0`  ",
        "",
        "## Résumé Exécutif",
        f"- **Score Global** : **{audit['score']}/100** (Note : **{audit['grade']}**)",
        f"- **Statut** : {'🛡️ SÉCURISÉ' if audit['is_secure'] else '⚠️ VULNÉRABLE / NON CONFORME OWASP'}",
        f"- **En-têtes Conformes** : {audit['headers_passed']}/{audit['headers_checked']}",
        "",
        "## Détail des En-têtes Analysés",
        "| En-tête | Statut | Points | Recommandation & Description |",
        "| :--- | :--- | :---: | :--- |",
    ]

    for d in audit.get("details", []):
        status_icon = "✅ PASS" if d["status"] == "PASS" else "❌ MISSING"
        desc = d.get("description", "")
        recom = f"<br>↳ *Recommandation :* `{d.get('recommendation')}`" if d["status"] != "PASS" else ""
        lines.append(f"| `{d['header']}` | {status_icon} | {d['points']}/25 | {desc}{recom} |")

    # Cookies section if present
    if audit.get("cookies_audit"):
        lines.extend([
            "",
            "## Audit des Cookies de Session (`Set-Cookie`)",
            "| Cookie | Secure Flag | HttpOnly Flag | SameSite | Conforme |",
            "| :--- | :---: | :---: | :---: | :---: |",
        ])
        for c in audit["cookies_audit"]:
            ok = "✅" if c["is_secure"] else "❌"
            lines.append(f"| `{c['cookie_name']}` | {'✅' if c['has_secure'] else '❌'} | {'✅' if c['has_httponly'] else '❌'} | `{c['samesite']}` | {ok} |")

    # Server leak section if present
    if audit.get("leak_audit"):
        lines.extend([
            "",
            "## Divulgation d'Informations Techniques (Bannières)",
        ])
        for l in audit["leak_audit"]:
            lines.append(f"- ⚠️ **{l['header']}** : `{l['value']}` ({l['recommendation']})")

    return "\n".join(lines)


def generate_html_dashboard(audit: Dict[str, Any], domain: str = "example.com") -> str:
    """
    Génère un tableau de bord HTML exécutif autonome, responsive et élégant.
    Ne requiert AUCUNE connexion externe (CSS et JS intégrés hermétiquement).
    Inclut des onglets interactifs de remédiation 1-click pour tous les serveurs majeurs.
    """
    target = audit.get("target_url", domain)
    score = audit.get("score", 0)
    grade = audit.get("grade", "F")
    is_secure = audit.get("is_secure", False)

    grade_color = "#10b981" if score >= 85 else "#f59e0b" if score >= 60 else "#ef4444"
    status_text = "NIVEAU DE PROTECTION ÉLEVÉ" if is_secure else "AMÉLIORATIONS CRITIQUES REQUISES"

    details_rows = []
    for d in audit.get("details", []):
        is_pass = d["status"] == "PASS"
        badge_bg = "#dcfce7" if is_pass else "#fee2e2"
        badge_color = "#166534" if is_pass else "#991b1b"
        badge_text = "CONFORME" if is_pass else "MANQUANT"
        val_display = f"<code>{html.escape(str(d.get('value', '')))}</code>" if is_pass else f"<span style='color: #ef4444; font-weight: 600;'>Non configuré</span> — Recommandé : <code>{html.escape(str(d.get('recommendation', '')))}</code>"

        details_rows.append(f"""
        <tr>
            <td style="font-weight: 600;">{html.escape(d['name'])} <br><small style="color: #64748b; font-weight: normal;">{html.escape(d['header'])}</small></td>
            <td><span style="background: {badge_bg}; color: {badge_color}; padding: 4px 10px; border-radius: 9999px; font-size: 0.75rem; font-weight: 700;">{badge_text}</span></td>
            <td>{d['points']} pts</td>
            <td>{val_display}<br><small style="color: #64748b;">{html.escape(d.get('description', ''))}</small></td>
        </tr>
        """)

    # Identification des en-têtes manquants pour la génération dynamique
    missing_headers = [d["header"] for d in audit.get("details", []) if d.get("status") != "PASS"]
    has_missing = len(missing_headers) > 0
    target_headers = missing_headers if has_missing else list(SnippetGenerator.DIRECTIVES.keys())

    nginx_snip = html.escape(SnippetGenerator.generate_tailored(target_headers, server="nginx"))
    caddy_snip = html.escape(SnippetGenerator.generate_tailored(target_headers, server="caddy"))
    apache_snip = html.escape(SnippetGenerator.generate_tailored(target_headers, server="apache"))
    cloudflare_snip = html.escape(SnippetGenerator.generate_tailored(target_headers, server="cloudflare"))
    vercel_snip = html.escape(SnippetGenerator.generate_tailored(target_headers, server="vercel"))
    fastapi_snip = html.escape(SnippetGenerator.generate_tailored(target_headers, server="fastapi"))

    domain_clean = target.replace("https://", "").replace("http://", "").split("/")[0]
    curl_cmd = html.escape(f"curl -s -D - \"https://{domain_clean}\" -o /dev/null | grep -iE 'strict-transport|content-security|x-frame|x-content-type|referrer-policy|permissions-policy'")

    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapport d'Audit de Sécurité Web — {html.escape(target)}</title>
    <style>
        :root {{
            --bg: #0f172a;
            --surface: #1e293b;
            --surface-alt: #0b1120;
            --border: #334155;
            --text: #f8fafc;
            --text-muted: #94a3b8;
            --primary: #38bdf8;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            padding: 40px 20px;
        }}
        .container {{ max-width: 1040px; margin: 0 auto; }}
        .header {{ margin-bottom: 30px; border-bottom: 1px solid var(--border); padding-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-end; }}
        .header h1 {{ font-size: 1.8rem; font-weight: 800; color: #fff; }}
        .header p {{ color: var(--text-muted); font-size: 0.95rem; margin-top: 5px; }}
        .badge-brand {{ background: #0284c7; color: #fff; font-size: 0.75rem; padding: 3px 8px; border-radius: 6px; text-transform: uppercase; font-weight: 700; }}
        
        .score-card {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 30px;
            display: grid;
            grid-template-columns: 200px 1fr;
            gap: 30px;
            align-items: center;
            margin-bottom: 30px;
        }}
        .gauge {{
            width: 160px;
            height: 160px;
            border-radius: 50%;
            background: conic-gradient({grade_color} {score * 3.6}deg, #334155 0deg);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
        }}
        .gauge-inner {{
            width: 125px;
            height: 125px;
            background: var(--surface);
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }}
        .gauge-score {{ font-size: 2.5rem; font-weight: 900; color: #fff; }}
        .gauge-grade {{ font-size: 0.85rem; font-weight: 700; color: {grade_color}; }}
        
        .summary-title {{ font-size: 1.4rem; font-weight: 700; margin-bottom: 8px; }}
        .summary-subtitle {{ color: var(--text-muted); font-size: 0.95rem; margin-bottom: 15px; }}
        
        .table-card {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
            margin-bottom: 30px;
        }}
        table {{ width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }}
        th {{ background: #0b1120; padding: 14px 18px; color: var(--text-muted); font-weight: 600; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.05em; }}
        td {{ padding: 16px 18px; border-top: 1px solid var(--border); vertical-align: top; }}
        tr:hover td {{ background: rgba(255, 255, 255, 0.02); }}
        
        code {{ background: #0b1120; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 0.85rem; color: #38bdf8; }}
        
        /* Interactive Remediation Tabs */
        .tabs-card {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
            margin-bottom: 30px;
        }}
        .tabs-header {{
            display: flex;
            flex-wrap: wrap;
            background: #090d16;
            border-bottom: 1px solid var(--border);
            padding: 8px 16px 0 16px;
            gap: 6px;
        }}
        .tab-btn {{
            background: transparent;
            border: 1px solid transparent;
            border-bottom: none;
            color: var(--text-muted);
            padding: 10px 18px;
            border-radius: 8px 8px 0 0;
            cursor: pointer;
            font-size: 0.85rem;
            font-weight: 600;
            transition: all 0.2s ease;
        }}
        .tab-btn:hover {{
            color: var(--text);
            background: rgba(255, 255, 255, 0.04);
        }}
        .tab-btn.active {{
            color: #38bdf8;
            background: var(--surface);
            border-color: var(--border);
            border-bottom: 1px solid var(--surface);
            margin-bottom: -1px;
        }}
        .tab-pane {{
            display: none;
            padding: 24px;
        }}
        .tab-pane.active {{
            display: block;
        }}
        .code-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            gap: 12px;
        }}
        .code-file {{
            font-family: monospace;
            font-size: 0.8rem;
            color: var(--text-muted);
        }}
        .copy-btn {{
            background: #0284c7;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 7px 14px;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: background 0.2s;
        }}
        .copy-btn:hover {{
            background: #0369a1;
        }}
        .code-block {{
            background: #090d16;
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 16px;
            overflow-x: auto;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            font-size: 0.85rem;
            color: #e2e8f0;
            line-height: 1.5;
            white-space: pre-wrap;
            word-break: break-all;
        }}
        
        /* Non-regression Verification Box */
        .verify-card {{
            background: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.95));
            border: 1px solid #0284c7;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 30px;
        }}
        .verify-title {{
            font-size: 1.1rem;
            font-weight: 700;
            color: #38bdf8;
            margin-bottom: 8px;
        }}

        .footer {{ text-align: center; color: var(--text-muted); font-size: 0.85rem; margin-top: 40px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <span class="badge-brand">SecHeaders Sentinel</span>
                <h1>Audit de Sécurité des En-têtes HTTP</h1>
                <p>Cible : <strong>{html.escape(target)}</strong> • Date : {time.strftime('%d/%m/%Y à %H:%M UTC')}</p>
            </div>
            <div style="text-align: right;">
                <span style="font-size: 0.85rem; color: var(--text-muted);">Standard OWASP & Mozilla Web Security</span>
            </div>
        </div>

        <div class="score-card">
            <div class="gauge">
                <div class="gauge-inner">
                    <span class="gauge-score">{score}</span>
                    <span class="gauge-grade">Note {grade}</span>
                </div>
            </div>
            <div>
                <h2 class="summary-title" style="color: {grade_color};">{status_text}</h2>
                <p class="summary-subtitle">
                    Ce rapport évalue la robustesse de votre infrastructure contre les attaques par Clickjacking, XSS, MIME-sniffing et écoute de trafic non chiffré.
                </p>
                <div style="display: flex; gap: 20px; font-size: 0.9rem;">
                    <div><strong>{audit.get('headers_passed', 0)} / {audit.get('headers_checked', 6)}</strong> En-têtes conformes</div>
                    <div><strong>{audit.get('score', 0)} / 100</strong> Points de durcissement</div>
                </div>
            </div>
        </div>

        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th style="width: 25%;">En-tête de Sécurité</th>
                        <th style="width: 15%;">Statut</th>
                        <th style="width: 10%;">Poids</th>
                        <th style="width: 50%;">Valeur Détectée & Recommandation</th>
                    </tr>
                </thead>
                <tbody>
                    {"".join(details_rows)}
                </tbody>
            </table>
        </div>

        <!-- Section Remédiation Interactive par Serveur -->
        <div class="tabs-card">
            <div style="padding: 20px 24px; border-bottom: 1px solid var(--border);">
                <h3 style="font-size: 1.2rem; font-weight: 700; color: #fff;">🔧 Guide de Remédiation Immédiate (1-Click Copy)</h3>
                <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 4px;">
                    {"Blocs de durcissement taillés sur mesure pour corriger les " + str(len(missing_headers)) + " vulnérabilités détectées." if has_missing else "Votre serveur est 100% conforme. Voici les gabarits de référence complets si vous migrez d'infrastructure."}
                </p>
            </div>
            <div class="tabs-header">
                <button class="tab-btn active" data-tab="tab-nginx" onclick="switchTab('tab-nginx')">Nginx</button>
                <button class="tab-btn" data-tab="tab-caddy" onclick="switchTab('tab-caddy')">Caddy</button>
                <button class="tab-btn" data-tab="tab-apache" onclick="switchTab('tab-apache')">Apache (.htaccess)</button>
                <button class="tab-btn" data-tab="tab-cloudflare" onclick="switchTab('tab-cloudflare')">Cloudflare Pages</button>
                <button class="tab-btn" data-tab="tab-vercel" onclick="switchTab('tab-vercel')">Vercel</button>
                <button class="tab-btn" data-tab="tab-fastapi" onclick="switchTab('tab-fastapi')">FastAPI / Python</button>
            </div>
            
            <div id="tab-nginx" class="tab-pane active">
                <div class="code-header">
                    <span class="code-file">Fichier : /etc/nginx/sites-available/default (dans server {{ ... }})</span>
                    <button class="copy-btn" onclick="copyCode('code-nginx', this)">📋 Copier Nginx</button>
                </div>
                <pre class="code-block"><code id="code-nginx">{nginx_snip}</code></pre>
            </div>

            <div id="tab-caddy" class="tab-pane">
                <div class="code-header">
                    <span class="code-file">Fichier : Caddyfile (directive header {{ ... }})</span>
                    <button class="copy-btn" onclick="copyCode('code-caddy', this)">📋 Copier Caddy</button>
                </div>
                <pre class="code-block"><code id="code-caddy">{caddy_snip}</code></pre>
            </div>

            <div id="tab-apache" class="tab-pane">
                <div class="code-header">
                    <span class="code-file">Fichier : .htaccess ou httpd.conf (&lt;IfModule mod_headers.c&gt;)</span>
                    <button class="copy-btn" onclick="copyCode('code-apache', this)">📋 Copier Apache</button>
                </div>
                <pre class="code-block"><code id="code-apache">{apache_snip}</code></pre>
            </div>

            <div id="tab-cloudflare" class="tab-pane">
                <div class="code-header">
                    <span class="code-file">Fichier : _headers (à la racine du projet Cloudflare Pages)</span>
                    <button class="copy-btn" onclick="copyCode('code-cloudflare', this)">📋 Copier Cloudflare</button>
                </div>
                <pre class="code-block"><code id="code-cloudflare">{cloudflare_snip}</code></pre>
            </div>

            <div id="tab-vercel" class="tab-pane">
                <div class="code-header">
                    <span class="code-file">Fichier : vercel.json (bloc headers)</span>
                    <button class="copy-btn" onclick="copyCode('code-vercel', this)">📋 Copier Vercel</button>
                </div>
                <pre class="code-block"><code id="code-vercel">{vercel_snip}</code></pre>
            </div>

            <div id="tab-fastapi" class="tab-pane">
                <div class="code-header">
                    <span class="code-file">Fichier : middleware.py (Starlette / FastAPI)</span>
                    <button class="copy-btn" onclick="copyCode('code-fastapi', this)">📋 Copier FastAPI</button>
                </div>
                <pre class="code-block"><code id="code-fastapi">{fastapi_snip}</code></pre>
            </div>
        </div>

        <!-- Test de non-régression terminal -->
        <div class="verify-card">
            <div class="verify-title">
                ⚡ Test de Non-Régression Instantané (Terminal)
            </div>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 12px;">
                Exécutez cette commande dans votre terminal après application pour vérifier en temps réel la présence des en-têtes configurés :
            </p>
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <pre class="code-block" style="flex: 1; margin: 0; padding: 10px 14px; min-width: 280px;"><code id="code-curl">{curl_cmd}</code></pre>
                <button class="copy-btn" style="white-space: nowrap; height: 42px;" onclick="copyCode('code-curl', this)">📋 Copier la commande</button>
            </div>
        </div>

        <div class="footer">
            Rapport certifié généré par SecHeaders Sentinel • Développé par Mateidslx
        </div>
    </div>

    <script>
        function switchTab(tabId) {{
            document.querySelectorAll('.tab-btn').forEach(function(b) {{ b.classList.remove('active'); }});
            document.querySelectorAll('.tab-pane').forEach(function(p) {{ p.classList.remove('active'); }});
            var btn = document.querySelector('[data-tab="' + tabId + '"]');
            var pane = document.getElementById(tabId);
            if (btn) btn.classList.add('active');
            if (pane) pane.classList.add('active');
        }}

        function copyCode(elementId, btn) {{
            var el = document.getElementById(elementId);
            if (!el) return;
            var text = el.innerText || el.textContent;
            navigator.clipboard.writeText(text).then(function() {{
                var origText = btn.innerHTML;
                btn.innerHTML = '✓ Copié !';
                btn.style.background = '#10b981';
                setTimeout(function() {{
                    btn.innerHTML = origText;
                    btn.style.background = '';
                }}, 2000);
            }}).catch(function(err) {{
                console.error('Erreur de copie:', err);
            }});
        }}
    </script>
</body>
</html>"""

