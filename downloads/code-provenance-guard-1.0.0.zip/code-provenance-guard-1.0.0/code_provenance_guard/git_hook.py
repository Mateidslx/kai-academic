# -*- coding: utf-8 -*-
"""Git Pre-commit Hook Manager."""
import os
import sys
from pathlib import Path

HOOK_SCRIPT = """#!/usr/bin/env python3
# Installed by code-provenance-guard
import sys
import subprocess

res = subprocess.run(["git", "diff", "--cached"], capture_output=True, text=True)
if res.returncode != 0:
    sys.exit(0)

from code_provenance_guard.detector import SecretDetector
detector = SecretDetector()
findings = detector.scan_content(res.stdout, source_path="git-staged-diff")

if findings:
    print("\\033[91m[BLOCKED] Commit rejected: Hardcoded secrets detected in staged changes!\\033[0m")
    for f in findings:
        print(f"  - Ligne {f['line']} : {f['type']} ({f['masked_match']})")
    print("Veuillez retirer les secrets avant de committer.")
    sys.exit(1)

sys.exit(0)
"""

class HookManager:
    @staticmethod
    def install(repo_path: Path) -> bool:
        hooks_dir = repo_path / ".git" / "hooks"
        if not hooks_dir.exists():
            return False
        pre_commit_file = hooks_dir / "pre-commit"
        pre_commit_file.write_text(HOOK_SCRIPT, encoding="utf-8")
        if os.name != "nt":
            pre_commit_file.chmod(0o755)
        return True
