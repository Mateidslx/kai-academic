# -*- coding: utf-8 -*-
"""CLI for code-provenance-guard."""
import argparse
import sys
from pathlib import Path
from .detector import SecretDetector
from .git_hook import HookManager

def main():
    parser = argparse.ArgumentParser(
        prog="code-provenance-guard",
        description="Détecteur heuristique de motifs de secrets sensibles par regex (Prototype interne)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Subcommand: scan
    scan_parser = subparsers.add_parser("scan", help="Scan a directory or file for hardcoded secrets")
    scan_parser.add_argument("path", default=".", nargs="?", help="Path to file or folder")

    # Subcommand: install-hook
    hook_parser = subparsers.add_parser("install-hook", help="Install git pre-commit hook in repository")
    hook_parser.add_argument("repo", default=".", nargs="?", help="Path to git repository root")

    args = parser.parse_args()

    if args.command == "install-hook":
        target = Path(args.repo).resolve()
        ok = HookManager.install(target)
        if ok:
            print(f"Hook pre-commit installé avec succès dans {target}/.git/hooks/pre-commit")
            sys.exit(0)
        else:
            print(f"Échec : le dossier .git/hooks est introuvable dans {target}", file=sys.stderr)
            sys.exit(1)

    elif args.command == "scan":
        target = Path(args.path)
        if not target.exists():
            print(f"Erreur : le chemin '{target}' est introuvable.", file=sys.stderr)
            sys.exit(2)
        detector = SecretDetector()
        total_findings = []

        if target.is_file():
            files = [target]
        else:
            files = [f for f in target.rglob("*") if f.is_file() and not any(p in str(f) for p in [".git", "__pycache__", "venv", ".pytest_cache"])]

        for f in files:
            try:
                content = f.read_text(encoding="utf-8", errors="ignore")
                findings = detector.scan_content(content, source_path=str(f))
                total_findings.extend(findings)
            except Exception:
                pass

        print(f"==================================================")
        print(f"  CODE PROVENANCE GUARD : {target}")
        print(f"  Fichiers analysés : {len(files)}")
        print(f"  Secrets détectés  : {len(total_findings)}")
        print(f"==================================================")

        for f in total_findings:
            print(f"  [ALERTE] {f['file']}:{f['line']} -> {f['type']} ({f['masked_match']})")

        sys.exit(0 if not total_findings else 1)

if __name__ == "__main__":
    main()
