# -*- coding: utf-8 -*-
"""Secret and Sensitive Token Detection Engine."""
import re
from typing import List, Dict, Any

class SecretDetector:
    """Scans code, commits and config files for hardcoded secrets and tokens."""

    PATTERNS = {
        "GITHUB_TOKEN": re.compile(r"gh[pousr]_[A-Za-z0-9_]{36,255}"),
        "OPENAI_API_KEY": re.compile(r"sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,128}"),
        "ANTHROPIC_API_KEY": re.compile(r"sk-ant-[A-Za-z0-9_-]{32,128}"),
        "AWS_ACCESS_KEY": re.compile(r"(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}"),
        "PRIVATE_KEY": re.compile(r"-----BEGIN (?:RSA|EC|OPENSSH|DSA|PGP|PRIVATE) KEY-----"),
        "STRIPE_SECRET_KEY": re.compile(r"sk_live_[0-9a-zA-Z]{24}"),
        "SLACK_BOT_TOKEN": re.compile(r"xoxb-[0-9]{11,13}-[0-9]{11,13}-[a-zA-Z0-9]{24}"),
        "GENERIC_PASSWORD": re.compile(r"""(?:password|passwd|secret|api_key)\s*[:=]\s*['"][^\s'"]{8,}['"]""", re.IGNORECASE)
    }

    def scan_content(self, text: str, source_path: str = "buffer") -> List[Dict[str, Any]]:
        findings = []
        for line_num, line in enumerate(text.splitlines(), 1):
            matched_specific = False
            for secret_type, regex in self.PATTERNS.items():
                if secret_type == "GENERIC_PASSWORD" and matched_specific:
                    continue
                match = regex.search(line)
                if match:
                    if secret_type != "GENERIC_PASSWORD":
                        matched_specific = True
                    val = match.group(0)
                    masked = val[:4] + "*" * (len(val) - 8) + val[-4:] if len(val) > 8 else "****"
                    findings.append({
                        "file": source_path,
                        "line": line_num,
                        "type": secret_type,
                        "masked_match": masked,
                        "severity": "CRITICAL"
                    })
        return findings
