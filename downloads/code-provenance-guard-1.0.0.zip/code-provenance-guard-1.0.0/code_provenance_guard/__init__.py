# -*- coding: utf-8 -*-
"""code_provenance_guard - AI Code Security & Secret Leak Pre-commit Guard."""

__version__ = "1.0.0"
__author__ = "Matei de Saint Leger & KAI Product Studio"

from .detector import SecretDetector
from .git_hook import HookManager

__all__ = ["SecretDetector", "HookManager"]
