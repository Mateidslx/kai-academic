# -*- coding: utf-8 -*-
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest
from code_provenance_guard.detector import SecretDetector

def test_detects_openai_key():
    detector = SecretDetector()
    fake_code = 'OPENAI_API_KEY = "sk-proj-1234567890abcdef1234567890abcdef12345678"'
    findings = detector.scan_content(fake_code)
    assert len(findings) == 1
    assert findings[0]["type"] == "OPENAI_API_KEY"

def test_detects_aws_key():
    detector = SecretDetector()
    fake_code = 'AWS_KEY = "AKIA1234567890ABCDEF"'
    findings = detector.scan_content(fake_code)
    assert len(findings) == 1
    assert findings[0]["type"] == "AWS_ACCESS_KEY"

def test_detects_stripe_key():
    detector = SecretDetector()
    fake_code = 'stripe_key = "sk_live_123456789012345678901234"'
    findings = detector.scan_content(fake_code)
    assert len(findings) == 1
    assert findings[0]["type"] == "STRIPE_SECRET_KEY"

def test_clean_code_zero_findings():
    detector = SecretDetector()
    clean_code = '''
def add(a, b):
    return a + b
'''
    findings = detector.scan_content(clean_code)
    assert len(findings) == 0
