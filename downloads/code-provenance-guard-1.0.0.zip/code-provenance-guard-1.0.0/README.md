# code-provenance-guard v1.0.0
> **Détecteur heuristique de motifs de secrets pour hook git pre-commit (Prototype d'apprentissage)**

[![Status](https://img.shields.io/badge/Status-Prototype_Interne-amber.svg)]()
[![Type](https://img.shields.io/badge/Type-Outil_D%C3%A9monstrateur-blue.svg)]()
[![Nature](https://img.shields.io/badge/Nature-D%C3%A9tection_Regex_Secrets-gray.svg)]()

Développé par **Matéi de Saint Leger** (Projet d'apprentissage BUT 1 Informatique).

---

## ℹ️ Présentation & Limites Techniques

`code-provenance-guard` est un script Python expérimental permettant d'intercepter les chaînes de caractères correspondant à des motifs connus de clés d'API avant validation d'un commit Git local.

### Ce que l'outil réalise :
1. Recherche par expressions régulières de motifs de jetons courants (OpenAI `sk-`, AWS `AKIA...`, Stripe `sk_live_`, jetons GitHub).
2. Fourniture d'un script d'installation de hook git `.git/hooks/pre-commit` local pour bloquer les commits contenant ces motifs.

### Limites strictes :
- **Ne garantit pas la provenance du code** : Il s'agit d'un simple filtre d'expressions régulières statiques. Il ne vérifie ni la paternité intellectuelle, ni les licences de code, ni la filiation d'entraînement IA.
- **Risques de faux positifs / faux négatifs** : Peut bloquer des tests contenant des faux jetons ou manquer des secrets au format atypique ou chiffré.
- Ne remplace pas des gestionnaires de secrets de niveau entreprise (Vault, AWS Secrets Manager, Gitleaks, TruffleHog).

---

## 🛠️ Utilisation CLI

```bash
# Scanner le dossier courant
code-provenance-guard scan .

# Installer le hook git pre-commit local
code-provenance-guard install-hook
```

---

## 💰 Statut Commercial & Tarifs
- **Statut** : Prototype interne et démonstrateur technique. **Aucune vente active, aucun chiffre d'affaires**.
- **Tarifs indicatifs affichés sur la démo** : 39 € (Solo) / 149 € (Équipe) — *Figures purement indicatives.*
