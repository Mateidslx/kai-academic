# -*- coding: utf-8 -*-
"""tests/test_visual_functional_auditor.py
Banc d'essai automatisé pour VisualFunctionalA11yAuditor :
1. Test en mode répertoire projet isolé avec serveur éphémère.
2. Détection en navigateur réel de 8 anomalies d'accessibilité et d'usabilité distinctes.
3. Vérification de la structure complète de chaque fiche d'anomalie.
4. Application d'un patch ciblé en workspace isolé et vérification effective de sa résolution par ré-audit.
"""

import sys
import shutil
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest
from a11y_audit_pro.browser_auditor import VisualFunctionalA11yAuditor, EphemeralServer


@pytest.fixture
def sample_web_project(tmp_path):
    """Crée une application web de test synthétique avec des anomalies ciblées."""
    proj_dir = tmp_path / "sample_site"
    proj_dir.mkdir()

    # Création d'une page HTML avec des défauts connus
    index_html = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <title></title>
  <style>
    body { font-family: sans-serif; background-color: #ffffff; margin: 0; padding: 20px; }
    .bad-contrast { color: #aaaaaa; background-color: #ffffff; font-size: 14px; }
    .wide-box { width: 600px; height: 50px; background: #e2e8f0; }
  </style>
</head>
<body>
  <h2>Sous-titre sans H1</h2>
  <h4>Titre H4 avec saut illégal</h4>
  
  <p class="bad-contrast">Texte avec un contraste insuffisant pour la lecture.</p>

  <img src="banner.jpg">

  <form>
    <input type="text" id="username" name="user">
  </form>

  <a href="#">Lien vide vers nul part</a>

  <button type="button" id="inertBtn"></button>

  <div class="wide-box">Boîte large provoquant un débordement sur petit écran</div>
</body>
</html>"""
    (proj_dir / "index.html").write_text(index_html, encoding="utf-8")
    return proj_dir


def test_browser_auditor_directory_mode(sample_web_project, tmp_path):
    report_dir = tmp_path / "reports"
    auditor = VisualFunctionalA11yAuditor(output_dir=report_dir, headless=True)

    result = auditor.audit_target(sample_web_project, page_path="/index.html")

    assert result["score"] < 80, f"Le score attendu doit être dégradé en raison des défauts, obtenu: {result['score']}"
    assert result["findings_count"] >= 5, f"Au moins 5 anomalies attendues, obtenu: {result['findings_count']}"

    rules_found = [f["rule"] for f in result["findings"]]
    # Vérification des règles clés
    assert "WCAG_DOC_LANG_MISSING" in rules_found
    assert "WCAG_PAGE_TITLE_EMPTY" in rules_found
    assert "WCAG_VIEWPORT_ZOOM_BLOCKED" in rules_found
    assert "WCAG_HEADING_NO_H1" in rules_found
    assert "WCAG_IMG_MISSING_ALT" in rules_found
    assert "WCAG_INPUT_MISSING_LABEL" in rules_found
    assert "FUNCTIONAL_EMPTY_HREF" in rules_found
    assert "WCAG_BUTTON_EMPTY_LABEL" in rules_found

    # Vérification qu'une capture d'écran pleine page a été générée
    assert Path(result["full_screenshot"]).exists()

    # Vérification de la structure d'une fiche d'anomalie
    finding = next(f for f in result["findings"] if f["rule"] == "WCAG_DOC_LANG_MISSING")
    assert finding["severity"] == "CRITICAL"
    assert finding["confidence"] == "CONFIRMED"
    assert len(finding["reproduction_steps"]) >= 2
    assert "SC 3.1.1" in finding["standard"]
    assert "lang=" in finding["proposed_patch"]


def test_patch_application_and_verification(sample_web_project, tmp_path):
    report_dir = tmp_path / "reports_patch"
    auditor = VisualFunctionalA11yAuditor(output_dir=report_dir, headless=True)

    # 1. Audit initial
    init_res = auditor.audit_target(sample_web_project, page_path="/index.html")
    lang_finding = next(f for f in auditor.findings if f.rule == "WCAG_DOC_LANG_MISSING")

    # 2. Application du correctif dans le répertoire isolé
    success, msg = auditor.apply_and_verify_patch(
        target_dir=sample_web_project,
        file_relative="index.html",
        target_str="<html>",
        replacement_str="<html lang=\"fr\">",
        finding_id=lang_finding.finding_id
    )

    assert success is True
    assert "vérifié avec succès" in msg
    assert lang_finding.verification_status == "VERIFIED_FIXED"


def test_ai_vision_auditor_live(sample_web_project, tmp_path):
    """Vérifie l'exécution effective du modèle d'IA vision multimodale sur la capture d'écran."""
    report_dir = tmp_path / "reports_vision"
    auditor = VisualFunctionalA11yAuditor(output_dir=report_dir, headless=True, enable_vision=True)
    result = auditor.audit_target(sample_web_project, page_path="/index.html")

    assert "vision_analysis" in result
    va = result["vision_analysis"]
    assert va is not None
    if va.get("status") == "ERROR" and any("RESOURCE_EXHAUSTED" in str(a.get("error", "")) or "429" in str(a.get("error", "")) for a in va.get("model_attempts", [])):
        pytest.skip(f"Gemini API quota exceeded for live vision test: {va.get('error')}")
    assert va["status"] == "SUCCESS"
    assert va["model_name"] in ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"]
    assert "x" in va["input_dimensions"]  # Ex: 1280x800
    assert "UNKNOWN" in va["billing_tier"]
    assert "monetary_cost" in va
    assert "token_usage" in va
    assert len(va["visual_conclusions"]) > 0
    assert va["confidence"] >= 0.5
    assert va["scotopic_comfort_rating"] in ["EXCELLENT", "ACCEPTABLE", "HARSH"]
    assert len(va["contextual_discrimination"]) > 0


def test_ai_vision_auditor_mocked_success(tmp_path):
    """Vérifie le parsing complet du résultat vision lorsque le modèle répond avec succès (indépendant des quotas API)."""
    from unittest.mock import MagicMock
    from a11y_audit_pro.browser_auditor import VisionAuditor
    from PIL import Image

    img_path = tmp_path / "mock_screen.png"
    Image.new("RGB", (800, 600), color="white").save(img_path)

    auditor = VisionAuditor()
    mock_resp = MagicMock()
    mock_resp.text = '{"visual_conclusions": "Interface sobre et claire", "contextual_discrimination": "Aucun conflit texte/image", "scotopic_comfort_rating": "EXCELLENT", "issues_detected": [], "confidence": 0.98}'
    mock_usage = MagicMock()
    mock_usage.prompt_token_count = 120
    mock_usage.candidates_token_count = 45
    mock_usage.total_token_count = 165
    mock_resp.usage_metadata = mock_usage

    auditor._client = MagicMock()
    auditor._client.models.generate_content.return_value = mock_resp

    res = auditor.analyze_page_screenshot(img_path)
    assert res["status"] == "SUCCESS"
    assert res["confidence"] == 0.98
    assert res["scotopic_comfort_rating"] == "EXCELLENT"
    assert res["visual_conclusions"] == "Interface sobre et claire"
    assert res["token_usage"]["total_token_count"] == 165



def test_ai_vision_auditor_offline_no_invented_conclusions(tmp_path):
    """Prouve que sans client IA de vision, l'auditeur renvoie NOT_EVALUATED
    sans inventer de conclusions, de confort ou de score de confiance."""
    from a11y_audit_pro.browser_auditor import VisionAuditor
    from PIL import Image

    img_path = tmp_path / "test_screenshot.png"
    Image.new("RGB", (800, 600), color="white").save(img_path)

    va = VisionAuditor()
    va._client = None  # Simule l'absence de client
    res = va.analyze_page_screenshot(img_path)

    assert res["status"] == "NOT_EVALUATED"
    assert res["model_name"] is None
    assert res["visual_conclusions"] is None
    assert res["scotopic_comfort_rating"] is None
    assert res["issues_detected"] is None
    assert res["confidence"] == 0.0
    assert "non configuré" in res["error"]


def test_dynamic_interactive_controls_vs_inert(tmp_path):
    """Prouve que l'auditeur teste dynamiquement le comportement au clic et ne signale pas

    un lien href='#' s'il déclenche une action JS ou mutation DOM réelle."""
    proj_dir = tmp_path / "dynamic_site"
    proj_dir.mkdir()

    html = """<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Test Interactivité Dynamique</title>
</head>
<body>
  <h1>Page avec contrôles mixtes</h1>

  <!-- Lien avec href='#' mais muni d'une action JS qui mute le DOM -->
  <a href="#" id="modalOpener" onclick="document.getElementById('modal').style.display='block'; return false;">Ouvrir la Modale</a>
  <div id="modal" style="display:none;">Contenu de la modale dynamique</div>

  <!-- Lien inerte sans gestionnaire ni destination -->
  <a href="#" id="inertDeadLink">Lien Inerte Sans Action</a>

  <!-- Bouton actif -->
  <button type="button" id="activeBtn" onclick="document.getElementById('res').innerText='Clique';">Action</button>
  <div id="res"></div>

  <!-- Bouton inerte sans gestionnaire -->
  <button type="button" id="inertBtn">Bouton Inerte</button>
</body>
</html>"""
    (proj_dir / "index.html").write_text(html, encoding="utf-8")

    report_dir = tmp_path / "reports_dyn"
    auditor = VisualFunctionalA11yAuditor(output_dir=report_dir, headless=True, enable_vision=False)
    result = auditor.audit_target(proj_dir, page_path="/index.html")

    findings = result["findings"]
    empty_href_findings = [f for f in findings if f["rule"] == "FUNCTIONAL_EMPTY_HREF"]
    
    # Doit détecter EXACTEMENT le lien inerte (#inertDeadLink), mais PAS #modalOpener !
    assert len(empty_href_findings) == 1
    assert "inertDeadLink" in empty_href_findings[0]["element_selector"]
    assert "modalOpener" not in empty_href_findings[0]["element_selector"]

    # Doit détecter le bouton inerte (#inertBtn)
    inert_btn_findings = [f for f in findings if f["rule"] == "FUNCTIONAL_INERT_BUTTON"]
    assert len(inert_btn_findings) == 1
    assert "inertBtn" in inert_btn_findings[0]["element_selector"]

