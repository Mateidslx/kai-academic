# a11y-audit-pro v1.0.0
> **Suite professionnelle d'audit d'accessibilité numérique WCAG 2.1 AAA, confort scotopique et neuro-ergonomie**

[![Build](https://img.shields.io/badge/Build-Passing-emerald.svg)]()
[![Standard](https://img.shields.io/badge/Standard-WCAG_2.1_AAA-blue.svg)]()
[![Format](https://img.shields.io/badge/Reports-JSON_|_SARIF_|_HTML-purple.svg)]()
[![Platform](https://img.shields.io/badge/Platform-Windows_|_Linux-slate.svg)]()

Développé par **Matéi de Saint Leger & KAI Product Studio**.

---

## 🎯 Présentation du Produit

`a11y-audit-pro` est une suite logicielle complète pour auditer, corriger et certifier l'accessibilité des applications web et documents HTML.  
Elle combine un moteur d'inspection DOM par navigateur Playwright réel, une cascade de vision multimodale assistée par IA, et un analyseur de neuro-ergonomie pour le confort scotopique et les neurodivergences.

### Fonctionnalités Clés :
1. **Audit Navigateur Réel (Playwright)** : Rendu du DOM vivant, calcul de l'arbre d'accessibilité natif et capture d'écran haute résolution.
2. **Conformité Mathématique WCAG 2.1 AAA** : Vérification stricte des ratios de contraste (SC 1.4.3 pour AA : 4.5:1, SC 1.4.6 pour AAA : 7.0:1) avec calcul de luminance relative W3C.
3. **Analyseur Scotopique & Ergonomie Visuelle** : Détection des agressions rétiniennes (contrastes criards, fonds néon) et propositions de palettes douces adaptées.
4. **Vérification Contradictoire de Correctifs** : Évaluation sandboxée des patches d'accessibilité pour vérifier l'absence de régressions fonctionnelles.
5. **Rapports Multi-Standards** : Exportation directe en CLI, JSON structuré, Markdown, rapports SARIF pour GitHub Security Center, et dashboards HTML interactifs.

---

## 📦 Installation

```bash
pip install .
```

---

## 🛠️ Guide d'Utilisation

### 1. Analyse statique d'un fichier HTML local
```bash
a11y-audit-pro scan index.html --format text
```

### 2. Calcul du ratio de contraste entre deux couleurs
```bash
# Vérification de conformité AA / AAA pour du texte standard
a11y-audit-pro contrast "#0f172a" "#f8fafc"

# Pour du texte grand format ou éléments d'interface
a11y-audit-pro contrast "#3b82f6" "#ffffff" --large-text
```

### 3. Audit complet en navigateur Playwright
```bash
# Audit d'une URL publique
a11y-audit-pro audit https://example.com --report-format html --output rapport_a11y.html

# Audit d'un répertoire de projet web local avec serveur éphémère
a11y-audit-pro audit ./dist --report-format json --output audit_sarif.json
```

---

## 🛡️ Intégration CI/CD

Intégrez `a11y-audit-pro` dans vos workflows GitHub Actions pour bloquer les régressions d'accessibilité avant chaque mise en production :

```yaml
- name: Run a11y audit
  run: |
    python -m a11y_audit_pro scan build/index.html --format json > a11y_results.json
```
