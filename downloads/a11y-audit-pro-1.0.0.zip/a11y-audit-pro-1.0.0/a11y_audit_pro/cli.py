# -*- coding: utf-8 -*-
"""Command-line interface for a11y-audit-pro."""
import argparse
import sys
import os
from pathlib import Path
from .scanner import HtmlA11yScanner
from .contrast import calculate_contrast_ratio, is_wcag_compliant
from .scotopic import ScotopicAnalyzer
from .reporters import generate_json_report, generate_markdown_report, generate_html_report

def main():
    parser = argparse.ArgumentParser(
        prog="a11y-audit-pro",
        description="Vérificateur heuristique basique HTML et contraste colorimétrique (Prototype interne)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Subcommand: scan
    scan_parser = subparsers.add_parser("scan", help="Scan an HTML file for accessibility compliance")
    scan_parser.add_argument("file", help="Path to local HTML file to audit")
    scan_parser.add_argument("--format", choices=["text", "json", "markdown", "html"], default="text", help="Output format")
    scan_parser.add_argument("--output", help="Optional output file path")
    scan_parser.add_argument("--bg", default="#FAF8F5", help="Background color for scotopic contrast test (hex)")
    scan_parser.add_argument("--text-color", default="#1C1917", help="Text color for contrast test (hex)")

    # Subcommand: contrast
    contrast_parser = subparsers.add_parser("contrast", help="Evaluate contrast ratio between two hex colors")
    contrast_parser.add_argument("color1", help="First color (hex, e.g. #FFFFFF)")
    contrast_parser.add_argument("color2", help="Second color (hex, e.g. #0F172A)")
    contrast_parser.add_argument("--large-text", action="store_true", help="Evaluate for large text threshold (>=18pt or 14pt bold)")

    args = parser.parse_args()

    if args.command == "contrast":
        try:
            ratio = calculate_contrast_ratio(args.color1, args.color2)
            comp = is_wcag_compliant(ratio, is_large_text=args.large_text)
            print(f"==================================================")
            print(f"  A11Y CONTRAST AUDIT : {args.color1} vs {args.color2}")
            print(f"==================================================")
            print(f"  Contraste mesuré : {ratio}:1")
            print(f"  Conforme WCAG AA : {'OUI' if comp['aa_compliant'] else 'NON'} (seuil requis: {comp['required_aa']}:1)")
            print(f"  Conforme WCAG AAA: {'OUI' if comp['aaa_compliant'] else 'NON'} (seuil requis: {comp['required_aaa']}:1)")
            sys.exit(0 if comp['aa_compliant'] else 1)
        except Exception as e:
            print(f"Erreur de calcul : {e}", file=sys.stderr)
            sys.exit(2)

    elif args.command == "scan":
        target_path = Path(args.file)
        if not target_path.exists():
            print(f"Fichier introuvable : {target_path}", file=sys.stderr)
            sys.exit(2)

        content = target_path.read_text(encoding="utf-8", errors="replace")
        scanner = HtmlA11yScanner()
        audit_data = scanner.audit_html(content)

        scotopic_analyzer = ScotopicAnalyzer()
        scotopic_res = scotopic_analyzer.evaluate_palette(args.bg, args.text_color)
        audit_data["scotopic"] = scotopic_res

        if args.format == "json":
            out_str = generate_json_report(audit_data)
        elif args.format == "markdown":
            out_str = generate_markdown_report(audit_data, target_name=target_path.name)
        elif args.format == "html":
            out_str = generate_html_report(audit_data, target_name=target_path.name)
        else:
            # Text format
            print(f"==================================================")
            print(f"  A11Y AUDIT PRO : {target_path.name}")
            print(f"  Score Global  : {audit_data['score']}/100 ({audit_data['grade']})")
            print(f"  Conformité    : {'OUI' if audit_data['compliant'] else 'NON'}")
            print(f"  Anomalies     : {audit_data['findings_count']}")
            print(f"==================================================")
            for f in audit_data["findings"]:
                print(f"  [{f['severity']}] {f['rule']}: {f['message']}")
            print(f"  Score Scotopique: {scotopic_res['scotopic_score']}/100 ({scotopic_res['rating']})")
            out_str = None

        if out_str:
            if args.output:
                Path(args.output).write_text(out_str, encoding="utf-8")
                print(f"Rapport sauvegardé dans {args.output}")
            else:
                print(out_str)

        sys.exit(0 if audit_data['compliant'] else 1)

if __name__ == "__main__":
    main()
