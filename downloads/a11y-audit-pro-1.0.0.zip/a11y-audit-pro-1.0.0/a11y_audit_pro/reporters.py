# -*- coding: utf-8 -*-
"""Report Generators for a11y_audit_pro (JSON, Markdown, and Standalone HTML)."""
import json
import time
from typing import Dict, Any

def generate_json_report(audit_data: Dict[str, Any], pretty: bool = True) -> str:
    """Exports audit findings in machine-readable JSON format."""
    payload = {
        "generator": "a11y-audit-pro v1.0.0",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "summary": {
            "score": audit_data.get("score", 0),
            "grade": audit_data.get("grade", "N/A"),
            "compliant": audit_data.get("compliant", False),
            "findings_count": audit_data.get("findings_count", 0)
        },
        "findings": audit_data.get("findings", []),
        "scotopic_analysis": audit_data.get("scotopic", None)
    }
    return json.dumps(payload, indent=2 if pretty else None, ensure_ascii=False)

def generate_markdown_report(audit_data: Dict[str, Any], target_name: str = "Document") -> str:
    """Exports a professional Markdown report ready for client deliverables."""
    score = audit_data.get("score", 0)
    grade = audit_data.get("grade", "N/A")
    lines = [
        f"# Rapport d'Audit d'Accessibilité Web & Scotopique (WCAG 2.1)",
        f"**Cible auditée** : `{target_name}`  ",
        f"**Date d'audit** : {time.strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Outil** : `a11y-audit-pro v1.0.0` (Licence Commerciale)  ",
        "",
        "## Résumé Exécutif",
        f"- **Score Global d'Accessibilité** : **{score}/100**",
        f"- **Palier WCAG** : **{grade}**",
        f"- **Statut de Conformité** : {'✅ CONFORME' if audit_data.get('compliant') else '⚠️ NON CONFORME'}",
        f"- **Anomalies Détectées** : {audit_data.get('findings_count', 0)}",
        "",
        "## Anomalies & Recommandations de Remédiation",
    ]

    findings = audit_data.get("findings", [])
    if not findings:
        lines.append("Aucune anomalie critique détectée. Document conforme aux standards WCAG 2.1.")
    else:
        for i, f in enumerate(findings, 1):
            lines.extend([
                f"### {i}. [{f['severity']}] {f['rule']}",
                f"- **Constat** : {f['message']}",
                f"- **Recommandation** : {f['recommendation']}",
                ""
            ])

    scotopic = audit_data.get("scotopic")
    if scotopic:
        lines.extend([
            "## Évaluation Ergonomique & Scotopique (Confort Cognitif)",
            f"- **Score Scotopique** : {scotopic['scotopic_score']}/100 ({scotopic['rating']})",
            f"- **Ratio de contraste** : {scotopic['ratio']}:1",
            f"- **Risque d'éblouissement** : {'OUI (Fond trop brillant)' if scotopic['is_glare_risk'] else 'NON'}",
            ""
        ])

    return "\n".join(lines)

def generate_html_report(audit_data: Dict[str, Any], target_name: str = "Document") -> str:
    """Generates a standalone, beautiful HTML dashboard report."""
    md = generate_markdown_report(audit_data, target_name)
    score = audit_data.get("score", 0)
    grade = audit_data.get("grade", "N/A")
    color = "#10b981" if score >= 80 else "#f59e0b" if score >= 60 else "#ef4444"

    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Audit d'Accessibilité - {target_name}</title>
  <style>
    body {{ font-family: system-ui, -apple-system, sans-serif; background: #FAF8F5; color: #1C1917; padding: 2rem; max-width: 800px; margin: 0 auto; line-height: 1.6; }}
    .badge {{ display: inline-block; padding: 0.25rem 0.75rem; border-radius: 9999px; background: {color}; color: white; font-weight: bold; font-size: 0.875rem; }}
    .card {{ background: white; border: 1px solid #E7E5E4; border-radius: 1rem; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }}
    h1, h2, h3 {{ color: #0F172A; }}
    pre {{ background: #1E293B; color: #F1F5F9; padding: 1rem; border-radius: 0.5rem; overflow-x: auto; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>Rapport d'Audit d'Accessibilité Web</h1>
    <p><strong>Cible :</strong> {target_name} | <strong>Score :</strong> <span class="badge">{score}/100 ({grade})</span></p>
  </div>
  <div class="card">
    <pre>{md}</pre>
  </div>
</body>
</html>"""
