# -*- coding: utf-8 -*-
"""a11y_audit_pro - Professional WCAG 2.1 & Cognitive Accessibility Auditor."""

__version__ = "1.0.0"
__author__ = "Matei de Saint Leger & KAI Product Studio"

from .contrast import calculate_contrast_ratio, is_wcag_compliant
from .scanner import HtmlA11yScanner
from .scotopic import ScotopicAnalyzer
from .reporters import generate_json_report, generate_html_report, generate_markdown_report

__all__ = [
    "calculate_contrast_ratio",
    "is_wcag_compliant",
    "HtmlA11yScanner",
    "ScotopicAnalyzer",
    "generate_json_report",
    "generate_html_report",
    "generate_markdown_report",
]
