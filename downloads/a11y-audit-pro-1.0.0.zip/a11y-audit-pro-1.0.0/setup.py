#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name="a11y-audit-pro",
    version="1.0.0",
    description="Professional WCAG 2.1 AAA & Scotopic Cognitive Accessibility CLI Auditor",
    author="Matei de Saint Leger & KAI Product Studio",
    packages=find_packages(),
    python_requires=">=3.9",
    entry_points={
        "console_scripts": [
            "a11y-audit-pro=a11y_audit_pro.cli:main",
        ],
    },
)
