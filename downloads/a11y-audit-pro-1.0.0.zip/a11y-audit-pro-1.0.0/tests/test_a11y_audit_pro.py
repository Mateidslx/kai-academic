# -*- coding: utf-8 -*-
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest
from a11y_audit_pro.contrast import calculate_contrast_ratio, is_wcag_compliant, hex_to_rgb
from a11y_audit_pro.scotopic import ScotopicAnalyzer
from a11y_audit_pro.scanner import HtmlA11yScanner
from a11y_audit_pro.reporters import generate_json_report, generate_markdown_report, generate_html_report

def test_hex_to_rgb():
    assert hex_to_rgb("#FFFFFF") == (255, 255, 255)
    assert hex_to_rgb("#000000") == (0, 0, 0)
    assert hex_to_rgb("#FFF") == (255, 255, 255)

def test_contrast_ratio_black_white():
    ratio = calculate_contrast_ratio("#FFFFFF", "#000000")
    assert ratio >= 20.0
    comp = is_wcag_compliant(ratio)
    assert comp["aa_compliant"] is True
    assert comp["aaa_compliant"] is True

def test_scotopic_analyzer_calm_tint():
    analyzer = ScotopicAnalyzer()
    res = analyzer.evaluate_palette("#FAF8F5", "#1C1917")
    assert res["is_calming_tint"] is True
    assert res["scotopic_score"] >= 80

def test_html_scanner_valid():
    html = """<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Page Valide</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
  <h1>Titre Principal</h1>
  <img src="logo.png" alt="Logo Officiel">
</body>
</html>"""
    scanner = HtmlA11yScanner()
    res = scanner.audit_html(html)
    assert res["compliant"] is True
    assert res["score"] >= 90

def test_html_scanner_missing_lang_and_alt():
    html = """<html><head><title>Test</title></head><body><img src="test.jpg"></body></html>"""
    scanner = HtmlA11yScanner()
    res = scanner.audit_html(html)
    assert res["findings_count"] >= 2
    rules = [f["rule"] for f in res["findings"]]
    assert "doc_lang" in rules
    assert "img_alt_tags" in rules

def test_report_generation():
    data = {"score": 95, "grade": "AAA", "compliant": True, "findings_count": 0, "findings": []}
    json_out = generate_json_report(data)
    assert "a11y-audit-pro" in json_out
    md_out = generate_markdown_report(data, target_name="Index")
    assert "CONFORME" in md_out
    html_out = generate_html_report(data, target_name="Index")
    assert "<!DOCTYPE html>" in html_out
