# a11y-audit-pro v1.0.0
> **Vérificateur heuristique d'accessibilité HTML & contrastes de couleurs (Prototype d'apprentissage)**

[![Status](https://img.shields.io/badge/Status-Prototype_Interne-amber.svg)]()
[![Type](https://img.shields.io/badge/Type-Outil_D%C3%A9monstrateur-blue.svg)]()
[![Nature](https://img.shields.io/badge/Nature-V%C3%A9rifications_Heuristiques-gray.svg)]()

Développé par **Matéi de Saint Leger** (Projet d'apprentissage BUT 1 Informatique).

---

## ℹ️ Présentation & Limites Techniques Reconnues

`a11y-audit-pro` est un script en ligne de commande développé comme démonstrateur technique pour évaluer des balises HTML statiques et tester des contrastes colorimétriques.

### Ce que l'outil réalise :
1. Calcul mathématique du ratio de contraste entre deux couleurs hexadécimales via la formule W3C de luminance relative.
2. Vérification heuristique de présence de balises de base (`<html lang="...">`, présence d'attributs `alt` sur les images, balise `<title>`).
3. Génération de synthèses textuelles, JSON, Markdown ou HTML.

### Ce que l'outil NE fait PAS (Limites strictes) :
- **Aucune certification officielle** : Ne remplace en aucun cas un outil d'audit complet tel qu'[axe-core](https://www.deque.com/axe/axe-core/) ou Pa11y.
- **Aucune garantie de conformité WCAG AAA** : Les vérifications sont purement syntaxiques et statiques (sans exécution de DOM JavaScript interactif).
- **Aucun bénéfice médical ni thérapeutique** : Les calculs de confort visuel sont des indications heuristiques basées sur des ratios de contraste et ne constituent aucunement un diagnostic ni un traitement du syndrome d'Irlen/sensibilité scotopique.

---

## 📦 Installation Locale

```bash
pip install .
```

---

## 🛠️ Utilisation CLI

### 1. Analyse statique d'un fichier HTML local
```bash
a11y-audit-pro scan index.html --format text
```

### 2. Calcul du ratio de contraste de deux couleurs
```bash
a11y-audit-pro contrast "#FAF8F5" "#1C1917"
```

---

## 💰 Statut Commercial & Tarifs
- **Statut** : Prototype interne et démonstrateur technique. **Aucune vente active, aucun paiement traité**.
- **Tarifs indicatifs affichés sur la démo** : 29 € (Solo) / 99 € (Pro) — *Figures purement indicatives pour la simulation d'interface.*
