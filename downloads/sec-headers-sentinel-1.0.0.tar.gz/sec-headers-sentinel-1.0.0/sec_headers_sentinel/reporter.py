# -*- coding: utf-8 -*-
"""Report Generators for Security Headers Sentinel."""
import json
import time
from typing import Dict, Any

def generate_security_report(audit: Dict[str, Any], domain: str = "example.com") -> str:
    lines = [
        f"# Rapport d'Audit de Sécurité des En-têtes HTTP (OWASP)",
        f"**Cible** : `{domain}`  ",
        f"**Date** : {time.strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Générateur** : `sec-headers-sentinel v1.0.0` (Licence Commerciale)  ",
        "",
        "## Résumé",
        f"- **Score Global** : **{audit['score']}/100**",
        f"- **Note de Sécurité** : **{audit['grade']}**",
        f"- **Statut** : {'🛡️ SÉCURISÉ' if audit['is_secure'] else '⚠️ VULNÉRABLE / RISQUE OWASP'}",
        f"- **En-têtes Conformes** : {audit['headers_passed']}/{audit['headers_checked']}",
        "",
        "## Détail des En-têtes Analysés",
        "| En-tête | Statut | Valeur / Recommandation |",
        "| :--- | :--- | :--- |"
    ]

    for d in audit.get("details", []):
        status_icon = "✅ Présent" if d["status"] == "PASS" else "❌ Manquant"
        val = d["value"] if d["status"] == "PASS" else f"Recommandé : `{d.get('recommendation')}`"
        lines.append(f"| `{d['header']}` | {status_icon} | {val} |")

    return "\n".join(lines)
