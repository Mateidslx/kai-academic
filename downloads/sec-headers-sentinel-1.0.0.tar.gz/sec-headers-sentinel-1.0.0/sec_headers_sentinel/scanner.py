# -*- coding: utf-8 -*-
"""Security Headers Scanner & Evaluation Engine."""
from typing import Dict, Any, List

class HeaderSecurityScanner:
    """Audits HTTP response headers against OWASP and Mozilla Web Security Guidelines."""

    HEADER_SPECS = {
        "strict-transport-security": {
            "name": "HTTP Strict Transport Security (HSTS)",
            "weight": 25,
            "min_max_age": 31536000,
            "recommendation": "max-age=31536000; includeSubDomains; preload"
        },
        "content-security-policy": {
            "name": "Content Security Policy (CSP)",
            "weight": 30,
            "required_directives": ["default-src", "script-src"],
            "recommendation": "default-src 'self'; script-src 'self'; object-src 'none';"
        },
        "x-frame-options": {
            "name": "X-Frame-Options (Clickjacking Protection)",
            "weight": 15,
            "valid_values": ["DENY", "SAMEORIGIN"],
            "recommendation": "DENY"
        },
        "x-content-type-options": {
            "name": "X-Content-Type-Options (MIME Sniffing)",
            "weight": 10,
            "valid_values": ["nosniff"],
            "recommendation": "nosniff"
        },
        "referrer-policy": {
            "name": "Referrer-Policy (Privacy)",
            "weight": 10,
            "valid_values": ["strict-origin-when-cross-origin", "no-referrer", "same-origin"],
            "recommendation": "strict-origin-when-cross-origin"
        },
        "permissions-policy": {
            "name": "Permissions-Policy (Feature Control)",
            "weight": 10,
            "recommendation": "camera=(), microphone=(), geolocation=()"
        }
    }

    def audit_headers(self, headers: Dict[str, str]) -> Dict[str, Any]:
        norm = {k.lower().strip(): v.strip() for k, v in headers.items()}
        score = 0
        details: List[Dict[str, Any]] = []

        for header_key, spec in self.HEADER_SPECS.items():
            val = norm.get(header_key)
            weight = spec["weight"]

            if not val:
                # Check if CSP frame-ancestors replaces x-frame-options
                if header_key == "x-frame-options" and "frame-ancestors" in norm.get("content-security-policy", ""):
                    score += weight
                    details.append({
                        "header": header_key,
                        "present": True,
                        "status": "PASS",
                        "value": "Couvert via CSP frame-ancestors",
                        "points": weight
                    })
                    continue

                details.append({
                    "header": header_key,
                    "present": False,
                    "status": "MISSING",
                    "value": None,
                    "points": 0,
                    "recommendation": spec["recommendation"]
                })
            else:
                score += weight
                details.append({
                    "header": header_key,
                    "present": True,
                    "status": "PASS",
                    "value": val,
                    "points": weight
                })

        grade = "A+" if score >= 95 else "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 50 else "F"

        return {
            "score": score,
            "max_score": 100,
            "grade": grade,
            "is_secure": score >= 75,
            "headers_checked": len(self.HEADER_SPECS),
            "headers_passed": sum(1 for d in details if d["status"] == "PASS"),
            "details": details
        }
