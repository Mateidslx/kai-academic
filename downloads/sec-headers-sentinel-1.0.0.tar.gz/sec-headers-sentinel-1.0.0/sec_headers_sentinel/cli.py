# -*- coding: utf-8 -*-
"""CLI for sec-headers-sentinel."""
import argparse
import sys
import json
from .scanner import HeaderSecurityScanner
from .generator import SnippetGenerator
from .reporter import generate_security_report

def main():
    parser = argparse.ArgumentParser(
        prog="sec-headers-sentinel",
        description="Inspecteur statique d'en-têtes HTTP de sécurité et générateur de gabarits (Prototype interne)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Subcommand: generate
    gen_parser = subparsers.add_parser("generate", help="Generate hardened server configuration snippets")
    gen_parser.add_argument("--server", choices=["nginx", "caddy", "fastapi"], default="nginx")

    # Subcommand: audit-json
    audit_parser = subparsers.add_parser("audit-json", help="Audit headers from a JSON dictionary or file")
    audit_parser.add_argument("json_string", help="JSON string representing headers dictionary")

    args = parser.parse_args()

    if args.command == "generate":
        gen = SnippetGenerator()
        if args.server == "nginx":
            print(gen.generate_nginx())
        elif args.server == "caddy":
            print(gen.generate_caddy())
        elif args.server == "fastapi":
            print(gen.generate_fastapi_middleware())

    elif args.command == "audit-json":
        try:
            headers = json.loads(args.json_string)
            scanner = HeaderSecurityScanner()
            res = scanner.audit_headers(headers)
            print(generate_security_report(res))
            sys.exit(0 if res["is_secure"] else 1)
        except Exception as e:
            print(f"Erreur d'analyse : {e}", file=sys.stderr)
            sys.exit(2)

if __name__ == "__main__":
    main()
