# sec-headers-sentinel v1.0.0
> **Inspecteur statique d'en-têtes HTTP de sécurité & générateur de gabarits (Prototype d'apprentissage)**

[![Status](https://img.shields.io/badge/Status-Prototype_Interne-amber.svg)]()
[![Type](https://img.shields.io/badge/Type-Outil_D%C3%A9monstrateur-blue.svg)]()
[![Nature](https://img.shields.io/badge/Nature-Analyse_Statique_Headers-gray.svg)]()

Développé par **Matéi de Saint Leger** (Projet d'apprentissage BUT 1 Informatique).

---

## ℹ️ Présentation & Limites Techniques

`sec-headers-sentinel` est un utilitaire CLI expérimental permettant d'inspecter rapidement la présence d'en-têtes HTTP de sécurité et de produire des gabarits de configuration basiques.

### Ce que l'outil réalise :
1. Inspection des principaux en-têtes HTTP défensifs (HSTS, Content-Security-Policy, X-Frame-Options, X-Content-Type-Options, Referrer-Policy).
2. Génération de gabarits de configuration standardisés pour Nginx, Caddy et middleware FastAPI.

### Limites strictes :
- **Ne remplace pas un audit de sécurité web complet** ni un test d'intrusion.
- **Les snippets générés sont génériques** et doivent impérativement être ajustés aux dépendances réelles et à la politique de sécurité du domaine cible.
- Ne détecte pas les vulnérabilités de code applicatif (injections SQL, SSRF, XSS applicatif).

---

## 🛠️ Utilisation CLI

```bash
# Générer un gabarit Nginx de base
sec-headers-sentinel generate --server nginx

# Auditer un dictionnaire JSON d'en-têtes HTTP
sec-headers-sentinel audit-json '{"Strict-Transport-Security": "max-age=31536000", "X-Content-Type-Options": "nosniff"}'
```

---

## 💰 Statut Commercial & Tarifs
- **Statut** : Prototype interne et démonstrateur technique. **Aucune transaction commerciale, zéro vente réalisée**.
- **Tarifs indicatifs affichés sur la démo** : 19 € (Solo) / 49 € (Pro) — *Figures purement indicatives.*
