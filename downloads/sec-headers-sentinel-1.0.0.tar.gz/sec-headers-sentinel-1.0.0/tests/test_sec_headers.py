# -*- coding: utf-8 -*-
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest
from sec_headers_sentinel.scanner import HeaderSecurityScanner
from sec_headers_sentinel.generator import SnippetGenerator
from sec_headers_sentinel.reporter import generate_security_report

def test_full_headers_pass():
    headers = {
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
        "Content-Security-Policy": "default-src 'self'",
        "X-Frame-Options": "DENY",
        "X-Content-Type-Options": "nosniff",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "camera=(), microphone=()"
    }
    scanner = HeaderSecurityScanner()
    res = scanner.audit_headers(headers)
    assert res["score"] == 100
    assert res["grade"] == "A+"
    assert res["is_secure"] is True

def test_missing_headers_low_score():
    headers = {"Content-Type": "text/html"}
    scanner = HeaderSecurityScanner()
    res = scanner.audit_headers(headers)
    assert res["score"] == 0
    assert res["grade"] == "F"
    assert res["is_secure"] is False

def test_csp_frame_ancestors_replaces_xfo():
    headers = {
        "Content-Security-Policy": "default-src 'self'; frame-ancestors 'none'",
        "Strict-Transport-Security": "max-age=31536000",
        "X-Content-Type-Options": "nosniff"
    }
    scanner = HeaderSecurityScanner()
    res = scanner.audit_headers(headers)
    assert res["score"] >= 65

def test_snippet_generator():
    gen = SnippetGenerator()
    nginx = gen.generate_nginx()
    assert "Strict-Transport-Security" in nginx
    caddy = gen.generate_caddy()
    assert "Content-Security-Policy" in caddy

def test_report_generation():
    headers = {"X-Content-Type-Options": "nosniff"}
    scanner = HeaderSecurityScanner()
    res = scanner.audit_headers(headers)
    report = generate_security_report(res, "test.local")
    assert "test.local" in report
    assert "OWASP" in report
