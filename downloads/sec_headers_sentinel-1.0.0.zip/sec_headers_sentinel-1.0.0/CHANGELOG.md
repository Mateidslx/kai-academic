# Changelog

All notable changes to `sec-headers-sentinel` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-10-15

### Added
- Complete HTTP defensive header scanning (HSTS, CSP, X-Content-Type-Options, Referrer-Policy, Permissions-Policy).
- Template generation engine for Nginx, Caddy, FastAPI middleware, and Apache.
- Synthetic security lab architecture assessor evaluating multi-role access policies.
- Fail-closed scope boundary validator preventing unauthorized network scans.
- Standalone CLI entrypoint `sec-headers-sentinel`.
- PEP 517 / PEP 621 wheel distribution build support.
