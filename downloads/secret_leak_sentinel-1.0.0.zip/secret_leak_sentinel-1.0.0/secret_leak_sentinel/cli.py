# -*- coding: utf-8 -*-
"""secret_leak_sentinel/cli.py
Interface CLI pour Secret Leak Sentinel.
Supporte le scan de dépôt, le mode hook pre-commit, et l'affichage des instructions de remédiation.
"""

from __future__ import annotations
import argparse
import sys
import json
from pathlib import Path

from . import __version__
from .detector import SecretLeakDetector
from .git_hook import run_staged_scan, HookInstaller
from .remediation import RemediationGuide
from .reporter import generate_html_report, generate_sarif_report

# Reconfigure stdout/stderr for Windows terminal UTF-8 and emoji safety
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def main():
    parser = argparse.ArgumentParser(
        prog="secret-leak-sentinel",
        description="Détecteur de fuites de secrets combinant analyse d'entropie de Shannon et regex contextuelles."
    )
    parser.add_argument("--version", action="version", version=f"secret-leak-sentinel {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    # Subcommand: scan
    scan_parser = subparsers.add_parser("scan", help="Analyser un fichier ou un répertoire récursivement")
    scan_parser.add_argument("path", default=".", nargs="?", help="Chemin du fichier ou dossier à analyser")
    scan_parser.add_argument("--json", action="store_true", help="Sortie structurée au format JSON")
    scan_parser.add_argument("--html", help="Chemin du fichier HTML de sortie pour le rapport exécutif")
    scan_parser.add_argument("--sarif", help="Chemin du fichier SARIF de sortie pour l'intégration CI/CD")

    # Subcommand: pre-commit
    subparsers.add_parser("pre-commit", help="Vérifier les modifications indexées dans Git (staged changes)")

    # Subcommand: install-hook
    hook_parser = subparsers.add_parser("install-hook", help="Installer le hook pre-commit dans le dépôt Git")
    hook_parser.add_argument("repo", default=".", nargs="?", help="Racine du dépôt Git")

    # Subcommand: remediate
    rem_parser = subparsers.add_parser("remediate", help="Afficher les instructions de révocation, rotation et purge d'historique")
    rem_parser.add_argument("--type", default="ALL", help="Type de secret (ex: GITHUB_TOKEN, AWS_ACCESS_KEY_ID)")

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)

    args = parser.parse_args()

    if args.command == "install-hook":
        target = Path(args.repo).resolve()
        try:
            HookInstaller.install(target)
            print(f"[OK] Hook pre-commit installé dans {target}/.git/hooks/pre-commit")
            sys.exit(0)
        except (FileExistsError, FileNotFoundError, RuntimeError) as exc:
            print(f"[ERREUR] Installation du hook impossible : {exc}", file=sys.stderr)
            sys.exit(1)
        except Exception as exc:
            print(f"[ERREUR] Échec inattendu : {exc}", file=sys.stderr)
            sys.exit(1)

    elif args.command == "pre-commit":
        try:
            findings = run_staged_scan()
        except ValueError as exc:
            # Fichier binaire ou incomplet dans les modifications indexées
            print(f"[ERREUR] Analyse incomplète de l'index Git (fichier non traitable) : {exc}", file=sys.stderr)
            sys.exit(2)
        except Exception as exc:
            # Dépôt manquant, Git absent, ou anomalie
            print(f"[ERREUR] Exécution pre-commit impossible : {exc}", file=sys.stderr)
            sys.exit(2)

        if not findings:
            print("[OK] Aucun secret détecté dans les modifications indexées.")
            sys.exit(0)

        print(f"\033[91m[ALERTE] {len(findings)} secret(s) détecté(s) dans l'index Git !\033[0m", file=sys.stderr)
        for f in findings:
            print(f"  - {f.file_path}:{f.line_number} [{f.secret_type}] (Entropie: {f.entropy:.2f}) -> {f.masked_value}", file=sys.stderr)
        print("\nExécutez 'secret-leak-sentinel remediate' pour les étapes de révocation et de purge.", file=sys.stderr)
        sys.exit(1)

    elif args.command == "scan":
        target = Path(args.path)
        detector = SecretLeakDetector()

        if not target.exists():
            if args.json:
                print(json.dumps({"error": f"Fichier ou dossier introuvable : {target}", "errors": [f"Fichier ou dossier introuvable : {target}"], "findings_count": 0, "findings": []}, indent=2))
            else:
                print(f"[ERREUR] Chemin introuvable : '{target}'", file=sys.stderr)
            sys.exit(2)

        if target.is_symlink():
            if args.json:
                print(json.dumps({"error": f"Lien symbolique refusé : {target}", "errors": [f"Lien symbolique refusé : {target}"], "findings_count": 0, "findings": []}, indent=2))
            else:
                print(f"[ERREUR] Liens symboliques non supportés : '{target}'", file=sys.stderr)
            sys.exit(2)

        if target.is_file():
            try:
                findings = detector.scan_file(target)
                errors = []
            except Exception as exc:
                if args.json:
                    print(json.dumps({"error": str(exc), "errors": [str(exc)], "findings_count": 0, "findings": []}, indent=2))
                else:
                    print(f"[ERREUR] Impossible d'analyser le fichier : {exc}", file=sys.stderr)
                sys.exit(2)
        else:
            findings, errors = detector.scan_directory(target)
            if errors:
                if args.json:
                    out = {
                        "scanned_target": str(target),
                        "errors": errors,
                        "findings_count": len(findings),
                        "findings": [f.to_dict() for f in findings]
                    }
                    print(json.dumps(out, indent=2))
                else:
                    print(f"[ERREUR] Analyse incomplète : {len(errors)} erreur(s) détectée(s)", file=sys.stderr)
                    for err in errors:
                        print(f"  - {err}", file=sys.stderr)
                sys.exit(2)

        if args.html:
            try:
                html_code = generate_html_report(findings, target_name=str(target))
                out_html = Path(args.html)
                out_html.parent.mkdir(parents=True, exist_ok=True)
                out_html.write_text(html_code, encoding="utf-8")
                if not args.json:
                    print(f"[OK] Rapport exécutif HTML généré : {args.html}")
            except Exception as exc:
                print(f"[ERREUR] Échec de génération du rapport HTML : {exc}", file=sys.stderr)

        if args.sarif:
            try:
                sarif_code = generate_sarif_report(findings, target_name=str(target))
                out_sarif = Path(args.sarif)
                out_sarif.parent.mkdir(parents=True, exist_ok=True)
                out_sarif.write_text(sarif_code, encoding="utf-8")
                if not args.json:
                    print(f"[OK] Rapport SARIF généré : {args.sarif}")
            except Exception as exc:
                print(f"[ERREUR] Échec de génération du rapport SARIF : {exc}", file=sys.stderr)

        if args.json:
            out = {
                "scanned_target": str(target),
                "findings_count": len(findings),
                "findings": [f.to_dict() for f in findings]
            }
            print(json.dumps(out, indent=2))
            sys.exit(0 if not findings else 1)

        print("=" * 60)
        print("  SECRET LEAK SENTINEL : RAPPORT D'ANALYSE")
        print(f"  Cible             : {target}")
        print(f"  Secrets trouvés   : {len(findings)}")
        print("=" * 60)

        for f in findings:
            print(f"  [{f.severity}] {f.file_path}:{f.line_number}")
            print(f"    Type     : {f.secret_type}")
            print(f"    Entropie : {f.entropy:.2f} bits/char")
            print(f"    Valeur   : {f.masked_value}")
            print(f"    Contexte : {f.context_snippet}")
            print()

        if findings:
            print("[CONSEIL] Pour révoquer et purger ces secrets de l'historique Git, exécutez :")
            print("  secret-leak-sentinel remediate")

        sys.exit(0 if not findings else 1)

    elif args.command == "remediate":
        sec_type = args.type.upper()
        info = RemediationGuide.get_instructions_for_finding(sec_type)
        print("=" * 60)
        print(f"  GUIDE DE RÉMÉDIATION : {sec_type}")
        print("=" * 60)
        print(info["overview"])
        print("\nÉtapes obligatoires :")
        for step in info["steps"]:
            print(f"  {step}")
        print("\nGuide spécifique du fournisseur :")
        for k, v in info["specific_provider_guidance"].items():
            print(f"  - {k}: {v}")
        print("\nRecette de purge d'historique Git :")
        print(info["git_history_purge_recipe"])
        sys.exit(0)


if __name__ == "__main__":
    main()
