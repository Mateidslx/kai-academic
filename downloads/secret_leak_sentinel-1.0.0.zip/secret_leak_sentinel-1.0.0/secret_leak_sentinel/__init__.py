# -*- coding: utf-8 -*-
"""secret_leak_sentinel package.
Détecteur de fuites de secrets combinant analyse d'entropie de Shannon et motifs contextuels.
"""

from .entropy import calculate_shannon_entropy, is_high_entropy
from .detector import SecretLeakDetector, SecretFinding
from .filters import is_placeholder_or_sample, is_git_commit_hash, is_file_ignored
from .remediation import RemediationGuide

__version__ = "1.0.0"
__all__ = [
    "calculate_shannon_entropy",
    "is_high_entropy",
    "SecretLeakDetector",
    "SecretFinding",
    "is_placeholder_or_sample",
    "is_git_commit_hash",
    "is_file_ignored",
    "RemediationGuide",
]
