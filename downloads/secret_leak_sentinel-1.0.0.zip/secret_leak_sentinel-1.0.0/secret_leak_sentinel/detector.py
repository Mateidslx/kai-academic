# -*- coding: utf-8 -*-
"""secret_leak_sentinel/detector.py
Moteur de détection de secrets et clés sensibles combinant regex contextuelles et entropie de Shannon.
Masquage strict fail-closed : aucune clé brute non-masquée n'est jamais affichée dans les findings ou snippets.
"""

from __future__ import annotations
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path

from .entropy import calculate_shannon_entropy, is_high_entropy
from .filters import (
    is_placeholder_or_sample,
    is_git_commit_hash,
    is_file_ignored,
    has_allowlist_directive
)


@dataclass
class SecretFinding:
    file_path: str
    line_number: int
    secret_type: str
    severity: str  # CRITICAL, HIGH, MEDIUM
    entropy: float
    masked_value: str
    context_snippet: str
    remediation_key: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# Alias de compatibilité
Finding = SecretFinding


class SecretLeakDetector:
    """Détecte les fuites de secrets par corrélation contextuelle et analyse d'entropie."""

    # Regex contextuelles précises
    PATTERNS: Dict[str, re.Pattern] = {
        "GITHUB_TOKEN": re.compile(r"\b(gh[pousr]_[A-Za-z0-9_]{36,255})\b"),
        "OPENAI_API_KEY": re.compile(r"\b(sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,128})\b"),
        "ANTHROPIC_API_KEY": re.compile(r"\b(sk-ant-[A-Za-z0-9_-]{32,128})\b"),
        "AWS_ACCESS_KEY_ID": re.compile(r"\b((?:AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16})\b"),
        "STRIPE_SECRET_KEY": re.compile(r"\b(sk_live_[0-9a-zA-Z]{24,32})\b"),
        "SLACK_BOT_TOKEN": re.compile(r"\b(xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24})\b"),
        "PRIVATE_KEY_HEADER": re.compile(r"(-----BEGIN (?:(?:RSA|EC|OPENSSH|DSA|PGP)\s+)?(?:PRIVATE\s+)?KEY-----|-----BEGIN (?:[A-Z0-9_-]+\s+)*KEY-----)"),
        "DATABASE_URI_WITH_CREDS": re.compile(r"\b(?:postgres|postgresql|mysql|mongodb|redis):\/\/([a-zA-Z0-9_-]+:[^@\s]{4,}@[a-zA-Z0-9_.-]+:[0-9]+/[a-zA-Z0-9_.-]+)\b"),
        "JWT_BEARER_TOKEN": re.compile(r"\b(ey[A-Za-z0-9_-]{15,}\.ey[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,})\b"),
    }

    # Détection générique basée sur assignation + entropie élevée
    ASSIGNMENT_CANDIDATE = re.compile(
        r"""(?:\b[a-zA-Z0-9_]*(?:key|secret|token|password|passwd|auth|credential)[a-zA-Z0-9_]*)\s*[:=]\s*['"]([^'"\s]{16,128})['"]""",
        re.IGNORECASE
    )

    def __init__(self):
        self.last_errors: List[str] = []

    def mask_secret(self, raw_secret: str, entropy: float) -> str:
        """Masque rigoureusement le secret pour empêcher toute exfiltration dans les logs."""
        length = len(raw_secret)
        if length <= 6:
            return "***[REDACTED]***"
        prefix = raw_secret[:3]
        suffix = raw_secret[-3:]
        return f"{prefix}***[REDACTED: len={length}, entropy={entropy:.2f}]***{suffix}"

    def scan_content(self, text: str, source_path: str = "buffer") -> List[SecretFinding]:
        findings: List[SecretFinding] = []

        lines = text.splitlines()
        for idx, line in enumerate(lines, start=1):
            # 1. Vérifier si la ligne contient une directive explicite d'exclusion
            if has_allowlist_directive(line):
                continue

            line_candidates: List[Tuple[str, str, float, str, str]] = []  # raw_val, key_type, ent, masked, severity
            matched_line_keys: set[str] = set()

            # 2. Motifs contextuels stricts
            for key_type, pattern in self.PATTERNS.items():
                for match in pattern.finditer(line):
                    raw_val = match.group(1) if match.groups() else match.group(0)

                    # Filtrage faux positifs
                    if is_placeholder_or_sample(raw_val):
                        continue
                    if is_git_commit_hash(raw_val):
                        continue

                    ent = calculate_shannon_entropy(raw_val)
                    masked = self.mask_secret(raw_val, ent)
                    severity = "CRITICAL" if key_type in ("PRIVATE_KEY_HEADER", "AWS_ACCESS_KEY_ID", "GITHUB_TOKEN", "STRIPE_SECRET_KEY") else "HIGH"

                    line_candidates.append((raw_val, key_type, ent, masked, severity))
                    matched_line_keys.add(raw_val)

            # 3. Détection générique basée sur variable d'assignation + entropie
            for assign_match in self.ASSIGNMENT_CANDIDATE.finditer(line):
                raw_candidate = assign_match.group(1)
                if raw_candidate in matched_line_keys:
                    continue
                if is_placeholder_or_sample(raw_candidate):
                    continue
                if is_git_commit_hash(raw_candidate):
                    continue

                ent = calculate_shannon_entropy(raw_candidate)
                if is_high_entropy(raw_candidate, threshold=3.5, min_length=16):
                    masked = self.mask_secret(raw_candidate, ent)
                    line_candidates.append((raw_candidate, "GENERIC_HIGH_ENTROPY_KEY", ent, masked, "HIGH"))
                    matched_line_keys.add(raw_candidate)

            if not line_candidates:
                continue

            # 4. Construire un snippet désinfecté où TOUS les secrets de la ligne sont masqués
            # (Empêche toute fuite croisée de secret adjacent sur la même ligne)
            sanitized_line = line.strip()
            # Remplacer d'abord les plus longues chaînes pour éviter les remplacements partiels
            for raw_val, _, _, masked, _ in sorted(line_candidates, key=lambda c: len(c[0]), reverse=True):
                sanitized_line = sanitized_line.replace(raw_val, masked)

            if len(sanitized_line) > 120:
                sanitized_line = sanitized_line[:117] + "..."

            # 5. Créer les findings avec le snippet entièrement assaini
            for raw_val, key_type, ent, masked, severity in line_candidates:
                finding = SecretFinding(
                    file_path=source_path,
                    line_number=idx,
                    secret_type=key_type,
                    severity=severity,
                    entropy=ent,
                    masked_value=masked,
                    context_snippet=sanitized_line,
                    remediation_key=key_type if key_type != "GENERIC_HIGH_ENTROPY_KEY" else "GENERIC_KEY"
                )
                findings.append(finding)

        return findings

    def scan_file(self, filepath: Path, check_ignored: bool = False) -> List[SecretFinding]:
        """Analyse un fichier unique avec vérification stricte fail-closed du système de fichiers."""
        p = Path(filepath)
        if not p.exists():
            raise FileNotFoundError(f"Chemin de fichier inexistant : {p}")
        if p.is_symlink():
            raise ValueError(f"Liens symboliques non supportés pour des raisons de sécurité : {p}")
        if not p.is_file():
            raise ValueError(f"Le chemin spécifié n'est pas un fichier régulier : {p}")

        # Limite stricte de taille : 2 MiB
        stat = p.stat()
        if stat.st_size > 2 * 1024 * 1024:
            raise ValueError(f"Fichier trop volumineux (> 2 MiB) : {p} ({stat.st_size} octets)")

        # Ignorer les fichiers si demandé (ex: scan récursif de dossier)
        if check_ignored and is_file_ignored(str(p)):
            return []

        raw_bytes = p.read_bytes()
        # Détection de fichier binaire : présence d'octets NUL
        if b"\x00" in raw_bytes:
            raise ValueError(f"Fichier binaire non supporté : {p}")

        try:
            content = raw_bytes.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(f"Encodage UTF-8 invalide dans {p}: {exc}")

        return self.scan_content(content, source_path=str(p))

    def scan_directory(self, root_dir: Path) -> Tuple[List[SecretFinding], List[str]]:
        """Analyse récursivement un répertoire en consignant les erreurs d'incomplétude."""
        self.last_errors = []
        all_findings: List[SecretFinding] = []
        p = Path(root_dir)
        if not p.exists():
            raise FileNotFoundError(f"Dossier inexistant : {p}")

        for item in p.rglob("*"):
            if item.is_symlink():
                self.last_errors.append(f"Lien symbolique ignoré/non-supporté : {item}")
                continue
            if item.is_file() and not is_file_ignored(str(item)):
                try:
                    findings = self.scan_file(item)
                    all_findings.extend(findings)
                except Exception as exc:
                    self.last_errors.append(f"{item.name}: {exc}")

        return all_findings, self.last_errors
