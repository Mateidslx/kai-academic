# -*- coding: utf-8 -*-
"""secret_leak_sentinel/git_hook.py
Gestionnaire de hook git pre-commit et vérification des fichiers indexés (staged changes).
Scan strict au niveau de l'index Git avec support des chemins exotiques (espaces, retours ligne, accents).
"""

from __future__ import annotations
import os
import sys
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple

from .detector import SecretLeakDetector, SecretFinding


def extract_added_lines_from_diff(diff_text: str) -> List[Tuple[str, int, str]]:
    """Extrait les lignes ajoutées (+) d'un diff avec leur nom de fichier et numéro de ligne approximatif."""
    current_file = "unknown"
    current_line = 0
    added_lines: List[Tuple[str, int, str]] = []

    for line in diff_text.splitlines():
        if line.startswith("+++ b/"):
            current_file = line[6:]
        elif line.startswith("@@"):
            # Ex: @@ -1,4 +1,6 @@
            parts = line.split("+")
            if len(parts) > 1:
                try:
                    current_line = int(parts[1].split(",")[0].split(" ")[0])
                except Exception:
                    current_line = 1
        elif line.startswith("+") and not line.startswith("+++"):
            added_lines.append((current_file, current_line, line[1:]))
            current_line += 1
        elif not line.startswith("-"):
            current_line += 1

    return added_lines


class HookInstaller:
    """Installe et gère le hook pre-commit de façon idempotente et sans écraser les hooks tiers."""

    HOOK_SIGNATURE = "# Installed by secret-leak-sentinel"

    @classmethod
    def generate_hook_script(cls) -> str:
        launcher = str(Path(sys.argv[0]).resolve()).replace("\\", "/")
        python_bin = sys.executable.replace("\\", "/")
        return f"""#!/bin/sh
{cls.HOOK_SIGNATURE}
# Hook pre-commit fail-closed pour Secret Leak Sentinel
if [ -f "{launcher}" ] && echo "{launcher}" | grep -q "\\.pyz$"; then
    exec "{python_bin}" "{launcher}" pre-commit "$@"
elif command -v secret-leak-sentinel >/dev/null 2>&1; then
    exec secret-leak-sentinel pre-commit "$@"
else
    exec "{python_bin}" -m secret_leak_sentinel.cli pre-commit "$@"
fi
"""

    @classmethod
    def install(cls, repo_path: Path) -> bool:
        repo = Path(repo_path).resolve()
        hooks_dir = repo / ".git" / "hooks"
        if not hooks_dir.is_dir():
            raise FileNotFoundError(f"Dossier .git/hooks introuvable dans {repo}")

        hook_file = hooks_dir / "pre-commit"
        if hook_file.exists():
            try:
                existing_content = hook_file.read_text(encoding="utf-8", errors="replace")
            except Exception:
                existing_content = ""

            # Si le hook existant n'a pas notre signature, collision formelle refusée !
            if cls.HOOK_SIGNATURE not in existing_content:
                raise FileExistsError(
                    f"Conflit de hook détecté : {hook_file} existe déjà et n'a pas été créé par secret-leak-sentinel. "
                    "Écrasement refusé pour préserver le hook utilisateur."
                )

        script = cls.generate_hook_script()
        hook_file.write_text(script, encoding="utf-8")
        if os.name != "nt":
            hook_file.chmod(0o755)
        return True


def run_staged_scan(repo_path: Optional[Path] = None) -> List[SecretFinding]:
    """Exécute un scan sur les modifications git indexées (staged blob).
    Lève une exception si Git n'est pas disponible, si le dossier n'est pas un dépôt Git,
    ou si un fichier binaire est présent dans l'index.
    """
    git_bin = shutil.which("git") or "git"
    cwd = str(repo_path) if repo_path else os.getcwd()

    # 1. Vérification présence de Git et validité du dépôt
    check_repo = subprocess.run(
        [git_bin, "rev-parse", "--is-inside-work-tree"],
        cwd=cwd,
        capture_output=True,
        text=True
    )
    if check_repo.returncode != 0:
        raise RuntimeError(f"Le chemin '{cwd}' n'est pas un dépôt Git valide ou Git est inaccessible.")

    # 2. Récupérer la liste des fichiers modifiés dans l'index Git (NUL-separated pour noms avec espaces/newlines)
    staged_list_proc = subprocess.run(
        [git_bin, "-c", "core.quotePath=false", "diff", "--cached", "--name-only", "--diff-filter=d", "-z"],
        cwd=cwd,
        capture_output=True
    )
    if staged_list_proc.returncode != 0:
        raise RuntimeError("Impossible de lire l'index Git.")

    raw_names = staged_list_proc.stdout.split(b"\x00")
    staged_files: List[str] = [n.decode("utf-8", errors="replace") for n in raw_names if n]

    detector = SecretLeakDetector()
    all_findings: List[SecretFinding] = []

    # 3. Analyser chaque blob staged directement depuis l'index Git
    for rel_path in staged_files:
        show_proc = subprocess.run(
            [git_bin, "show", f":{rel_path}"],
            cwd=cwd,
            capture_output=True
        )
        if show_proc.returncode != 0:
            continue

        raw_data = show_proc.stdout
        # Détection binaire : fail-closed avec erreur explicite
        if b"\x00" in raw_data:
            raise ValueError(f"Fichier binaire indexé dans Git non analysable : {rel_path}")

        try:
            content = raw_data.decode("utf-8")
        except UnicodeDecodeError:
            raise ValueError(f"Fichier indexé avec encodage non-UTF8 dans Git : {rel_path}")

        findings = detector.scan_content(content, source_path=rel_path)
        all_findings.extend(findings)

    return all_findings
