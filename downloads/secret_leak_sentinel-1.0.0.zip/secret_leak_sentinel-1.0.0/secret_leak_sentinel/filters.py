# -*- coding: utf-8 -*-
"""secret_leak_sentinel/filters.py
Règles d'exclusion strictes et filtrage des faux positifs :
- Données d'exemple et placeholders de documentation
- Empreintes cryptographiques connues (hashes hexadécimaux de commit git)
- Fichiers de gabarit (.env.example, sample.json) et caches
- Lignes avec directives d'exclusion explicites sous forme de commentaire (# pragma: allowlist secret, # nosec)
"""

from __future__ import annotations
import re
from typing import Set

# Mots-clés indiquant formellement un faux positif ou une valeur de documentation
PLACEHOLDER_SUBSTRINGS = {
    "placeholder",
    "dummy",
    "redacted",
    "changeme",
    "your_token_here",
    "your_api_key_here",
    "your_secret_key",
    "insert_here",
    "mock_token",
    "test_key",
    "fake_token",
}

# Fichiers et extensions ignorés par défaut lors de scans récursifs de répertoires
IGNORED_FILE_PATTERNS = [
    r"\.env\.example$",
    r"\.env\.sample$",
    r"\.env\.template$",
    r"package-lock\.json$",
    r"yarn\.lock$",
    r"pnpm-lock\.yaml$",
    r"(?:^|/)\.git(?:/|$)",
    r"(?:^|/)__pycache__(?:/|$)",
    r"(?:^|/)\.pytest_cache(?:/|$)",
]

# Patterns de faux positifs évidents
GIT_COMMIT_HASH_PATTERN = re.compile(r"^[0-9a-f]{40}$", re.IGNORECASE)
HEX_COLOR_PATTERN = re.compile(r"^#?[0-9a-f]{6}$|^#?[0-9a-f]{8}$", re.IGNORECASE)

# Directive d'exclusion explicite : doit impérativement être un commentaire (commençant par #)
ALLOWLIST_DIRECTIVE_PATTERN = re.compile(
    r"#\s*(?:pragma:\s*allowlist\s*secret|\bnosec\b|\bskip-secret-scan\b)",
    re.IGNORECASE
)


def is_placeholder_or_sample(value: str) -> bool:
    """Détecte si la valeur correspond à un exemple de documentation ou un placeholder évident."""
    val_lower = value.lower()
    for token in PLACEHOLDER_SUBSTRINGS:
        if token in val_lower:
            return True
    if val_lower.endswith("example") or val_lower.startswith("example") or val_lower == "sample":
        return True
    return False


def is_git_commit_hash(value: str) -> bool:
    """Détecte un hash de commit Git 40-hex isolé."""
    return bool(GIT_COMMIT_HASH_PATTERN.match(value.strip()))


def is_file_ignored(filepath: str) -> bool:
    """Vérifie si le chemin correspond à un gabarit ou cache ignoré lors d'un scan récursif."""
    clean_path = filepath.replace("\\", "/")
    for pattern in IGNORED_FILE_PATTERNS:
        if re.search(pattern, clean_path, re.IGNORECASE):
            return True
    return False


def has_allowlist_directive(line: str) -> bool:
    """Vérifie si la ligne contient une directive de dispense explicite sous forme de commentaire.
    Ne prend PAS en compte les occurrences du mot à l'intérieur de chaînes de caractères (ex: label='nosec' ou nanosecond).
    """
    return bool(ALLOWLIST_DIRECTIVE_PATTERN.search(line))
