# -*- coding: utf-8 -*-
"""secret_leak_sentinel/reporter.py
Générateur de rapports professionnels pour Secret Leak Sentinel :
- Rapport HTML exécutif autonome et interactif avec onglets de remédiation
- Export standardisé OASIS SARIF v2.1.0 pour GitHub Security / GitLab CI
"""

from __future__ import annotations
import html
import json
import time
from typing import List, Dict, Any
from pathlib import Path

from .detector import Finding
from .remediation import RemediationGuide


def generate_html_report(findings: List[Finding], target_name: str = "Projet") -> str:
    """Génère un rapport exécutif HTML autonome, responsive et élégant."""
    findings_count = len(findings)
    is_clean = findings_count == 0
    grade_color = "#10b981" if is_clean else "#ef4444"
    status_text = "AUCUN SECRET EXPOSÉ" if is_clean else f"{findings_count} FUITE(S) DE SECRETS DÉTECTÉE(S)"
    sub_title = "Tous les fichiers audités sont exempts de jetons à haute entropie ou clés API privées." if is_clean else "Attention : des jetons ou clés d'accès réels sont exposés dans le code source."

    rows_html = []
    for idx, f in enumerate(findings, 1):
        sev_color = "#dc2626" if f.severity == "CRITICAL" else "#ea580c"
        guide = RemediationGuide.get_instructions_for_finding(f.secret_type)
        provider_tip = guide["steps"][0] if guide["steps"] else ""
        
        rows_html.append(f"""
        <tr>
            <td style="font-weight: 700; color: #f8fafc;">#{idx}</td>
            <td><span style="background: {sev_color}; color: #fff; padding: 3px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 700;">{html.escape(f.severity)}</span></td>
            <td><strong>{html.escape(f.secret_type)}</strong></td>
            <td><code>{html.escape(f.file_path)}:{f.line_number}</code></td>
            <td><code>{html.escape(f.masked_value)}</code></td>
            <td style="color: #94a3b8; font-family: monospace;">{f.entropy:.2f} bits/c</td>
            <td style="font-size: 0.85rem; color: #cbd5e1;">{html.escape(provider_tip)}</td>
        </tr>
        """)

    table_rows = "".join(rows_html)

    # Onglets de remédiation
    git_purge_recipe = html.escape(RemediationGuide.GENERAL_PROTOCOL["FOUR_STEP_REMEDIATION"][2] + "\n\nExemple de commande git-filter-repo :\npip install git-filter-repo\ngit filter-repo --replace-text <(echo 'ANCIENNE_CLÉ===>REMOVED') --force\ngit push origin --force --all")
    precommit_install_cmd = "secret-leak-sentinel install-hook ."

    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit de Secrets & Clés API — {html.escape(target_name)}</title>
    <style>
        :root {{
            --bg: #0f172a;
            --surface: #1e293b;
            --border: #334155;
            --text: #f8fafc;
            --text-muted: #94a3b8;
            --primary: #38bdf8;
            --danger: #ef4444;
            --success: #10b981;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            background: var(--bg);
            color: var(--text);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            padding: 40px 20px;
        }}
        .container {{ max-width: 1040px; margin: 0 auto; }}
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }}
        .header h1 {{ font-size: 1.8rem; font-weight: 800; color: #fff; }}
        .badge-brand {{
            background: #0284c7;
            color: #fff;
            font-size: 0.75rem;
            padding: 3px 8px;
            border-radius: 6px;
            text-transform: uppercase;
            font-weight: 700;
        }}
        .card {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
        }}
        .status-box {{
            display: flex;
            align-items: center;
            gap: 20px;
        }}
        .status-indicator {{
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: {grade_color};
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            flex-shrink: 0;
        }}
        table {{ width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }}
        th {{ background: #090d16; padding: 12px 14px; color: var(--text-muted); font-size: 0.75rem; text-transform: uppercase; }}
        td {{ padding: 14px; border-top: 1px solid var(--border); vertical-align: top; }}
        code {{ background: #090d16; color: #38bdf8; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 0.85rem; }}
        
        /* Tabs */
        .tabs-header {{
            display: flex;
            background: #090d16;
            border-bottom: 1px solid var(--border);
            padding: 8px 16px 0 16px;
            gap: 6px;
            border-radius: 16px 16px 0 0;
        }}
        .tab-btn {{
            background: transparent;
            border: 1px solid transparent;
            border-bottom: none;
            color: var(--text-muted);
            padding: 10px 16px;
            border-radius: 8px 8px 0 0;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.85rem;
        }}
        .tab-btn.active {{
            background: var(--surface);
            color: #38bdf8;
            border-color: var(--border);
            border-bottom: 1px solid var(--surface);
            margin-bottom: -1px;
        }}
        .tab-pane {{ display: none; padding: 24px; }}
        .tab-pane.active {{ display: block; }}
        
        .code-box {{
            background: #090d16;
            color: #f1f5f9;
            padding: 16px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 0.85rem;
            overflow-x: auto;
            white-space: pre-wrap;
            margin-top: 10px;
        }}
        .btn-copy {{
            background: #0284c7;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            float: right;
        }}
        .footer {{ text-align: center; color: var(--text-muted); font-size: 0.85rem; margin-top: 40px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <span class="badge-brand">Secret Leak Sentinel v1.0</span>
                <h1>Audit de Sécurité des Secrets & Clés Privées</h1>
                <p style="color: var(--text-muted); font-size: 0.95rem; margin-top: 4px;">Cible : <strong>{html.escape(target_name)}</strong> • {time.strftime('%d/%m/%Y à %H:%M UTC')}</p>
            </div>
            <div>
                <span style="font-size: 0.85rem; color: var(--text-muted);">Entropie de Shannon & Regex Contextuelles</span>
            </div>
        </div>

        <div class="card">
            <div class="status-box">
                <div class="status-indicator">
                    {"🛡️" if is_clean else "⚠️"}
                </div>
                <div>
                    <h2 style="font-size: 1.4rem; color: {grade_color}; font-weight: 800;">{status_text}</h2>
                    <p style="color: var(--text-muted); font-size: 0.95rem; margin-top: 4px;">{sub_title}</p>
                </div>
            </div>
        </div>

        {f'''
        <div class="card" style="padding: 0; overflow: hidden;">
            <div style="padding: 20px 24px; border-bottom: 1px solid var(--border);">
                <h3 style="font-size: 1.2rem; font-weight: 700;">Détail des Secrets Identifiés ({findings_count})</h3>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">Les valeurs réelles sont automatiquement masquées pour prévenir toute fuite secondaire.</p>
            </div>
            <table>
                <thead>
                    <tr>
                        <th style="width: 5%;">#</th>
                        <th style="width: 10%;">Sévérité</th>
                        <th style="width: 18%;">Type de Secret</th>
                        <th style="width: 20%;">Emplacement</th>
                        <th style="width: 20%;">Valeur Masquée</th>
                        <th style="width: 12%;">Entropie</th>
                        <th style="width: 15%;">Mesure Immédiate</th>
                    </tr>
                </thead>
                <tbody>
                    {table_rows}
                </tbody>
            </table>
        </div>
        ''' if not is_clean else ''}

        <!-- Guide de Remédiation Interactif -->
        <div class="card" style="padding: 0; overflow: hidden;">
            <div class="tabs-header">
                <button class="tab-btn active" onclick="switchTab('tab-purge', this)">1. Purge de l'Historique Git</button>
                <button class="tab-btn" onclick="switchTab('tab-hook', this)">2. Hook Pre-commit Automatique</button>
                <button class="tab-btn" onclick="switchTab('tab-cicd', this)">3. Intégration CI/CD</button>
            </div>

            <div id="tab-purge" class="tab-pane active">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h4 style="font-size: 1.05rem; font-weight: 700;">Purge Totale des Blobs de Secrets via git-filter-repo</h4>
                    <button class="btn-copy" onclick="copySnippet('code-purge', this)">📋 Copier la recette</button>
                </div>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 6px;">
                    Un secret committé reste présent dans l'historique de chaque clone. Utilisez cette procédure pour réécrire les branches :
                </p>
                <pre class="code-box"><code id="code-purge">{git_purge_recipe}</code></pre>
            </div>

            <div id="tab-hook" class="tab-pane">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h4 style="font-size: 1.05rem; font-weight: 700;">Protection Native Pre-Commit (Local)</h4>
                    <button class="btn-copy" onclick="copySnippet('code-hook', this)">📋 Copier la commande</button>
                </div>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 6px;">
                    Installez le hook dans votre dépôt local pour interdire définitivement l'ajout de clés dans git commit :
                </p>
                <pre class="code-box"><code id="code-hook">{precommit_install_cmd}</code></pre>
            </div>

            <div id="tab-cicd" class="tab-pane">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h4 style="font-size: 1.05rem; font-weight: 700;">Pipeline GitHub Actions / GitLab CI</h4>
                    <button class="btn-copy" onclick="copySnippet('code-cicd', this)">📋 Copier le job</button>
                </div>
                <pre class="code-box"><code id="code-cicd">- name: Scan for Secret Leaks
  run: |
    pip install secret-leak-sentinel
    secret-leak-sentinel scan . --sarif secret-leaks.sarif
- name: Upload SARIF report
  uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: secret-leaks.sarif</code></pre>
            </div>
        </div>

        <div class="footer">
            Rapport certifié généré par Secret Leak Sentinel • Développé par Mateidslx
        </div>
    </div>

    <script>
        function switchTab(tabId, btn) {{
            document.querySelectorAll('.tab-btn').forEach(function(b) {{ b.classList.remove('active'); }});
            document.querySelectorAll('.tab-pane').forEach(function(p) {{ p.classList.remove('active'); }});
            btn.classList.add('active');
            var pane = document.getElementById(tabId);
            if (pane) pane.classList.add('active');
        }}

        function copySnippet(elementId, btn) {{
            var el = document.getElementById(elementId);
            if (!el) return;
            var text = el.innerText || el.textContent;
            navigator.clipboard.writeText(text).then(function() {{
                var orig = btn.innerHTML;
                btn.innerHTML = '✓ Copié !';
                setTimeout(function() {{ btn.innerHTML = orig; }}, 2000);
            }}).catch(function(err) {{
                console.error(err);
            }});
        }}
    </script>
</body>
</html>"""


def generate_sarif_report(findings: List[Finding], target_name: str = "Projet") -> str:
    """Génère un rapport conforme à la spécification OASIS SARIF v2.1.0."""
    rules_map = {}
    results = []

    for f in findings:
        rule_id = f"SLS-{f.secret_type}"
        if rule_id not in rules_map:
            rules_map[rule_id] = {
                "id": rule_id,
                "name": f"ExposedSecret_{f.secret_type}",
                "shortDescription": {"text": f"Exposition d'identifiant sensible : {f.secret_type}"},
                "fullDescription": {"text": f"Un secret potentiel ({f.secret_type}) avec entropie {f.entropy:.2f} bits/c a été détecté."},
                "defaultConfiguration": {"level": "error" if f.severity == "CRITICAL" else "warning"}
            }

        results.append({
            "ruleId": rule_id,
            "message": {"text": f"Secret {f.secret_type} détecté : {f.masked_value}"},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {"uri": f.file_path.replace("\\", "/")},
                        "region": {"startLine": f.line_number}
                    }
                }
            ]
        })

    sarif_doc = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "secret-leak-sentinel",
                        "semanticVersion": "1.0.0",
                        "informationUri": "https://polar.sh/Mateidslx",
                        "rules": list(rules_map.values())
                    }
                },
                "results": results
            }
        ]
    }
    return json.dumps(sarif_doc, indent=2, ensure_ascii=False)
