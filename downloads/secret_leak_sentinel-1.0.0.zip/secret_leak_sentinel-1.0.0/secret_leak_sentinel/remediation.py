# -*- coding: utf-8 -*-
"""secret_leak_sentinel/remediation.py
Guide de remédiation technique pour les secrets exposés :
- Distinction formelle entre modification du fichier local et exposition dans l'historique Git.
- Protocoles de révocation immédiate, rotation sécurisée et réécriture d'historique.
- Étapes de vérification contradictoire prouvant l'invalidation réelle du secret.
"""

from typing import Dict, Any, List


class RemediationGuide:
    """Fournit des instructions de remédiation précises et vérifiables par type de secret."""

    GENERAL_PROTOCOL = {
        "DIFFERENCE_LOCAL_VS_GIT_HISTORY": (
            "ATTENTION : Modifier simplement le fichier local ou committer une suppression "
            "NE PROTÈGE PAS le secret ! Dès lors qu'un secret a été committé dans Git, "
            "il reste accessible en clair dans l'historique de chaque clone et dans chaque objet commit (git show <hash>). "
            "Toute clé committée doit être considérée comme COMPROMISE et RÉVOQUÉE à la source."
        ),
        "FOUR_STEP_REMEDIATION": [
            "1. RÉVOCATION IMMÉDIATE : Invalider la clé dès maintenant dans la console du fournisseur (AWS IAM, GitHub Token Settings, OpenAI Platform, Stripe Dashboard).",
            "2. ROTATION & NOUVELLE CLÉ : Générer une nouvelle clé et la configurer exclusivement via variable d'environnement ou coffre-fort de secrets (HashiCorp Vault, AWS Secrets Manager).",
            "3. PURGE D'HISTORIQUE GIT : Réécrire l'historique à l'aide de 'git-filter-repo' ou BFG Repo-Cleaner pour supprimer le blob dans toutes les branches et tags.",
            "4. VÉRIFICATION CONTRADICTOIRE : Prouver par une commande curl ou SDK que l'ancienne clé retourne 401 Unauthorized / Invalid Key, et que la nouvelle clé fonctionne."
        ]
    }

    SPECIFIC_REMEDIATION: Dict[str, Dict[str, Any]] = {
        "GITHUB_TOKEN": {
            "revocation_url": "https://github.com/settings/tokens",
            "revocation_action": "Cliquer sur 'Revoke' pour le jeton exposé.",
            "verification_command": "curl -s -H 'Authorization: token <ANCIEN_JETON>' https://api.github.com/user",
            "expected_verification_response": "HTTP 401 Bad credentials"
        },
        "OPENAI_API_KEY": {
            "revocation_url": "https://platform.openai.com/api-keys",
            "revocation_action": "Cliquer sur l'icône Corbeille / Delete Key pour invalider la clé.",
            "verification_command": "curl -s https://api.openai.com/v1/models -H 'Authorization: Bearer <ANCIENNE_CLÉ>'",
            "expected_verification_response": "HTTP 401 Invalid API Key"
        },
        "ANTHROPIC_API_KEY": {
            "revocation_url": "https://console.anthropic.com/settings/keys",
            "revocation_action": "Désactiver et supprimer la clé API dans la console Anthropic.",
            "verification_command": "curl -s https://api.anthropic.com/v1/messages -H 'x-api-key: <ANCIENNE_CLÉ>'",
            "expected_verification_response": "HTTP 401 authentication_error"
        },
        "AWS_ACCESS_KEY_ID": {
            "revocation_url": "AWS Management Console -> IAM -> Users -> Security Credentials",
            "revocation_action": "Passer le statut de la clé en 'Inactive', puis 'Delete'.",
            "verification_command": "aws sts get-caller-identity --profile <profil_utilise>",
            "expected_verification_response": "InvalidClientTokenId / The security token included in the request is invalid"
        },
        "STRIPE_SECRET_KEY": {
            "revocation_url": "https://dashboard.stripe.com/apikeys",
            "revocation_action": "Cliquer sur 'Roll key' ou supprimer la clé secrète.",
            "verification_command": "curl -s https://api.stripe.com/v1/charges -u <ANCIENNE_CLÉ>:",
            "expected_verification_response": "HTTP 401 Invalid API Key provided"
        },
        "PRIVATE_KEY_HEADER": {
            "revocation_url": "Serveur cible / ~/.ssh/authorized_keys ou Autorité de certification (PKI)",
            "revocation_action": "Retirer immédiatement la clé publique associée de tous les authorized_keys, révoquer le certificat.",
            "verification_command": "ssh -i <ancienne_cle_privee> -o BatchMode=yes user@serveur exit",
            "expected_verification_response": "Permission denied (publickey)"
        }
    }

    @classmethod
    def get_instructions_for_finding(cls, secret_type: str) -> Dict[str, Any]:
        specific = cls.SPECIFIC_REMEDIATION.get(secret_type, {
            "revocation_url": "Console d'administration du fournisseur tiers",
            "revocation_action": "Révoquer la clé immédiatement et générer un nouveau secret aléatoire.",
            "verification_command": "Effectuer une requête authentifiée avec l'ancien secret",
            "expected_verification_response": "Erreur d'authentification 401 ou accès refusé."
        })
        return {
            "overview": cls.GENERAL_PROTOCOL["DIFFERENCE_LOCAL_VS_GIT_HISTORY"],
            "steps": cls.GENERAL_PROTOCOL["FOUR_STEP_REMEDIATION"],
            "specific_provider_guidance": specific,
            "git_history_purge_recipe": (
                "# Exemple d'élimination complète de l'historique :\n"
                "pip install git-filter-repo\n"
                "git filter-repo --invert-paths --path chemin/vers/fichier_avec_secret\n"
                "# Ou pour remplacer le motif sans supprimer le fichier :\n"
                "git filter-repo --replace-text expressions_a_masquer.txt\n"
                "git push origin --force --all"
            )
        }
