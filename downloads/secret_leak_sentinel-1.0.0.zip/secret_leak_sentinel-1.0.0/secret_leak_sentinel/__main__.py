# -*- coding: utf-8 -*-
"""Entry point for python -m secret_leak_sentinel."""
from .cli import main

if __name__ == "__main__":
    main()
