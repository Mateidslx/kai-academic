# -*- coding: utf-8 -*-
"""secret_leak_sentinel/entropy.py
Calculateur d'entropie de Shannon pour la détection de chaînes aléatoires et de clés cryptographiques.
"""

import math
from typing import Dict


def calculate_shannon_entropy(data: str) -> float:
    """Calcule l'entropie de Shannon H(X) en bits par caractère.
    Une chaîne aléatoire haute densité (base64, hexadécimal, uuid) aura une entropie élevée (> 3.5 - 4.5).
    Une chaîne répétitive ou de texte naturel aura une faible entropie (< 3.0).
    """
    if not data:
        return 0.0

    length = len(data)
    frequencies: Dict[str, int] = {}
    for char in data:
        frequencies[char] = frequencies.get(char, 0) + 1

    entropy = 0.0
    for count in frequencies.values():
        p = count / length
        entropy -= p * math.log2(p)

    return round(entropy, 3)


def is_high_entropy(data: str, threshold: float = 3.6, min_length: int = 16) -> bool:
    """Vérifie si une chaîne dépasse le seuil d'entropie de Shannon minimal."""
    if len(data) < min_length:
        return False
    return calculate_shannon_entropy(data) >= threshold
