# -*- coding: utf-8 -*-
"""secret_leak_sentinel/release_entry.py
Point d'entrée autonome pour l'exécutable packagé (zipapp .pyz).
Supporte l'exécution hors arborescence sans dépendances externes.
"""

from __future__ import annotations
import sys
from . import __version__
from .cli import main as cli_main


def main() -> None:
    if sys.argv[1:] in (["--help"], ["-h"]):
        print(f"Secret Leak Sentinel {__version__} — Python 3.9+, sans dépendance")
        print("  scan [PATH] [--json]       Analyser un fichier ou un répertoire")
        print("  pre-commit                Vérifier l'index du dépôt Git courant")
        print("  install-hook [REPO]       Installer un hook dans un dépôt Git")
        print("  remediate [--type TYPE]   Afficher les étapes de remédiation")
        print("  --version                 Afficher la version du moteur")
        print("Utilisez COMMAND --help pour les options détaillées.")
    elif sys.argv[1:] == ["--version"]:
        print(f"secret-leak-sentinel {__version__}")
    else:
        cli_main()


if __name__ == "__main__":
    main()
