#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_release.py
Construit une archive autonome zipapp (.pyz) pour secret-leak-sentinel,
utilisable directement avec Python 3 standard sans aucune dépendance externe.

Usage:
  python build_release.py --output /path/to/secret-leak-sentinel.pyz
"""

from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path

SUPPORT = Path(__file__).resolve().parent
ARTIFACT_NAME = "secret-leak-sentinel.pyz"
ENTRY_POINT = "from secret_leak_sentinel.release_entry import main\nmain()\n"


def source_version(package: Path) -> str:
    tree = ast.parse((package / "__init__.py").read_text(encoding="utf-8"))
    for item in tree.body:
        if isinstance(item, ast.Assign):
            if any(isinstance(t, ast.Name) and t.id == "__version__" for t in item.targets):
                value = ast.literal_eval(item.value)
                if isinstance(value, str):
                    return value
    return "1.0.0"


def collect_files(source_root: Path) -> dict[str, bytes]:
    package = source_root / "secret_leak_sentinel"
    if not (package / "cli.py").is_file() or not (package / "detector.py").is_file():
        raise ValueError("SOURCE doit contenir secret_leak_sentinel/cli.py et detector.py.")
    contents: dict[str, bytes] = {}
    for base in (package,):
        for path in sorted(base.rglob("*")):
            relative = path.relative_to(base)
            if "__pycache__" in relative.parts or path.suffix in {".pyc", ".pyo"}:
                continue
            if path.is_symlink():
                raise ValueError(f"Lien symbolique refusé dans le paquet : {relative}")
            if path.is_file() and path.suffix in {".py", ".html", ".css", ".js", ".json", ".txt", ".md"}:
                contents["secret_leak_sentinel/" + relative.as_posix()] = path.read_bytes()
    contents["__main__.py"] = ENTRY_POINT.encode("utf-8")
    return contents


def build(source_root: Path, output_file: Path) -> dict:
    source_root = source_root.resolve(strict=True)
    version = source_version(source_root / "secret_leak_sentinel")
    contents = collect_files(source_root)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix=".kai-release-") as temporary:
        stage = Path(temporary)
        archive = stage / output_file.name
        with archive.open("wb") as handle:
            handle.write(b"#!/usr/bin/env python3\n")
        with zipfile.ZipFile(archive, "a", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
            for name, content in sorted(contents.items()):
                info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                handle.writestr(info, content)
        artifact_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
        manifest = {
            "product": "Secret Leak Sentinel",
            "version": version,
            "artifact": output_file.name,
            "artifact_bytes": archive.stat().st_size,
            "sha256": artifact_hash,
        }
        if output_file.exists():
            output_file.unlink()
        archive.rename(output_file)
        if os.name != "nt":
            output_file.chmod(0o755)

    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, nargs="?")
    parser.add_argument("output_directory", type=Path, nargs="?")
    parser.add_argument("--source", type=Path, dest="source_option")
    parser.add_argument("--output", type=Path, dest="output_option",
                        help="Archive .pyz à créer ou dossier de sortie")
    args = parser.parse_args()
    try:
        source = args.source_option or args.source or SUPPORT
        output = args.output_option or args.output_directory
        if output is None:
            output = SUPPORT / ARTIFACT_NAME
        if output.is_dir() or output.suffix.lower() != ".pyz":
            output = output / ARTIFACT_NAME
        manifest = build(source, output)
    except (OSError, ValueError, SyntaxError) as exc:
        parser.exit(2, f"Construction refusée : {exc}\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
