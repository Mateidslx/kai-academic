# -*- coding: utf-8 -*-
"""tests/test_secret_leak_sentinel.py
Tests unitaires rigoureux pour Secret Leak Sentinel :
- Calcul d'entropie de Shannon
- Filtrage des faux positifs et données d'exemple
- Détection contextuelle de clés et masquage strict
- Guide de remédiation et protocole de vérification d'invalidation
"""

import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest
from secret_leak_sentinel.entropy import calculate_shannon_entropy, is_high_entropy
from secret_leak_sentinel.filters import (
    is_placeholder_or_sample,
    is_git_commit_hash,
    is_file_ignored,
    has_allowlist_directive
)
from secret_leak_sentinel.detector import SecretLeakDetector
from secret_leak_sentinel.remediation import RemediationGuide
from secret_leak_sentinel.git_hook import extract_added_lines_from_diff


def test_shannon_entropy_calculation():
    # Chaîne vide
    assert calculate_shannon_entropy("") == 0.0
    
    # Chaîne répétitive (1 symbole = entropie nulle)
    assert calculate_shannon_entropy("aaaaaaaaaaaaaaaa") == 0.0
    
    # Texte répétitif simple (entropie faible)
    assert calculate_shannon_entropy("passwordpassword") < 3.0
    
    # Clé aléatoire base64 / haute densité (entropie élevée)
    high_ent_token = "Kx9$mP2#vL7!wQ5@zR1*bN8^cY3~"
    ent = calculate_shannon_entropy(high_ent_token)
    assert ent >= 4.0
    assert is_high_entropy(high_ent_token, threshold=3.5, min_length=16) is True
    
    # Chaîne courte sous le seuil min_length
    assert is_high_entropy("abc", min_length=10) is False


def test_filters_and_exclusion_rules():
    # Détection des placeholders et données d'exemple
    assert is_placeholder_or_sample("insert_your_token_here") is True
    assert is_placeholder_or_sample("YOUR_API_KEY_HERE") is True
    assert is_placeholder_or_sample("dummy_secret_value") is True
    assert is_placeholder_or_sample("password = 'REDACTED'") is True
    assert is_placeholder_or_sample("AKIA9876543210ZYXWUT") is False

    # Détection des hashes de commit Git
    assert is_git_commit_hash("4a78c1b2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8") is True
    assert is_git_commit_hash("not_a_hash") is False

    # Fichiers ignorés
    assert is_file_ignored(".env.example") is True
    assert is_file_ignored("config/.env.template") is True
    assert is_file_ignored(".git/config") is True
    assert is_file_ignored("app/main.py") is False

    # Directives d'exclusion explicite
    assert has_allowlist_directive("token = 'xyz' # pragma: allowlist secret") is True
    assert has_allowlist_directive("secret = 'xyz' # nosec") is True
    assert has_allowlist_directive("token = 'xyz'") is False


def test_detector_contextual_patterns_and_masking():
    detector = SecretLeakDetector()
    
    # Code synthétique contenant un jeton GitHub et une fausse clé AWS
    raw_github = "ghp_1234567890abcdef1234567890abcdef1234"
    raw_aws = "AKIAIOSFODNN7ABCDEFG"
    code = f"""
    # Configuration
    GITHUB_AUTH = "{raw_github}"
    AWS_KEY = "{raw_aws}"
    # Example placeholder (ne doit pas être détecté)
    DOCS_KEY = "ghp_placeholder_your_token_here_xxxx"
    """
    
    findings = detector.scan_content(code, source_path="test_config.py")
    
    # Exactement 2 secrets réels détectés (le placeholder doit être ignoré)
    assert len(findings) == 2
    types = [f.secret_type for f in findings]
    assert "GITHUB_TOKEN" in types
    assert "AWS_ACCESS_KEY_ID" in types
    
    # Vérification impérative du masquage strict
    for f in findings:
        assert raw_github not in f.masked_value
        assert raw_aws not in f.masked_value
        assert "[REDACTED:" in f.masked_value
        # Le contexte ne doit pas non plus contenir le secret brut
        assert raw_github not in f.context_snippet
        assert raw_aws not in f.context_snippet


def test_detector_generic_high_entropy_assignment():
    detector = SecretLeakDetector()
    
    # Assignation avec clé à haute entropie
    raw_secret = "x7K!9mP@2#vL8$wQ4%zR0^bN6&cY1*tU"
    code = f'api_key = "{raw_secret}"'
    findings = detector.scan_content(code)
    
    assert len(findings) == 1
    assert findings[0].secret_type == "GENERIC_HIGH_ENTROPY_KEY"
    assert findings[0].entropy >= 4.0
    assert raw_secret not in findings[0].masked_value

    # Assignation avec mot de passe commun faible entropie (ne doit pas être faussement alerté)
    code_low = 'password = "password123"'
    findings_low = detector.scan_content(code_low)
    assert len(findings_low) == 0


def test_remediation_guide_instructions():
    guide = RemediationGuide.get_instructions_for_finding("AWS_ACCESS_KEY_ID")
    assert "ATTENTION : Modifier simplement le fichier local" in guide["overview"]
    assert len(guide["steps"]) == 4
    assert "git filter-repo" in guide["git_history_purge_recipe"]
    
    aws_info = guide["specific_provider_guidance"]
    assert "IAM" in aws_info["revocation_url"]
    assert "aws sts get-caller-identity" in aws_info["verification_command"]
    assert "InvalidClientTokenId" in aws_info["expected_verification_response"]


def test_diff_parser_for_staged_changes():
    mock_diff = """diff --git a/app.py b/app.py
index e69de29..d95f3ad 100644
--- a/app.py
+++ b/app.py
@@ -1,2 +1,3 @@
 def run():
+    token = "ghp_1234567890abcdef1234567890abcdef1234"
     pass
"""
    added = extract_added_lines_from_diff(mock_diff)
    assert len(added) == 1
    filepath, line_no, content = added[0]
    assert filepath == "app.py"
    assert "ghp_1234567890abcdef" in content


def test_html_and_sarif_reports(tmp_path):
    from secret_leak_sentinel.reporter import generate_html_report, generate_sarif_report
    detector = SecretLeakDetector()
    raw_github = "ghp_1234567890abcdef1234567890abcdef1234"
    code = f'GITHUB_KEY = "{raw_github}"'
    findings = detector.scan_content(code, source_path="auth.py")
    assert len(findings) == 1

    # 1. HTML generation test
    html_out = generate_html_report(findings, target_name="MonProjet")
    assert "<!DOCTYPE html>" in html_out
    assert "MonProjet" in html_out
    assert "GITHUB_TOKEN" in html_out
    assert "auth.py" in html_out
    assert raw_github not in html_out
    assert "[REDACTED:" in html_out
    assert "git-filter-repo" in html_out

    # Test clean HTML report
    clean_html = generate_html_report([], target_name="ProjetPropre")
    assert "AUCUN SECRET EXPOSÉ" in clean_html

    # 2. SARIF generation test
    sarif_str = generate_sarif_report(findings, target_name="MonProjet")
    import json
    sarif_data = json.loads(sarif_str)
    assert sarif_data["version"] == "2.1.0"
    assert len(sarif_data["runs"]) == 1
    run = sarif_data["runs"][0]
    assert run["tool"]["driver"]["name"] == "secret-leak-sentinel"
    assert len(run["results"]) == 1
    res = run["results"][0]
    assert res["ruleId"] == "SLS-GITHUB_TOKEN"
    assert res["locations"][0]["physicalLocation"]["artifactLocation"]["uri"] == "auth.py"
    assert raw_github not in sarif_str


def test_cli_scan_with_reports(tmp_path, monkeypatch):
    from secret_leak_sentinel.cli import main
    # Créer un fichier de test
    src = tmp_path / "sample.py"
    src.write_text('API_KEY = "ghp_1234567890abcdef1234567890abcdef1234"\n', encoding="utf-8")
    
    html_out = tmp_path / "report.html"
    sarif_out = tmp_path / "report.sarif"
    
    monkeypatch.setattr(sys, "argv", [
        "secret-leak-sentinel", "scan", str(src),
        "--html", str(html_out),
        "--sarif", str(sarif_out)
    ])
    
    with pytest.raises(SystemExit) as exc:
        main()
    # Le scan a détecté un secret donc exit code 1
    assert exc.value.code == 1
    assert html_out.exists()
    assert sarif_out.exists()
    assert "<!DOCTYPE html>" in html_out.read_text(encoding="utf-8")
    assert "SLS-GITHUB_TOKEN" in sarif_out.read_text(encoding="utf-8")


