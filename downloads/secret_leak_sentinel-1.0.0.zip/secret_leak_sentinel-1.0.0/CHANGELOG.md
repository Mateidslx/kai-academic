# Changelog

All notable changes to `secret-leak-sentinel` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-10-15

### Added
- Shannon Entropy ($H(X)$) statistical randomness detection for arbitrary API keys and secrets.
- Contextual regex patterns for GitHub tokens, OpenAI, Anthropic, AWS IAM, Stripe, Slack, RSA/OpenSSH keys, JWTs, and database URIs.
- False positive allowlist filter (.env.example, sample placeholders, `# pragma: allowlist secret`, git commit hashes).
- Strict fail-closed redaction mask (`[REDACTED: len=... entropy=...]`).
- Pre-commit hook automatic installer (`secret-leak-sentinel install-hook`).
- Git staged diff parser inspecting only newly added lines in the Git index.
- Comprehensive remediation guide with `git-filter-repo` and adversarial validation steps.
- PEP 517 / PEP 621 wheel distribution build support.
