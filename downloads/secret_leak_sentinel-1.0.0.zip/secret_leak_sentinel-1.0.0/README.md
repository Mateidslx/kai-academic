# Secret Leak Sentinel (Ex-Code Provenance Guard)

Outil d'ingénierie rigoureux pour la détection de fuites de secrets, clés d'API et jetons sensibles avant commit ou lors d'audits statiques de référentiels de code.

> **Note d'intégrité et de vérité produit :**
> Cet outil a été renommé de manière transparente en **Secret Leak Sentinel**. Il a été purgé de toute allégation trompeuse ("code provenance guard", "intellectual property protection", "blockchain authorship") qui masquait ce qui n'était auparavant qu'un détecteur heuristique regex rudimentaire.

---

## Capacités Authentiques

1. **Calcul d'Entropie de Shannon ($H(X)$)** :
   - Évaluation statistique de l'entropie par caractère (en bits).
   - Détection des chaînes hautement aléatoires ($H \ge 3.5 - 4.5$ bits/char) dans les assignations (`api_key`, `secret`, `auth_token`).

2. **Expressions Régulières Contextuelles Précises** :
   - Jetons GitHub (`ghp_`, `gho_`, `ghu_`, `ghs_`, `ghr_`).
   - Clés d'API OpenAI (`sk-proj-`, `sk-svcacct-`, `sk-`).
   - Clés d'API Anthropic (`sk-ant-`).
   - Identifiants IAM AWS (`AKIA`, `ASIA`, `AGPA`, etc.).
   - Clés secrètes Stripe (`sk_live_`).
   - Jetons de bot Slack (`xoxb-`).
   - En-têtes de clés privées cryptographiques (`BEGIN RSA/EC/OPENSSH/PGP PRIVATE KEY`).
   - Chaînes de connexion de base de données avec identifiants (`postgres://`, `mongodb://`, etc.).
   - Jetons JWT signés (`ey...ey...`).

3. **Filtrage des Faux Positifs & Données d'Exemple** :
   - Exclusion automatique des gabarits (`.env.example`, `.env.template`).
   - Exclusion des placeholders documentaires (`your_token_here`, `dummy`, `redacted`, `insert_here`).
   - Détection des hashes de commit Git (40 caractères hexadécimaux purs).
   - Prise en charge des directives d'exclusion inline (`# pragma: allowlist secret`, `# nosec`).

4. **Masquage Strict Fail-Closed** :
   - **Aucun secret brut n'est jamais imprimé** dans les sorties standard, journaux, résumés ou rapports.
   - Format de masquage sécurisé : `abc***[REDACTED: len=40, entropy=4.25]***xyz`.

5. **Deux Modes Opérationnels** :
   - Mode Hook Git Pre-commit : analyse exclusive des lignes ajoutées dans le cache Git (`git diff --cached`).
   - Mode Audit de Dépôt : analyse récursive des fichiers du projet avec sortie texte ou JSON.

6. **Guide de Remédiation & Révocation** :
   - Rappel formel : modifier un fichier local ou committer une suppression **ne supprime pas le secret de l'historique Git**.
   - Procédure de purge d'historique avec `git-filter-repo`.
   - Commandes de vérification contradictoire (`curl`, `aws sts`) prouvant que l'ancienne clé retourne 401 Unauthorized et que la nouvelle fonctionne.

---

## Utilisation

```bash
# 1. Analyser un répertoire ou un fichier
python -m secret_leak_sentinel.cli scan chemin/vers/projet

# Sortie structurée JSON
python -m secret_leak_sentinel.cli scan . --json

# 2. Vérifier les modifications indexées (mode pre-commit)
python -m secret_leak_sentinel.cli pre-commit

# 3. Installer le hook git pre-commit automatiquement
python -m secret_leak_sentinel.cli install-hook .

# 4. Obtenir les consignes de révocation et de purge
python -m secret_leak_sentinel.cli remediate --type AWS_ACCESS_KEY_ID
```
